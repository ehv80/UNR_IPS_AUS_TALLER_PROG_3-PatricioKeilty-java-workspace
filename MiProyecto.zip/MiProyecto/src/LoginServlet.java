

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class for Servlet: LoginServlet
 * 
 */
 public class LoginServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
	
	private static final String LOGIN_NAME = "loginName";

	/**
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request,
	 *      HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<html><head><title>Ejemplo de uso de HttpSession</title></head>");
		out.println("<body>" );

		String usuarioParam = request.getParameter("usuario");
		HttpSession session = request.getSession(true);
		String loginName = (String)session.getAttribute(LOGIN_NAME);
		
		if ( loginName == null & usuarioParam == null ){
			out.println("<form action=\"\" method=\"GET\">");
			out.println("Usuario: <input type=\"text\" name=\"usuario\"/>" );
			out.println("<input type=\"submit\" value=\"Enviar\"/>" );
			out.println("</form>");
		}else{
			if(loginName == null)
				session.setAttribute(LOGIN_NAME, usuarioParam);

			loginName = (String)session.getAttribute(LOGIN_NAME);
			out.println("<h1>Bienvenido!</h1>");
			out.println("<p>Est&aacute;s logueado como " + loginName + " </p>");
		}

		out.println("</body></html>");
		out.close();
	}
	
	/**
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request,
	 *      HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// invoca doGet
		doGet(request, response);
	}
	
}