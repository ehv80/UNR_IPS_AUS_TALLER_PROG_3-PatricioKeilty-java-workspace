
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class for Servlet: DispatchServlet
 * 
 */
public class DispatchServlet extends javax.servlet.http.HttpServlet implements
		javax.servlet.Servlet {

	/**
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request,
	 *      HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// set headers and buffer size before accessing the Writer
		response.setContentType("text/html");
		response.setBufferSize(8192);
		PrintWriter out = response.getWriter();
		// then write the response
		out.println("<html>" + "<head><title>" + "Vamos a incluir un banner...." + "</title></head>");
		out.println("<body>");
		// Get the dispatcher; it gets the banner to the user
		RequestDispatcher dispatcher = getServletContext()
				.getRequestDispatcher("/banner");
		if (dispatcher != null)
			dispatcher.include(request, response);
		out.println("</body>");
		out.println("</html>");
		out.close();
	}
}