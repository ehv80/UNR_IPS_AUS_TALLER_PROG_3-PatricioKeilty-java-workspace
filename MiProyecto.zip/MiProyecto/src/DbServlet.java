import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class DbServlet extends HttpServlet{

	private String _databaseUrl;
	private String _username;
	private String _password;
	private String _databaseDriverClassName;

	/**
	 * @see javax.servlet.Servlet#destroy()
	 */
	public void destroy() {
		super.destroy();
	}
	
	/**
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doSomething();
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<html><head><title>" + 
				getServletContext().getInitParameter("titulo")+ 
				"</title></head>");
		out.println("<body>" + getServletConfig().getInitParameter("mensaje") + "</body></html>");
		out.close();
	}
	
	private void doSomething() throws ServletException {
		// ejemplo simple para ilustrar el uso de par�metros en el contexto de la aplicaci�n
		try {
			Class.forName(_databaseDriverClassName);
			Connection connection = DriverManager.getConnection(_databaseUrl, _username, _password);

			// ejecutar alguna consulta a la base de datos

			connection.close();
		} catch (SQLException e) {
			throw new ServletException(e);
		} catch (ClassNotFoundException e) {
			throw new ServletException(e);
		}
		
	}

	/**
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	/**
	 * @see javax.servlet.Servlet#getServletInfo()
	 */
	public String getServletInfo() {
		return super.getServletInfo();
	}
	
	/**
	 * @see javax.servlet.GenericServlet#init()
	 */
	public void init() throws ServletException {
		//c�digo de inicializaci�n servlet 
		_databaseDriverClassName = getServletContext().getInitParameter("db_driver_class");
		_databaseUrl = getServletContext().getInitParameter("db_url");
		_username = getServletContext().getInitParameter("db_user");
		_password = getServletContext().getInitParameter("db_pass");
	}
}
