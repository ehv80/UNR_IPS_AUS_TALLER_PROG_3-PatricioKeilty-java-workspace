

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class for Servlet: SimpleServlet
 *
 */
 public class SimpleServlet extends javax.servlet.http.HttpServlet {
	 
    /**
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public SimpleServlet() {
		super();
	}
	
	/**
	 * @see javax.servlet.Servlet#destroy()
	 */
	public void destroy() {
		super.destroy();
	}
	
	/**
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<html><head><title>" + 
				getServletContext().getInitParameter("titulo")+ 
				"</title></head>");
		out.println("<body>" + getServletConfig().getInitParameter("mensaje") + "</body></html>");
		out.close();
	}
	
	/**
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	/**
	 * @see javax.servlet.Servlet#getServletInfo()
	 */
	public String getServletInfo() {
		return super.getServletInfo();
	}
	
	/**
	 * @see javax.servlet.GenericServlet#init()
	 */
	public void init() throws ServletException {
		//c�digo de inicializaci�n 
	}
}