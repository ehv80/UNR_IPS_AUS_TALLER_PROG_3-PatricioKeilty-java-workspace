package clinica;

// Generated 06/01/2008 07:45:09 by Hibernate Tools 3.2.0.beta8

import java.util.List;
import javax.naming.InitialContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;

import dbServlets.Hiber8Manager;
import static org.hibernate.criterion.Example.create;

/**
 * Home object for domain model class Diagnostico.
 * @see clinica.Diagnostico
 * @author Hibernate Tools
 */
public class DiagnosticoHome 
{
	/**
	 * Método:	consultaDiagnosticos
	 * 			Realiza una consulta HQL en la base de datos Clinica, Tabla DIAGNOSTICOS. 
	 * @author 	ehv80
	 * @param 	consultaHQL
	 * @return	listaDeDiagnosticos
	 * @throws	HibernateException
	 */
	public static List<Diagnostico> consultaDiagnosticos(String consultaHQL) throws HibernateException
	{
		Session session = null;
		Transaction transaccion = null;
		try
		{
			session = Hiber8Manager.openHibernateSession();
			transaccion = session.beginTransaction();
			List<Diagnostico> listaDeDiagnosticos = ( List<Diagnostico> )( session.createQuery( consultaHQL ).list() );
			transaccion.commit();
			return listaDeDiagnosticos;
		}
		catch( HibernateException ex )
		{
			if( transaccion != null )
			{
				transaccion.rollback();
			}
			throw ex;
		}
		finally
		{
			if( session != null )
			{
				session.close();
			}
		}
	}
	
	/**
	 * Método:	modificaDiagnostico
	 * 			Realiza la modificación del registro de un Diagnostico en la base de datos Clinica, Tabla DIAGNOSTICOS.
	 * @author 	ehv80
	 * @param 	diagnostico
	 * @throws 	HibernateException
	 */
	public static void modificaDiagnostico(Diagnostico diagnostico) throws HibernateException
	{
		Transaction transaccion = null;
		Session session = null;
		try
		{
			session = Hiber8Manager.openHibernateSession();
			transaccion = session.beginTransaction();
			session.saveOrUpdate( diagnostico );
			transaccion.commit();
		}
		catch( HibernateException ex )
		{
			if( transaccion != null )
			{
				transaccion.rollback();
			}
			throw ex;
		}
		finally
		{
			if( session != null )
			{
				session.close();
			}
		}
	}
	
	/**
	 * Método:	eliminaDiagnostico
	 * 			Realiza la eliminación del registro de un Diagnostico en la base de datos Clinica, Tabla DIAGNOSTICOS.
	 * @author 	ehv80
	 * @param 	diagnostico
	 * @throws 	HibernateException
	 */
	public static void eliminaDiagnostico(Diagnostico diagnostico) throws HibernateException
	{
		Transaction transaccion = null;
		Session session = null;
		try
		{
			session = Hiber8Manager.openHibernateSession();
			transaccion = session.beginTransaction();
			session.delete( diagnostico );
			transaccion.commit();
		}
		catch( HibernateException ex )
		{
			if( transaccion != null )
			{
				transaccion.rollback();
			}
			throw ex;
		}
		finally
		{
			if( session != null )
			{
				session.close();
			}
		}
	}
	
	/**
	 * Método:	encontrarPorEjemplo
	 * 			Responsable de realizar consultas basada en una instancia ejemplo.
	 * @param 	instance
	 * @return	listaDeDiagnosticos
	 * @throws 	HibernateException
	 */
	public static List<Diagnostico> encontrarPorEjemplo(Diagnostico diagnostico) throws HibernateException 
	{
		Transaction transaccion = null;
		Session session = null;
		try
		{
			session = Hiber8Manager.openHibernateSession();
			transaccion = session.beginTransaction();
			List<Diagnostico> listaDeDiagnosticos = ( List<Diagnostico> ) session.createCriteria( Diagnostico.class ).add( Example.create( diagnostico ) ).list();
			transaccion.commit();
			return listaDeDiagnosticos;
		}
		catch( HibernateException ex )
		{
			//catcheada y relanzada para hacer el rollback
			if( transaccion != null )
			{
				transaccion.rollback();
			}
			throw ex;
		}
		finally
		{
			if( session != null )
			{
				session.close();
			}
		}
	}
}