package clinica;

// Generated 06/01/2008 07:45:09 by Hibernate Tools 3.2.0.beta8

import java.util.List;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;

import dbServlets.Hiber8Manager;

/**
 * Home object for domain model class Paciente.
 * @see clinica.Paciente
 * @author Hibernate Tools
 */
public class PacienteHome {

	/**
	 * Método:	consultaPacientes
	 * 			Realiza una consulta HQL en la base de datos Clinica, Tabla PACIENTES. 
	 * @author 	ehv80
	 * @param 	consultaHQL
	 * @return	listaDePacientes
	 * @throws	HibernateException
	 */
	public static List<Paciente> consultaPacientes(String consultaHQL) throws HibernateException
	{
		Session session = null;
		Transaction transaccion = null;
		try
		{
			session = Hiber8Manager.openHibernateSession();
			transaccion = session.beginTransaction();
			List<Paciente> listaDePacientes = ( List<Paciente> )( session.createQuery( consultaHQL ).list() );
			transaccion.commit();
			return listaDePacientes;
		}
		catch( HibernateException ex )
		{
			if( transaccion != null )
			{
				transaccion.rollback();
			}
			throw ex;
		}
		finally
		{
			if( session != null )
			{
				session.close();
			}
		}
	}
	
	/**
	 * Método:	modificaPaciente
	 * 			Realiza la modificación del registro de un Paciente en la base de datos Clinica, Tabla PACIENTES.
	 * @author 	ehv80
	 * @param 	paciente
	 * @throws 	HibernateException
	 */
	public static void modificaPaciente(Paciente paciente) throws HibernateException
	{
		Transaction transaccion = null;
		Session session = null;
		try
		{
			session = Hiber8Manager.openHibernateSession();
			transaccion = session.beginTransaction();
			session.saveOrUpdate( paciente );
			transaccion.commit();
		}
		catch( HibernateException ex )
		{
			if( transaccion != null )
			{
				transaccion.rollback();
			}
			throw ex;
		}
		finally
		{
			if( session != null )
			{
				session.close();
			}
		}
	}
	
	/**
	 * Método:	eliminaPaciente
	 * 			Realiza la eliminación del registro de un Paciente en la base de datos Clinica, Tabla PACIENTES.
	 * @author 	ehv80
	 * @param 	paciente
	 * @throws 	HibernateException
	 */
	public static void eliminaPaciente(Paciente paciente) throws HibernateException
	{
		Transaction transaccion = null;
		Session session = null;
		try
		{
			session = Hiber8Manager.openHibernateSession();
			transaccion = session.beginTransaction();
			session.delete( paciente );
			transaccion.commit();
		}
		catch( HibernateException ex )
		{
			if( transaccion != null )
			{
				transaccion.rollback();
			}
			throw ex;
		}
		finally
		{
			if( session != null )
			{
				session.close();
			}
		}
	}
	
	/**
	 * Método:	encontrarPorEjemplo
	 * 			Responsable de realizar consultas basada en una instancia ejemplo.
	 * @param 	instance
	 * @return	listaDePacientes
	 * @throws 	HibernateException
	 */
	public static List<Paciente> encontrarPorEjemplo(Paciente paciente) throws HibernateException 
	{
		Transaction transaccion = null;
		Session session = null;
		try
		{
			session = Hiber8Manager.openHibernateSession();
			transaccion = session.beginTransaction();
			List<Paciente> listaDePacientes = ( List<Paciente> ) session.createCriteria( Paciente.class ).add( Example.create( paciente ) ).list();
			transaccion.commit();
			return listaDePacientes;
		}
		catch( HibernateException ex )
		{
			//catcheada y relanzada para hacer el rollback
			if( transaccion != null )
			{
				transaccion.rollback();
			}
			throw ex;
		}
		finally
		{
			if( session != null )
			{
				session.close();
			}
		}
	}
	
	/*
	* IGUAL ASÍ NO FUNCIONA ..!
	* @param paciente
	* @return
	*
	*public static Set<Diagnostico> obtenerSetDeDiagnosticos( Paciente paciente )
	*{
	*	Session session = null;
	*	Transaction transaccion = null;
	*	try
	*	{
	*		session = Hiber8Manager.openHibernateSession();
	*		transaccion = session.beginTransaction();
	*		Set<Diagnostico> setDeDiagnosticos = paciente.getDiagnosticos();
	*		transaccion.commit();
	*		return setDeDiagnosticos;
	*	}
	*	catch( HibernateException ex )
	*	{
	*		if( transaccion != null )
	*		{
	*			transaccion.rollback();
	*		}
	*		throw ex;
	*	}
	*	finally
	*	{
	*		if( session != null )
	*		{
	*			session.close();
	*		}
	*	}
	*}
	*/
}
