package clinica;

import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;

import dbServlets.Hiber8Manager;

/**
 * Home object for domain model class Usuario.
 * @see .Usuario
 * @author Hibernate Tools
 */
public class UsuarioHome 
{
	
	/**
	 * Método:	consultaUsuarios
	 * 			Realiza una consulta HQL en la base de datos Clinica, Tabla USUARIOS. 
	 * @author 	patricio.keilty@gmail.com
	 * @param 	consultaHQL
	 * @return	listaDeUsuarios
	 * @throws	HibernateException
	 */
	public static List<Usuario> consultaUsuarios(String consultaHQL) throws HibernateException
	{
		Session session = null;
		Transaction transaccion = null;
		try
		{
			session = Hiber8Manager.openHibernateSession();
			transaccion = session.beginTransaction();
			List<Usuario> listaDeUsuarios = ( List<Usuario> )( session.createQuery( consultaHQL ).list());
			transaccion.commit();
			return listaDeUsuarios;
		}
		catch( HibernateException ex )
		{
			if( transaccion != null )
			{
				transaccion.rollback();
			}
			throw ex;
		}
		finally
		{
			if( session != null )
			{
				session.close();
			}
		}
	}
	
	/**
	 * Método:	modificaUsuario
	 * 			Realiza la modificación del registro de un Usuario en la base de datos Clinica, Tabla USUARIOS.
	 * @author 	patricio.keilty@gmail.com
	 * @param 	usuario
	 * @throws 	HibernateException
	 */
	public static void modificaUsuario(Usuario usuario) throws HibernateException
	{
		Transaction transaccion = null;
		Session session = null;
		try
		{
			session = Hiber8Manager.openHibernateSession();
			transaccion = session.beginTransaction();
			session.saveOrUpdate( usuario );
			transaccion.commit();
		}
		catch( HibernateException ex )
		{
			if (transaccion != null)
			{
				transaccion.rollback();
			}
			throw ex;
		}
		finally
		{
			if( session != null )
			{
				session.close();
			}
		}
	}
	
	/**
	 * Método:	eliminaUsuario
	 * 			Realiza la eliminación del registro de un Usuario en la base de datos Clinica, Tabla USUARIOS.
	 * @author 	patricio.keilty@gmail.com
	 * @param 	usuario
	 * @throws 	HibernateException
	 */
	public static void eliminaUsuario(Usuario usuario) throws HibernateException
	{
		Transaction transaccion = null;
		Session session = null;
		try
		{
			session = Hiber8Manager.openHibernateSession();
			transaccion = session.beginTransaction();
			session.delete( usuario );
			transaccion.commit();
		}
		catch( HibernateException ex )
		{
			if( transaccion != null )
			{
				transaccion.rollback();
			}
			throw ex;
		}
		finally
		{
			if( session != null )
			{
				session.close();
			}
		}
	}
	
	/**
	 * Método:	encontrarPorEjemplo
	 * 			Responsable de realizar consultas basada en una instancia ejemplo.
	 * @author 	patricio.keilty@gmail.com
	 * @param 	instance
	 * @return	results
	 * @throws 	HibernateException
	 */
	public static List<Usuario> encontrarPorEjemplo(Usuario instance) throws HibernateException 
	{
		Transaction transaccion = null;
		Session session = null;
		try
		{
			session = Hiber8Manager.openHibernateSession();
			transaccion = session.beginTransaction();
			List<Usuario> results = ( List<Usuario> ) session.createCriteria( Usuario.class ).add( Example.create( instance )).list();
			transaccion.commit();
			return results;
		}
		catch( HibernateException ex )
		{
			//catcheada y relanzada para hacer el rollback
			if( transaccion != null )
			{
				transaccion.rollback();
			}
			throw ex;
		}
		finally
		{
			if( session != null )
			{
				session.close();
			}
		}
	}
}