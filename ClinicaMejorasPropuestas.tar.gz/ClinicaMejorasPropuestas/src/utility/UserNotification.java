package utility;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * Utility class for managing user notification by means of user´s HttpSession.
 *  
 * @author patricio.keilty@gmail.com
 *
 */
public class UserNotification {

	private static final String MESSAGE_LIST = "USER_MESSAGES";
	
	public static enum Level {
		ERROR, WARN, INFO;
		
		public String render(String text){
			String style = "";
			switch (this){
				case ERROR:
					style = "style=\"color: red; font-size: 18px; line-height: 125%\" ";
					break;
				case WARN:
					style = "style=\"color: yellow; font-size: 18px; line-height: 125%\" ";
					break;
				case INFO:
					style = "style=\"color: #3B6EBF; font-size: 18px; line-height: 125%\" ";
					break;
			}
			return "<span " + style + ">" + text + "</span>";
		}
	}
	
	public static void addMessage(HttpServletRequest request, String message, Level level){
		getMessages(request).add(level.render(message));
	}

	public static List getMessages(HttpServletRequest request){
		List messages = (List) request.getSession().getAttribute(MESSAGE_LIST);
		if (messages == null){
			messages = new ArrayList();
			request.getSession().setAttribute(MESSAGE_LIST, messages);
		}
		return messages;
	}
	
	public static void clearMessages(HttpServletRequest request){
		getMessages(request).clear();
	}
}
