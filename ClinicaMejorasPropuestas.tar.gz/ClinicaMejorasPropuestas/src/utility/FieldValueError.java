package utility;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

/**
 * Helper utility class to manage form fields values and error messages.
 * Clase de Utilidad que ayuda a manejar los valores y mensajes de error de los campos de un formulario.
 * 
 * @author patricio.keilty@gmail.com
 *
 */
public class FieldValueError
{

	private static final String PARAMS_ERRORS = "form_errors";
	private static final String PARAMS_VALUES = "form_values";
	
	/**
	 * Método:	getParamsMap
	 * 			Retorna un HashMap<String, String>, que contiene pares clave-valor, ambos objetos String.
	 * 			Se trata del mapa para almacenar parámetros de un formulario.
	 * @author 	patricio.keilty@gmail.com 
	 * @param 	request
	 * @return	mapa
	 */
	private static Map<String, String> getParamsMap( HttpServletRequest request )
	{
		Map<String, String> mapa = (Map<String, String>)request.getAttribute( FieldValueError.PARAMS_VALUES );
		if( mapa == null )
		{
			mapa = new HashMap<String, String>();
			request.setAttribute( FieldValueError.PARAMS_VALUES, mapa );
		}
		return mapa;
	}
	
	/**
	 * Método:	getErrorsMap
	 * 			Retorna un HashMap<String, String>, que contiene pares clave-valor ambos objetos String.
	 * 			Se trata del mapa para almacenar los errores relacionados a los parámetros de un formulario.
	 * @author 	patricio.keilty@gmail.com
	 * @param 	request
	 * @return 	mapa
	 */
	private static Map<String, String> getErrorsMap( HttpServletRequest request )
	{
		Map<String, String> mapa = (Map<String, String>)request.getAttribute( FieldValueError.PARAMS_ERRORS );
		if( mapa == null )
		{
			mapa = new HashMap<String, String>();
			request.setAttribute( FieldValueError.PARAMS_ERRORS, mapa );
		}
		return mapa;
	}
	
	/**
	 * Método:	getFieldValue
	 * 			Método auxiliar para obtener el valor de un campo por nombre.
	 * 			Intenta obtenerlo del atributo, sino del param equivalente, y sino lo encuentra retorna vacío.
	 * @author 	patricio.keilty@gmail.com
	 * @param 	fieldName
	 * @param 	request
	 * @return 	value
	 */
	public static String getFieldValue( String fieldName, HttpServletRequest request )
	{
		Map<String, String> mapa = (Map<String, String>)request.getAttribute( FieldValueError.PARAMS_VALUES );
		String value = "";
		String found = null;
		if( mapa != null )
		{
			found = mapa.get( fieldName );
			if( found != null )
			{
				value = found;
			}
			else
			{
				found = request.getParameter( fieldName );
			}
			if( found != null )
			{
				value = found;
			}
		}
		return value;
	}
	
	/**
	 * Método:	setFieldValue
	 * 			Introduce una cadena String del valor de un campo de un formulario en el HashMap de Parámetros.
	 * @author 	patricio.keilty@gmail.com
	 * @param 	fieldName
	 * @param 	fieldValue
	 * @param 	request
	 */
	public static void setFieldValue( String fieldName, String fieldValue, HttpServletRequest request )
	{
		Map<String, String> mapa = getParamsMap(request);
		mapa.put( fieldName, fieldValue );
	}
	
	/**
	 * Método:	getFieldError
	 * 			Método auxiliar para obtener la descripción del error relacionado a un campo por su nombre.
	 * @author 	patricio.keilty@gmail.com
	 * @param 	fieldName
	 * @param 	request
	 * @return	value
	 */
	//	 TODO support more than one error in a field
	public static String getFieldError( String fieldName, HttpServletRequest request )
	{
		Map<String, String> mapa = (Map<String, String>)request.getAttribute( FieldValueError.PARAMS_ERRORS );
		String value = "";
		if( mapa != null )
		{
			String valor = mapa.get( fieldName );
			if( valor != null )
			{
				value = valor;
			}
		}
		return value;
	}
	
	/**
	 * Método:	setFieldError
	 * 			Introduce una cadena String de un error relacionado a un campo de un formulario en el HashMap de Errores de los Parámetros.
	 * @author 	patricio.keilty@gmail.com
	 * @param 	fieldName
	 * @param 	fieldError
	 * @param 	request
	 */
	public static void setFieldError( String fieldName, String fieldError, HttpServletRequest request )
	{
		Map<String, String> mapa = getErrorsMap( request );
		mapa.put( fieldName, fieldError );
	}
}