package dbServlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import utility.FieldValueError;
import utility.UserNotification;
import utility.UserNotification.Level;
import clinica.Usuario;
import clinica.UsuarioHome;

/**
 * Servlet implementation class for Servlet: UsuarioServlet
 *
 */
public class UsuarioServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
{
	public static final String PARAM_ACCION = "accion";
	public static final String PARAM_NOMBRE_REAL = "nombreReal";
	public static final String PARAM_APELLIDO = "apellido";
	public static final String PARAM_USERNAME = "username";
	public static final String PARAM_PASSWORD = "password";
		
	public static final String PARAM_CRITERIO_CONSULTA = "selectorCriterioConsulta";
	public static final String PARAM_CRITERIO_CONSULTA_NOMBRE = "Nombre";
	public static final String PARAM_CRITERIO_CONSULTA_APELLIDO = "Apellido";
	public static final String PARAM_CRITERIO_CONSULTA_USERNAME = "Username";
	
	public static final String PARAM_VALOR_BUSCAR = "valorBuscar";
	
	public static final String PARAM_ELECCION_ELIMINAR_USUARIO = "eleccionEliminaUsuario";
	public static final String PARAM_SI = "SI";
	public static final String PARAM_NO = "NO";
	
	public static final String LISTA_USUARIOS = "lista_usuarios";

	public static final String ACCION_BORRAR = "borrar";
	public static final String ACCION_ACTUALIZAR = "actualizar";
	public static final String ACCION_LISTAR = "listar";
	public static final String ACCION_CONSULTAR = "consultar";
	public static final String ACCION_REGISTRAR = "registrar";
	public static final String ACCION_COMPLETAR_FORMULARIO_USUARIO ="completarFormularioUsuario";
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}  	
	
	/*
	 * (non-Java-doc)
	 * 
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request,
	 *      HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String accion = request.getParameter( UsuarioServlet.PARAM_ACCION );
		//if( accion == null ){ accion = ACCION_LISTAR; } //?

		// validar que el usuario está autenticado
		Usuario usuario = LoginServlet.getUsuarioEnSesion( request );
		if( accion != null )
		{
			if( !ACCION_REGISTRAR.equals( accion ) && usuario == null )
			{
				UserNotification.addMessage( request, 
					"Está intentando acceder a un recurso restringido para el cual necesita estar autenticado, por favor regístrese o acceda con su username y su password ..!",
					Level.ERROR );
				request.getRequestDispatcher("index.jsp").forward(request, response);
				return;
			}
		
			// el procesamiento se realiza según el valor del parámetro "accion"
			if( ACCION_LISTAR.equals(accion) ) 
			{
				doListar(request, response);
			}
			else if( ACCION_CONSULTAR.equals( accion ) )
			{
				doConsultar( request, response );
			}
			else if( ACCION_ACTUALIZAR.equals( accion ) )
			{
				doActualizar( request, response );
			}
			else if( ACCION_BORRAR.equals( accion ) )
			{
				doEliminar( request, response );
			}
			else if( ACCION_REGISTRAR.equals( accion) )
			{
				doRegistrar( request, response );
			}
			else if( ACCION_COMPLETAR_FORMULARIO_USUARIO.equals( accion ) )
			{
				doCompletarFormularioUsuario( request, response );
			}
		}
	}

	/**
	 * Método:	doCompletarFormularioUsuario
	 * 			Método auxiliar para completar los campos del formulario que está en do_modifica_usuario.jsp
	 * @param 	request
	 * @param 	response
	 * @throws 	ServletException
	 * @throws 	IOException
	 */
	private void doCompletarFormularioUsuario( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException
	{
		setCamposDeUsuarioEnSesion(request);
		request.getRequestDispatcher("do_modifica_usuario.jsp").forward(request, response);
	}
	
	/**
	 * Método:	doRegistrar
	 * 			Responsable de llevar adelante la registración de un usuario del sistema.
	 * @param 	request
	 * @param 	response
	 * @throws 	ServletException
	 * @throws 	IOException
	 */
	private void doRegistrar( HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try 
		{
			String nombreReal = request.getParameter( PARAM_NOMBRE_REAL );
			String apellido = request.getParameter( PARAM_APELLIDO );
			String nombreAcceso = request.getParameter( PARAM_USERNAME );
			String claveAcceso = request.getParameter( PARAM_PASSWORD );

			boolean validos = paramsValidos( nombreReal, apellido, nombreAcceso, claveAcceso, request);

			Usuario usuario = new Usuario( null, null, nombreAcceso, null );
			
			// validar que el username no esté repetido
			List<Usuario> match = UsuarioHome.encontrarPorEjemplo( usuario );
			if ( !match.isEmpty() )
			{
				validos = false;
				FieldValueError.setFieldError( PARAM_USERNAME, "El nombre de acceso ya está en uso, por favor ingrese uno que no esté en uso ..!",
						request);
			}
			
			if( validos )
			{
				usuario.setNombreReal( nombreReal );
				usuario.setApellido( apellido );
				usuario.setNombreAcceso( nombreAcceso );
				usuario.setClaveAcceso( claveAcceso );
				
				UsuarioHome.modificaUsuario( usuario );
				
				UserNotification.addMessage( request, "Ha sido registrado satisfactoriamente ..!", Level.INFO);
				UserNotification.addMessage(request, 
						"Ahora puede obtener acceso a los recursos del Portal autenticándose mediante el enlace llamado \"Login\" ..!",
						Level.INFO);
			}
			else
			{
				UserNotification.addMessage( request, "Ha ocurrido un error, por favor verifique los datos ingresados ..!", Level.ERROR);
				setCamposDeUnUsuarioARegistrar(request, nombreReal, apellido, nombreAcceso, claveAcceso);
				request.getRequestDispatcher("do_registra_usuario.jsp").forward(request, response);
				return;
			}
		}
		catch( HibernateException e )
		{
			UserNotification.addMessage(request,
					"Ha ocurrido un error al acceder a la base de datos. Por favor comuníquelo al administrador del sitio.",
					Level.ERROR);
		}
		request.getRequestDispatcher("index.jsp").forward(request, response);
	}

	/**
	 * Método:	doEliminar
	 * 			Responsable de borrar los datos del usuario.
	 * @param 	request
	 * @param 	response
	 * @throws 	IOException
	 * @throws 	ServletException
	 */
	private void doEliminar(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String eleccionEliminaUsuario = request.getParameter( UsuarioServlet.PARAM_ELECCION_ELIMINAR_USUARIO );
		
		//Sea null, o nó, lo pongo como atributo del request para asignarlo al formulario de confirmación de eliminación del Usuario
		request.setAttribute( UsuarioServlet.PARAM_ELECCION_ELIMINAR_USUARIO, eleccionEliminaUsuario );
		
		if( eleccionEliminaUsuario == null || eleccionEliminaUsuario.equals("") )
		{
			UserNotification.addMessage(request, 
					"Debe elegir por \"SI\" o por \"NO\" ..!", Level.ERROR );
			request.getRequestDispatcher("do_elimina_usuario.jsp").forward(request, response);
		}
		if ( eleccionEliminaUsuario != null && eleccionEliminaUsuario.equals( UsuarioServlet.PARAM_NO ) )
		{
			UserNotification.addMessage(request, 
					"Sus datos NO han sido borrados, puede continuar utilizando el sitio normalmente.", Level.INFO);
			request.getRequestDispatcher("do_elimina_usuario.jsp").forward(request, response);
		}
		if ( eleccionEliminaUsuario != null && eleccionEliminaUsuario.equals( UsuarioServlet.PARAM_SI ) ) 
		{
			try 
			{
				Usuario usuario = LoginServlet.getUsuarioEnSesion( request );
				UsuarioHome.eliminaUsuario( usuario );
				UserNotification.addMessage(request, 
						"Sus datos han sido borrados satisfactoriamente del sistema.", Level.INFO);
				request.getSession().invalidate();
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}
			catch( HibernateException e )
			{
				UserNotification.addMessage(request,
					"Ha ocurrido un error al acceder a la base de datos. Por favor comuníquelo al administrador del sitio.",
					Level.ERROR);
			}
			
		}
	}

	/**
	 * Método:	doActualizar
	 * 			Responsable de actualizar los datos de usuario.
	 * @param 	request
	 * @param 	response
	 * @throws	ServletException
	 * @throws 	IOException
	 */
	private void doActualizar(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try 
		{
			String nombreReal = request.getParameter( PARAM_NOMBRE_REAL );
			String apellido = request.getParameter( PARAM_APELLIDO );
			String nombreAcceso = request.getParameter( PARAM_USERNAME );
			String claveAcceso = request.getParameter( PARAM_PASSWORD );
			
			boolean validos = paramsValidos( nombreReal, apellido, nombreAcceso, claveAcceso, request );

			Usuario usuario = LoginServlet.getUsuarioEnSesion( request );
			
			//validar que el username nuevo no esté repetido
			if( !usuario.getNombreAcceso().equals( nombreAcceso ) )
			{
				Usuario sample = new Usuario(null, null, nombreAcceso, null);
				List<Usuario> match = UsuarioHome.encontrarPorEjemplo( sample );
				if ( !match.isEmpty() )
				{
					validos = false;
					FieldValueError.setFieldError(PARAM_USERNAME, "El nombre de acceso: " + nombreAcceso + " ya está en uso, por favor seleccione uno que no esté en uso.",
							request);
				}
			}
			
			if( validos )
			{
				usuario.setNombreReal( nombreReal );
				usuario.setApellido( apellido );
				usuario.setNombreAcceso( nombreAcceso );
				usuario.setClaveAcceso( claveAcceso );
				
				UsuarioHome.modificaUsuario( usuario );
				
				UserNotification.addMessage(request, "El Perfil de Usuario ha sido modificado satisfactoriamente ..!", Level.INFO);
			}
			else
			{
				UserNotification.addMessage(request, "Ha ocurrido un error, por favor verifique los datos!", Level.ERROR);
			}
		}
		catch( HibernateException e)
		{
			UserNotification.addMessage(request, 
					"Ha ocurrido un error al acceder a la base de datos. Por favor comuníquelo al administrador del sitio.",
					Level.ERROR);
		}
		setCamposDeUsuarioEnSesion( request );
		request.getRequestDispatcher("do_modifica_usuario.jsp").forward(request, response);
	}

	/**
	 * Método:	paramsValidos
	 * 			Responsable de validar los parámetros de los formularios.
	 * @param 	nombreReal
	 * @param 	apellido
	 * @param 	nombreAcceso
	 * @param 	claveAcceso
	 * @param 	request
	 * @return
	 */
	private boolean paramsValidos( String nombreReal, String apellido, String nombreAcceso, String claveAcceso, HttpServletRequest request) 
	{
		boolean ok = true;
		if( nombreReal == null || nombreReal.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( PARAM_NOMBRE_REAL, "Este campo no puede ser vacío.", request);
		}
		if( apellido == null || apellido.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( PARAM_APELLIDO, "Este campo no puede ser vacío.", request);
		}
		if ( nombreAcceso == null || nombreAcceso.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( PARAM_USERNAME, "Este campo no puede ser vacío.", request);
		}
		if (claveAcceso == null || claveAcceso.trim().equals(""))
		{
			ok = false;
			FieldValueError.setFieldError( PARAM_PASSWORD, "Este campo no puede ser vacío.", request);
		}
		return ok;
	}

	/**
	 * Método:	doListar
	 * 			Responsable de preparar los datos necesarios para la página de edición.
	 * @param 	request
	 * @param 	response
	 * @throws 	ServletException
	 * @throws 	IOException
	 */
	private void doListar(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try 
		{
			setListaUsuarios(request);
		}
		catch( HibernateException e)
		{
			UserNotification.addMessage(request, 
					"Ha ocurrido un error al acceder a la base de datos. Por favor comuníquelo al administrador del sitio.",
					Level.ERROR);
		}
		Usuario usuario = LoginServlet.getUsuarioEnSesion(request);
		FieldValueError.setFieldValue( PARAM_NOMBRE_REAL, usuario.getNombreReal(), request );
		FieldValueError.setFieldValue( PARAM_APELLIDO, usuario.getApellido(), request );
		FieldValueError.setFieldValue( PARAM_USERNAME, usuario.getNombreAcceso(), request );
		FieldValueError.setFieldValue( PARAM_PASSWORD, usuario.getClaveAcceso(), request );
		request.getRequestDispatcher( "do_modifica_usuario.jsp" ).forward( request, response );
	}

	/**
	 * Método:	doConsultar
	 * 			Realiza una consulta HQL en la base de datos Clinica, Tabla USUARIOS de acuerdo a un
	 * 			criterio de búsqueda y un valor suministrados por los parámetros del formulario.
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	private void doConsultar( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException
	{
		String criterioBusqueda = request.getParameter( UsuarioServlet.PARAM_CRITERIO_CONSULTA );
		String valorBuscar = request.getParameter( UsuarioServlet.PARAM_VALOR_BUSCAR );
		if( criterioBusqueda != null && !criterioBusqueda.trim().equals("") && valorBuscar != null && !valorBuscar.trim().equals("") )
		{
			request.setAttribute( UsuarioServlet.PARAM_CRITERIO_CONSULTA, criterioBusqueda );
			request.setAttribute( UsuarioServlet.PARAM_VALOR_BUSCAR, valorBuscar );
			try
			{
				setListaUsuarios( request, criterioBusqueda, valorBuscar );
			}
			catch( HibernateException hex)
			{
				UserNotification.addMessage(request, 
						"Ha ocurrido un error al acceder a la base de datos. Por favor comuníquelo al administrador del sitio.",
						Level.ERROR);
			}
		}
		else
		{
			UserNotification.addMessage( request, 
					"Debe seleccionar un criterio de búsqueda y completar con el valor que desea buscar ..!",
					Level.ERROR);
		}
		setCamposDeUsuarioEnSesion(request);
		request.getRequestDispatcher( "do_modifica_usuario.jsp" ).forward( request, response );
	}
	
	/**
	 * Método auxiliar para agregar al request la lista de usuarios.
	 * 
	 * @param request
	 */
	private void setListaUsuarios(HttpServletRequest request)
	{
		String consultaHQL = "select u from Usuario as u";
		List<Usuario> listaDeUsuarios = UsuarioHome.consultaUsuarios( consultaHQL );
		request.setAttribute( LISTA_USUARIOS , listaDeUsuarios);
	}
	
	/**
	 * Método auxiliar para agregar al request la lista de todos los Usuarios registrados que cumplen con un criterio de consulta 
	 * y un valor a buscar.
	 * @param request
	 * @param criterioBusqueda
	 * @param valorBuscar
	 */
	private void setListaUsuarios( HttpServletRequest request, String criterioBusqueda, String valorBuscar )
	{
		String consultaHQL = "select u from Usuario as u ";
		if( criterioBusqueda.trim().equals( UsuarioServlet.PARAM_CRITERIO_CONSULTA_NOMBRE ) )
		{
			consultaHQL = consultaHQL + " where u.nombreReal = '" + valorBuscar + "'";
		}
		else if( criterioBusqueda.trim().equals( UsuarioServlet.PARAM_CRITERIO_CONSULTA_APELLIDO ) )
		{
			consultaHQL = consultaHQL + " where u.apellido = '" + valorBuscar + "'";
		}
		else if( criterioBusqueda.trim().equals( UsuarioServlet.PARAM_CRITERIO_CONSULTA_USERNAME ) )
		{
			consultaHQL = consultaHQL + " where u.nombreAcceso = '" + valorBuscar + "'";
		}
		List<Usuario> listaDeUsuarios = UsuarioHome.consultaUsuarios( consultaHQL );
		request.setAttribute( UsuarioServlet.LISTA_USUARIOS , listaDeUsuarios );
	}

	/**
	 * Método:	setCamposDeUsuarioEnSesion
	 * 			Completa el formulario de edición de los datos de un Usuario, extrayendo los datos desde
	 * 			la HttpSession con LoginServlet.getUsuarioEnSesion(request).
	 * 
	 * @param request
	 */
	private void setCamposDeUsuarioEnSesion(HttpServletRequest request)
	{
		Usuario usuario = LoginServlet.getUsuarioEnSesion(request);
		FieldValueError.setFieldValue( PARAM_NOMBRE_REAL, usuario.getNombreReal(), request );
		FieldValueError.setFieldValue( PARAM_APELLIDO, usuario.getApellido(), request );
		FieldValueError.setFieldValue( PARAM_USERNAME, usuario.getNombreAcceso(), request );
		FieldValueError.setFieldValue( PARAM_PASSWORD, usuario.getClaveAcceso(), request );
	}
	
	/**
	 * Método:	setCamposDeUnUsuarioARegistrar
	 * 			Completa el formulario de la página: do_registra_usuario.jsp con los datos de un Usuario 
	 * 			que se va a registrar en el portal.
	 * @param request
	 * @param nombreReal
	 * @param apellido
	 * @param nombreAcceso
	 * @param claveAcceso
	 */
	private void setCamposDeUnUsuarioARegistrar( HttpServletRequest request, String nombreReal, String apellido, String nombreAcceso, String claveAcceso )
	{
		FieldValueError.setFieldValue( PARAM_NOMBRE_REAL, nombreReal, request );
		FieldValueError.setFieldValue( PARAM_APELLIDO, apellido, request );
		FieldValueError.setFieldValue( PARAM_USERNAME, nombreAcceso, request );
		FieldValueError.setFieldValue( PARAM_PASSWORD, claveAcceso, request );
	}
 }