package dbServlets;

import java.io.IOException;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import utility.FechaUtil;
import utility.FieldValueError;
import utility.UserNotification;
import utility.UserNotification.Level;
import clinica.Diagnostico;
import clinica.DiagnosticoHome;
import clinica.Paciente;
import clinica.PacienteHome;
import clinica.Usuario;

/**
 * Servlet implementation class for Servlet: DiagnosticoServlet
 *
 */
 public class DiagnosticoServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
 {
	 public static final String ACCION_LISTAR 									= "listar";
	 public static final String ACCION_CONSULTAR 								= "consultar";
	 public static final String ACCION_ACTUALIZAR 								= "actualizar";
	 public static final String ACCION_BORRAR 									= "borrar";
	 public static final String ACCION_GUARDAR 									= "guardar";
	 public static final String ACCION_SELECCIONAR_PACIENTE 					= "seleccionarPaciente";
	 public static final String ACCION_SELECCIONAR_DIAGNOSTICO_PARA_ACTUALIZAR 	= "seleccionarDiagnosticoParaActualizar";
	 
	 public static final String PARAM_TIPO_DOCUMENTO 	= "tipoDeDocumento";
	 public static final String PARAM_NRO_DOCUMENTO 	= "numeroDeDocumento";
	 public static final String PARAM_ANIO 				= "anio";
	 public static final String PARAM_MES 				= "mes";
	 public static final String PARAM_DIA 				= "dia";
	 public static final String PARAM_DESCRIPCION		= "descripcion";
	 public static final String PARAM_ID_DIAGNOSTICO	= "idDiagnostico";
	 
	 public static final String PACIENTE				= "paciente";
	 public static final String DIAGNOSTICO				= "diagnostico";
	 public static final String LISTA_DE_DIAGNOSTICOS	= "listaDeDiagnosticos";
	 
	 public static final String PARAM_SELECTOR_TIPO_DE_DOCUMENTO 		= "selectorTipoDeDocumento";
	 public static final String PARAM_SELECTOR_TIPO_DE_DOCUMENTO_DNI 	= "DNI";
	 public static final String PARAM_SELECTOR_TIPO_DE_DOCUMENTO_LC 	= "LC";
	 public static final String PARAM_SELECTOR_TIPO_DE_DOCUMENTO_LE 	= "LE";
	 public static final String PARAM_SELECTOR_NUMERO_DE_DOCUMENTO 		= "selectorNumeroDocumento";
	 public static final String PARAM_SELECTOR_DIAGNOSTICO				= "selectorDiagnostico";
	 
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public DiagnosticoServlet() 
	{
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String accion = request.getParameter( PacienteServlet.PARAM_ACCION );
		/*if( accion == null )
		*{
		*	accion = ACCION_LISTAR;
		*}
		*/
		
		//validar que el usuario está autenticado
		Usuario usuario = LoginServlet.getUsuarioEnSesion( request );
		if( !UsuarioServlet.ACCION_REGISTRAR.equals( accion ) && usuario == null )
		{
			UserNotification.addMessage(request, 
					"Está intentando acceder a un recurso restringido para el cual necesita estar autenticado, " +
					"por favor regístrese o acceda con su username y su password ..!",
					Level.ERROR);
			request.getRequestDispatcher("index.jsp").forward(request, response);
			return;
		}
		
		//el procesamiento se realiza según el valor del parámetro "accion"
		if( ACCION_LISTAR.equals( accion ) ) 
		{
			doListar( request, response );
		}
		else if( ACCION_CONSULTAR.equals( accion ) )
		{
			doConsultar( request, response);
		}
		else if( ACCION_ACTUALIZAR.equals( accion ) )
		{
			doActualizar( request, response );
		}
		else if( ACCION_BORRAR.equals( accion ) )
		{
			doEliminar( request, response );
		}
		else if( ACCION_GUARDAR.equals( accion ) )
		{
			doGuardar( request, response );
		}
		else if( ACCION_SELECCIONAR_PACIENTE.equals( accion ) )
		{
			doSeleccionarPaciente( request, response , "do_modifica_diagnostico.jsp" );
		}
		else if( ACCION_SELECCIONAR_DIAGNOSTICO_PARA_ACTUALIZAR.equals( accion ) )
		{
			doSeleccionarDiagnostico( request, response, "do_modifica_diagnostico.jsp" );
		}
	}
	
	/**
	 * Método:	setCamposDeDiagnostico
	 * 			Método auxiliar para completar los campos del formulario de edición de los datos referidos a un Diagnóstico.
	 * @param request
	 * @param tipoDeDocumento
	 * @param numeroDeDocumento
	 * @param anio
	 * @param mes
	 * @param dia
	 * @param descripcion
	 */
	private void setCamposDeDiagnostico( HttpServletRequest request, String tipoDeDocumento, String numeroDeDocumento,
			String anio, String mes, String dia, String descripcion )
	{
		FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_TIPO_DOCUMENTO, tipoDeDocumento, request );
		FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_NRO_DOCUMENTO, numeroDeDocumento, request );
		FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_ANIO, anio, request );
		FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_MES, mes, request );
		FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_DIA, dia, request );
		FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_DESCRIPCION, descripcion, request );
	}
	
	private void setCamposDeDiagnostico( HttpServletRequest request, Diagnostico diagnostico , Paciente paciente )
	{
		if( paciente != null && diagnostico != null )
		{
			FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_TIPO_DOCUMENTO, paciente.getTpoDoc(), request );
			FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_NRO_DOCUMENTO, String.valueOf( paciente.getNroDoc() ), request );
			
			Date fecha = diagnostico.getFecha();
			String anio = FechaUtil.getAnioFromDateToStr( fecha );
			String mes	= FechaUtil.getMesFromDateToStr( fecha );
			String dia 	= FechaUtil.getDiaFromDateToStr( fecha );
			
			FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_ANIO, anio, request );
			FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_MES, mes, request );
			FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_DIA, dia, request );
			
			FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_DESCRIPCION, diagnostico.getDescripcion(), request );
		}
	}
	
	/**
	 * Método:	paramsValidos
	 * 			Responsable de validar los parámetros de los formularios.
	 * @param 	tipoDeDocumento
	 * @param 	numeroDeDocumento
	 * @param 	anio
	 * @param 	mes
	 * @param 	dia
	 * @param 	descripcion
	 * @param 	request
	 * @return	ok
	 */
	private boolean paramsValidos( String tipoDeDocumento, String numeroDeDocumento, String anio, String mes, String dia, String descripcion,
			HttpServletRequest request )
	{
		boolean ok = true;
		
		if( tipoDeDocumento == null || tipoDeDocumento.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( DiagnosticoServlet.PARAM_TIPO_DOCUMENTO, "Debe seleccionar uno de los Tipos de Documentos: DNI o LC o LE ..!", request);
		}
		if( numeroDeDocumento == null || numeroDeDocumento.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( DiagnosticoServlet.PARAM_NRO_DOCUMENTO, "Este campo no puede ser vacío ..!", request);
		}
		if( anio == null || anio.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( DiagnosticoServlet.PARAM_ANIO, "Este campo no puede ser vacío ..!", request);
		}
		if( mes == null || mes.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( DiagnosticoServlet.PARAM_MES, "Este campo no puede ser vacío ..!", request);
		}
		if( dia == null || dia.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( DiagnosticoServlet.PARAM_DIA, "Este campo no puede ser vacío ..!", request);
		}
		if( descripcion == null || descripcion.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( DiagnosticoServlet.PARAM_DESCRIPCION, "Este campo no puede ser vacío ..!", request);
		}
		
		return ok;
	}
	
	/**
	 * Método:	doGuardar
	 * 			Responsable de almacenar el Diagnóstico de un Paciente. Obtiene el Paciente a partir de una consulta HQL
	 * 			por Tipo y Número de Documento. En caso de que el Paciente sigue con vida puede almacenar un Diagnóstico.
	 * 			En caso que el Paciente ha fallecido no puede almacenar el Diagnóstico.
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	private void doGuardar( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException
	{
		//Toma los parámetros del request del formulario de alta de Diagnóstico de un Paciente
		//Para averiguar el Paciente toma Tipo y Número de Documento => obtiene el Paciente mediante una Consulta
		String tipoDeDocumento		= request.getParameter( DiagnosticoServlet.PARAM_TIPO_DOCUMENTO );
		String numeroDeDocumento	= request.getParameter( DiagnosticoServlet.PARAM_NRO_DOCUMENTO );
		String anio					= request.getParameter( DiagnosticoServlet.PARAM_ANIO );
		String mes					= request.getParameter( DiagnosticoServlet.PARAM_MES );
		String dia					= request.getParameter( DiagnosticoServlet.PARAM_DIA );
		String descripcion			= request.getParameter( DiagnosticoServlet.PARAM_DESCRIPCION );
		
		//Para la consulta HQL por Tipo y Número de Documento. Debe chequear si Paciente está registrado o nó. Obtiene el Paciente.
		String consultaHQL = "";
		List<Paciente> listaDePacientes = null;
		Paciente paciente;
		
		/* Como registra por primera vez, puede usar new para instanciar un objeto Diagnostico 
		 * ya que proporciona un idDiagnostico incremental diferente  */
		
		Diagnostico diagnostico = new Diagnostico( null, null, null );
		
		boolean validos = paramsValidos( tipoDeDocumento, numeroDeDocumento, anio, mes, dia, descripcion, request );
		
		// verifica que la fecha del Diagnóstico sea una fecha correcta
		String fechaStr = anio + "-" + mes + "-" + dia;
		Date fecha = FechaUtil.validaFecha( request, fechaStr );
		if( fecha == null )
		{
			validos = false;
			FieldValueError.setFieldError( DiagnosticoServlet.PARAM_DIA, "Debe seleccionar una Fecha que sea válida ..!", request);
		}		
		
		// verifica que haya un Paciente registrado con ese tipo y número de documento
		if( tipoDeDocumento != null && !tipoDeDocumento.trim().equals("") && numeroDeDocumento != null && !numeroDeDocumento.trim().equals("") )
		{
			consultaHQL = "select p from Paciente as p where p.tpoDoc = '" + tipoDeDocumento + "' and p.nroDoc = '" + numeroDeDocumento + "'";
			
			listaDePacientes = PacienteHome.consultaPacientes( consultaHQL );
			
			if( listaDePacientes == null || listaDePacientes.isEmpty() || listaDePacientes.size() > 1 )
			{
				validos = false;
				FieldValueError.setFieldError( DiagnosticoServlet.PARAM_NRO_DOCUMENTO ,
					"El Tipo y Número de Documento que ha ingresado NO CORRESPONDEN con ninguno de los Pacientes registrados en la base de datos.",
					request );
			}
		}
		
		if( validos )
		{
			try
			{
				if( listaDePacientes != null && listaDePacientes.size() == 1 )
				{
					paciente = listaDePacientes.get(0);
					
					if( paciente.isEstaVivo() == true )
					{
						diagnostico.setPaciente( paciente );
						diagnostico.setFecha( fecha );
						diagnostico.setDescripcion( descripcion );
					
						DiagnosticoHome.modificaDiagnostico( diagnostico );
					
						UserNotification.addMessage( request, 
							"El Diagnóstico ha sido almacenado satisfactoriamente en la Base de Datos.", 
							UserNotification.Level.INFO );
					
						request.getRequestDispatcher( "gestor_pacientes_diagnosticos.jsp" ).forward(request, response);
					}
					else
					{
						UserNotification.addMessage( request, 
								"Error: No puede registrar el Diagnóstico a un Paciente que ha fallecido ..!", 
								UserNotification.Level.ERROR);
						setCamposDeDiagnostico( request, tipoDeDocumento, numeroDeDocumento, anio, mes, dia, descripcion );
						request.getRequestDispatcher( "do_alta_diagnostico.jsp" ).forward( request, response );
					}
				}
			}
			catch( HibernateException hex )
			{
				UserNotification.addMessage( request, 
						"Ha ocurrido un error al acceder a la base de datos. Por favor comuníquelo al administrador del Sitio.", 
						UserNotification.Level.ERROR );
				setCamposDeDiagnostico( request, tipoDeDocumento, numeroDeDocumento, anio, mes, dia, descripcion );
				request.getRequestDispatcher( "do_alta_diagnostico.jsp" ).forward( request, response );
			}
		}
		else
		{
			UserNotification.addMessage( request, "Ha ocurrido un error, por favor verifique los datos ingresados.", UserNotification.Level.ERROR );
			setCamposDeDiagnostico( request, tipoDeDocumento, numeroDeDocumento, anio, mes, dia, descripcion );
			request.getRequestDispatcher( "do_alta_diagnostico.jsp" ).forward( request, response );
		}
	}
	
	/**
	 * Método:	doSeleccionarPaciente
	 * 			Responsable de seleccionar un Paciente a partir de una consulta HQL por Tipo y Número de Documento
	 * 			en la Tabla: Clinica.PACIENTES.
	 * 			Asigna los campos Tipo y Número de Documento para el formulario selector de Pacientes.
	 * 			Pasa el Paciente seleccionado como atributo del request a la "urlDestino".
	 * 			Obtiene la lista de Diagnósticos del Paciente mediante otra consulta HQL por Id de Paciente
	 * 			en la Tabla: Clinica.DIAGNOSTICOS y la pasa como atributo del request a la "urlDestino".
	 * @param request
	 * @param response
	 * @param urlDestino
	 * @throws ServletException
	 * @throws IOException
	 */
	private void doSeleccionarPaciente( HttpServletRequest request, HttpServletResponse response , String urlDestino ) throws ServletException, IOException
	{
		String tipoDeDocumento 		= request.getParameter( DiagnosticoServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO );
		String numeroDeDocumento	= request.getParameter(DiagnosticoServlet.PARAM_SELECTOR_NUMERO_DE_DOCUMENTO );
		
		//asigna los campos Tipo y Número de Documento para el formulario selector de Pacientes 
		FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO, tipoDeDocumento, request);
		FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_SELECTOR_NUMERO_DE_DOCUMENTO, numeroDeDocumento, request);
		
		String consultaHQL = "";
		String consultaHQLDiag = "";
		List<Paciente> listaDePacientes = null;
		List<Diagnostico> listaDeDiagnosticos = null;
		Paciente paciente = null;
		
		boolean validos = true;
		// verifica el Tipo de Documento
		if( tipoDeDocumento == null || tipoDeDocumento.trim().equals("") )
		{
			validos = false;
			FieldValueError.setFieldError( DiagnosticoServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO, 
				"Debe seleccionar un Tipo de Documento: DNI o LC o LE ..!", request);
		}
		//verifica el Número de Documento
		if( numeroDeDocumento == null || numeroDeDocumento.trim().equals("") )
		{
			validos = false;
			FieldValueError.setFieldError( DiagnosticoServlet.PARAM_SELECTOR_NUMERO_DE_DOCUMENTO, 
				"Debe ingresar un Número de Documento (sin puntos) ..!", request);
		}
		
		if( validos )
		{
			consultaHQL = "select p from Paciente as p where p.tpoDoc = '" + tipoDeDocumento + "' and p.nroDoc = '" + numeroDeDocumento + "'";
			try
			{
				listaDePacientes = PacienteHome.consultaPacientes( consultaHQL );
				if( listaDePacientes != null &&  listaDePacientes.size() == 1 )
				{
					paciente = listaDePacientes.get(0);
					/* Si trato de obtener el set de Diagnósticos mediante:
					 * 
					 * 	setDeDiagnosticos = paciente.getDiagnosticos();
					 * 
					 *  Obtengo la siguiente Excepción:
					 *  
					 *  	org.hibernate.LazyInitializationException: failed to lazily initialize a collection of role: 
					 *  	clinica.Paciente.diagnosticos, no session or session was closed
					 */
					/*
					 * Si trato de obtener el set de Diagnósticos mediante un método donde previamente abro una sesion de HibernateSession 
					 * también obtengo la misma excepción: 
					 * 
					 * setDeDiagnosticos = PacienteHome.obtenerSetDeDiagnosticos( paciente );
					 * 
					 * Por este motivo este método: obtenerSetDeDiagnosticos ha sido eliminado de PacienteHome
					 */
					
					/* obtiene el set De Diagnosticos del Paciente mediante otra consulta HQL 
					 * porque al usar el método getDiagnosticos() ocurre una excepción	*/
					consultaHQLDiag = "select d from Diagnostico as d where d.paciente.idPaciente ='" + 
						String.valueOf( paciente.getIdPaciente() ) + "'";
					listaDeDiagnosticos = DiagnosticoHome.consultaDiagnosticos( consultaHQLDiag );
					
					request.setAttribute( DiagnosticoServlet.PACIENTE, paciente );
					request.setAttribute( DiagnosticoServlet.LISTA_DE_DIAGNOSTICOS, listaDeDiagnosticos );
				}
				else
				{
					UserNotification.addMessage( request, 
							"El Tipo y Número de Documento que ha introducido no corresponde a un Paciente registrado en la Base de Datos. <BR />" +
							"Por favor verifique los datos ingresados e intente nuevamente. <BR />",
							Level.ERROR);
				}
			}
			catch( HibernateException hex)
			{
				UserNotification.addMessage( request, 
						"Ha ocurrido un error al acceder a la base de datos. Por favor comuníquelo al administrador del Sitio.",
						Level.ERROR);
			}
		}
		else
		{
			UserNotification.addMessage( request, 
					"Debe ingresar un Tipo y Número de Documento en el selector de Pacientes ..!",
					Level.ERROR);
		}
		request.getRequestDispatcher( urlDestino ).forward( request, response );
	}
	
	/**
	 * Método:	doSeleccionarDiagnostico
	 * 			Responsable de Seleccionar un Diagnóstico a partir de un Id de Diagnóstico, que obtiene como parámetros del request, y
	 * 			una lista de Diagnósticos, que obtiene como atributo de la HttpSession.
	 * 			Asigna el campo para el formulario de selección de Diagnósticos de un Paciente.
	 * 			Pasa la lista de Diagnósticos como atributo del request.
	 * 			Obtiene el paciente como atributo del HttpSession, para evitar otra consulta a la base de datos, y
	 * 			pasa el paciente como atributo del request.
	 * 			A partir del paciente obtiene el tipo y número de Documento y los asigna al formulario selector de Pacientes.
	 * 			Asigna el campo oculto en el formulario de edición de los datos del Diagnóstico.
	 * 			Una vez que obtiene el diagnóstico de la lista de diagnósticos, pasa el diagnostico a la urlDestino 
	 * 			pasa el diagnostico a urlDestino como atributo del request y asigna los campos del formulario de edición de los datos del Diagnóstico.
	 * @param request
	 * @param response
	 * @param urlDestino
	 * @throws ServletException
	 * @throws IOException
	 */
	private void doSeleccionarDiagnostico( HttpServletRequest request, HttpServletResponse response , String urlDestino ) throws ServletException, IOException
	{
		//Toma del request el parámetro del formulario de selección de Diagnósticos: el id de Diagnóstico
		String idDiagnostico = request.getParameter( DiagnosticoServlet.PARAM_SELECTOR_DIAGNOSTICO );
		//asigna el campo para el formulario de selección de Diagnósticos de un Paciente
		FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_SELECTOR_DIAGNOSTICO, idDiagnostico, request);
		
		//obtiene la lista de Diagnósticos como atributo del HttpSession para evitar otra consulta a la base de datos
		List<Diagnostico> listaDeDiagnosticos = (List<Diagnostico>) request.getSession().getAttribute( DiagnosticoServlet.LISTA_DE_DIAGNOSTICOS );
		// pasa la lista de Diagnósticos como atributo del request
		request.setAttribute( DiagnosticoServlet.LISTA_DE_DIAGNOSTICOS, listaDeDiagnosticos );
		
		// obtiene el Paciente como atributo del HttpSession para evitar otra consulta a la base de datos
		Paciente paciente = (Paciente)request.getSession().getAttribute( DiagnosticoServlet.PACIENTE );
		//pasa el paciente como atributo del request 
		request.setAttribute( DiagnosticoServlet.PACIENTE, paciente );
		
		String tipoDeDocumento 		= paciente.getTpoDoc();
		//asigna el campo tipo de documento para el formulario selector de Paciente
		FieldValueError.setFieldValue(DiagnosticoServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO, tipoDeDocumento, request);
		
		int numeroDeDocumentoNro	= paciente.getNroDoc();
		String numeroDeDocumento	= String.valueOf( numeroDeDocumentoNro );
		// asigna el campo número de documento para el formulario selector de Paciente
		FieldValueError.setFieldValue(DiagnosticoServlet.PARAM_SELECTOR_NUMERO_DE_DOCUMENTO, numeroDeDocumento, request);
		
		if( idDiagnostico != null && !idDiagnostico.trim().equals("") && listaDeDiagnosticos != null )
		{
			//asigna el campo oculto en el formulario de edición de los datos del Diagnóstico
			FieldValueError.setFieldValue(DiagnosticoServlet.PARAM_ID_DIAGNOSTICO, idDiagnostico, request);
			
			//Busca en el Set el Diagnóstico con ese idDiagnostico
			int idDiagnosticoNro = Integer.parseInt( idDiagnostico );
			Iterator<Diagnostico> iteradorDeDiagnosticos = listaDeDiagnosticos.iterator();
			Diagnostico diagnostico = null;
			Diagnostico temp = null;
			while( iteradorDeDiagnosticos.hasNext() )
			{
				temp = iteradorDeDiagnosticos.next();
				if( temp.getIdDiagnostico() == idDiagnosticoNro )
				{
					diagnostico = temp;
				}
			}
			
			// pasa el diagnostico a urlDestino como atributo del request  
			request.setAttribute( DiagnosticoServlet.DIAGNOSTICO , diagnostico ); //antes
			
			//asigna los campos del formulario de edición de los datos del Diagnóstico
			setCamposDeDiagnostico(request, diagnostico, paciente);
		}
		else
		{
			UserNotification.addMessage(request, "Debe seleccionar uno de los Diagnósticos del Paciente ..!", UserNotification.Level.ERROR );
		}
		request.getRequestDispatcher( urlDestino ).forward(request, response);
	}
	
	private void doListar( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException
	{
		
	}
	
	private void doConsultar( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException
	{
		
	}
	/**
	 * Método:	doActualizar
	 * 			Responsable de realizar la actualización del diagnóstico de un paciente en la base de datos.
	 * 			Toma los parámetros del formulario de edición de los datos del Diagnóstico.
	 * 			Obtiene el diagnóstico como atributo del HttpSession, para evitar otra consulta a la base de datos.
	 * 			Obtiene el Paciente dueño del Diagnóstico como atributo del HttpSession para evitar otra consulta a la base de datos.
	 * 			Obtiene la lista de Diagnósticos como atributo del HttpSession para evitar otra consulta a la base de datos.
	 * 			En caso de realizar la modificación satisfactoriamente remueve del HttpSession los siguientes atributos:
	 * 			- el paciente
	 * 			- la lista de diagnósticos del paciente
	 * 			- el diagnostico seleccionado para modificar
	 * 			- redirige la respuesta hacia: gestor_pacientes_diagnosticos.jsp
	 * 			En caso contrario:
	 * 			- asigna los campos del formulario de edición de los datos del Diagnóstico de un paciente
	 * 			- asigna el campo oculto (hidden) del formulario de edición de los datos del Diagnóstico de un paciente
	 * 			- pasa como atributo del request al diagnóstico
	 * 			- asigna el campo para el formulario de selección de Diagnósticos de un Paciente
	 * 			- pasa la lista de Diagnósticos como atributo del request
	 * 			- pasa el paciente como atributo del request
	 * 			- asigna el campo tipo de documento para el formulario selector de Paciente
	 * 			- asigna el campo número de documento para el formulario selector de Paciente
	 * 			- redirige la respuesta hacia: do_modifica_diagnostico.jsp
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	private void doActualizar( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException
	{	
		//Toma los parámetros del formulario de edición de los datos del Diagnóstico
		String tipoDeDocumento 		= request.getParameter( DiagnosticoServlet.PARAM_TIPO_DOCUMENTO );
		String numeroDeDocumento	= request.getParameter( DiagnosticoServlet.PARAM_NRO_DOCUMENTO );
		String anio 				= request.getParameter( DiagnosticoServlet.PARAM_ANIO );
		String mes 					= request.getParameter( DiagnosticoServlet.PARAM_MES );
		String dia 					= request.getParameter( DiagnosticoServlet.PARAM_DIA );
		String descripcion 			= request.getParameter( DiagnosticoServlet.PARAM_DESCRIPCION );
		
		String idDiagnostico 		= request.getParameter( DiagnosticoServlet.PARAM_ID_DIAGNOSTICO );
		
		// obtiene el diagnóstico como atributo del HttpSession, para evitar otra consulta a la base de datos
		Diagnostico diagnostico = (Diagnostico)request.getSession().getAttribute( DiagnosticoServlet.DIAGNOSTICO );
		
		// obtiene el Paciente dueño del Diagnóstico como atributo del HttpSession para evitar otra consulta a la base de datos
		Paciente paciente = (Paciente)request.getSession().getAttribute( DiagnosticoServlet.PACIENTE );

		// obtiene la lista de Diagnósticos como atributo del HttpSession para evitar otra consulta a la base de datos
		List<Diagnostico> listaDeDiagnosticos = (List<Diagnostico>) request.getSession().getAttribute( DiagnosticoServlet.LISTA_DE_DIAGNOSTICOS );
		
		boolean validos = paramsValidos( tipoDeDocumento, numeroDeDocumento, anio, mes, dia, descripcion, request );
		// verifica el campo oculto idDiagnostico
		if( idDiagnostico == null || idDiagnostico.trim().equals("") )
		{
			validos = false;
		}
		//verifica la fecha
		String fechaStr = anio + "-" + mes + "-" + dia;
		Date fecha = FechaUtil.validaFecha( request, fechaStr );
		if( fecha == null )
		{
			validos = false;
			FieldValueError.setFieldError(DiagnosticoServlet.PARAM_DIA, "Debe seleccionar una fecha que sea válida ..!", request);
		}
		
		if( validos )
		{
			//actualiza
			if( diagnostico != null )
			{
				try
				{
					diagnostico.setIdDiagnostico( Integer.parseInt( idDiagnostico ) );
					diagnostico.setFecha( fecha );
					diagnostico.setDescripcion( descripcion );
					diagnostico.setPaciente( paciente );
					
					DiagnosticoHome.modificaDiagnostico( diagnostico );
					
					UserNotification.addMessage(request, 
							"El diagnóstico ha sido modificado satisfactoriamente en la base de datos.", UserNotification.Level.INFO);
					
					// Una vez que almacena el diagnóstico puede eliminar los atributos del HttpSession: paciente, listaDeDiagnosticos, diagnostico
					request.getSession().removeAttribute( DiagnosticoServlet.PACIENTE );
					request.getSession().removeAttribute( DiagnosticoServlet.LISTA_DE_DIAGNOSTICOS );
					request.getSession().removeAttribute( DiagnosticoServlet.DIAGNOSTICO );
					
					//redirige la respuesta hacia gestor_pacientes_diagnosticos.jsp
					request.getRequestDispatcher( "gestor_pacientes_diagnosticos.jsp" ).forward(request, response);
				}
				catch( HibernateException hex)
				{
					UserNotification.addMessage(request, "Ha ocurrido un error al acceder a la base de datos.<BR />" +
							"Por favor comuníquelo al administrador del sitio.<BR />", UserNotification.Level.ERROR );
					
					// asigna los campos del formulario de edición de los datos del Diagnóstico de un paciente
					setCamposDeDiagnostico( request, tipoDeDocumento, numeroDeDocumento, anio, mes, dia, descripcion );
					
					// asigna el campo oculto (hidden) del formulario de edición de los datos del Diagnóstico de un paciente
					FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_ID_DIAGNOSTICO, idDiagnostico, request );
					
					// pasa como atributo del request al diagnóstico
					request.setAttribute( DiagnosticoServlet.DIAGNOSTICO, diagnostico );
					
					// asigna el campo para el formulario de selección de Diagnósticos de un Paciente
					FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_SELECTOR_DIAGNOSTICO, idDiagnostico, request);
					
					// pasa la lista de Diagnósticos como atributo del request
					request.setAttribute( DiagnosticoServlet.LISTA_DE_DIAGNOSTICOS, listaDeDiagnosticos );
					
					// pasa el paciente como atributo del request 
					request.setAttribute( DiagnosticoServlet.PACIENTE, paciente );
					
					// asigna el campo tipo de documento para el formulario selector de Paciente
					FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO, tipoDeDocumento, request );
					
					// asigna el campo número de documento para el formulario selector de Paciente
					FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_SELECTOR_NUMERO_DE_DOCUMENTO, numeroDeDocumento, request );
					
					// redirige la respuesta hacia do_modifica_diagnostico.jsp
					request.getRequestDispatcher( "do_modifica_diagnostico.jsp" ).forward(request, response);
				}
			}
			
		}
		else
		{
			UserNotification.addMessage(request, "Ha ocurrido un error, por favor verifique los datos ingresados ..!", UserNotification.Level.ERROR );
			
			// asigna los campos del formulario de edición de los datos del Diagnóstico de un paciente
			setCamposDeDiagnostico( request, tipoDeDocumento, numeroDeDocumento, anio, mes, dia, descripcion );
						
			// asigna el campo oculto (hidden) del formulario de edición de los datos del Diagnóstico de un paciente
			FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_ID_DIAGNOSTICO, idDiagnostico, request );
			
			// pasa como atributo del request al diagnóstico
			request.setAttribute( DiagnosticoServlet.DIAGNOSTICO, diagnostico );
			
			// asigna el campo para el formulario de selección de Diagnósticos de un Paciente
			FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_SELECTOR_DIAGNOSTICO, idDiagnostico, request);
			
			// pasa la lista de Diagnósticos como atributo del request
			request.setAttribute( DiagnosticoServlet.LISTA_DE_DIAGNOSTICOS, listaDeDiagnosticos );
			
			//pasa el paciente como atributo del request 
			request.setAttribute( DiagnosticoServlet.PACIENTE, paciente );
			
			// asigna el campo tipo de documento para el formulario selector de Paciente
			FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO, tipoDeDocumento, request );
			
			// asigna el campo número de documento para el formulario selector de Paciente
			FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_SELECTOR_NUMERO_DE_DOCUMENTO, numeroDeDocumento, request );
			
			// redirige la respuesta hacia do_modifica_diagnostico.jsp
			request.getRequestDispatcher( "do_modifica_diagnostico.jsp" ).forward(request, response);
		}
	}
	
	private void doEliminar(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
	}
}