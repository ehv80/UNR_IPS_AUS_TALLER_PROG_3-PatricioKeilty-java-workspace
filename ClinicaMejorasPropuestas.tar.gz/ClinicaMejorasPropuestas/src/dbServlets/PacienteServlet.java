package dbServlets;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import utility.FechaUtil;
import utility.FieldValueError;
import utility.UserNotification;
import utility.UserNotification.Level;
import clinica.Diagnostico;
import clinica.DiagnosticoHome;
import clinica.Paciente;
import clinica.PacienteHome;
import clinica.Usuario;

/**
 * Servlet implementation class for Servlet: PacienteServlet
 * @author ehv80
 */
 public class PacienteServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
 {
	 public static final String PARAM_NOMBRE = "nombre";
	 public static final String PARAM_APELLIDO = "apellido";
	 public static final String PARAM_ANIO_NACIMIENTO = "anioNacimiento";
	 public static final String PARAM_MES_NACIMIENTO = "mesNacimiento";
	 public static final String PARAM_DIA_NACIMIENTO = "diaNacimiento";
	 public static final String PARAM_TIPO_DOCUMENTO = "tipoDeDocumento";
	 public static final String PARAM_NRO_DOCUMENTO = "numeroDeDocumento";
	 public static final String PARAM_OBRA_SOCIAL = "obraSocial";
	 public static final String PARAM_SEXO = "sexo";
	 public static final String PARAM_ESTA_VIVO = "estaVivo";
	 
	 public static final String PARAM_TIPO_DOCUMENTO_ANTERIOR = "tipoDeDocumentoAnterior";
	 public static final String PARAM_NRO_DOCUMENTO_ANTERIOR = "numeroDeDocumentoAnterior";
	 public static final String PARAM_ID_PACIENTE_ANTERIOR = "idPacienteAnterior";
	 
	 public static final String PARAM_CRITERIO_CONSULTA = "selectorCriterioConsulta";
	 public static final String PARAM_CRITERIO_CONSULTA_NOMBRE = "Nombre";
	 public static final String PARAM_CRITERIO_CONSULTA_APELLIDO = "Apellido";
	 public static final String PARAM_CRITERIO_CONSULTA_FECHA_NACIMIENTO = "Fecha de Nacimiento [Nota: YYYY-MM-DD ]";
	 public static final String PARAM_CRITERIO_CONSULTA_TIPO_DOCUMENTO = "Tipo de Documento [Nota: DNI o LC o LE ]";
	 public static final String PARAM_CRITERIO_CONSULTA_NUMERO_DOCUMENTO = "Nro. de Documento [Nota: sin los puntos]";
	 public static final String PARAM_CRITERIO_CONSULTA_OBRA_SOCIAL = "Obra Social";
	 public static final String PARAM_CRITERIO_CONSULTA_SEXO = "Sexo [Nota: F=femenino , M=masculino ]";
	 public static final String PARAM_CRITERIO_CONSULTA_ESTA_VIVO = "Esta con Vida [Nota: 1 indica Paciente vivo]";
	 
	 public static final String PARAM_VALOR_BUSCAR = "valorBuscar";
	 
	 public static final String PARAM_PACIENTE = "paciente";
	 
	 public static final String PARAM_SELECTOR_TIPO_DE_DOCUMENTO = "selectorTipoDeDocumento";
	 public static final String PARAM_TIPO_DE_DOCUMENTO_DNI = "DNI";
	 public static final String PARAM_TIPO_DE_DOCUMENTO_LC = "LC";
	 public static final String PARAM_TIPO_DE_DOCUMENTO_LE = "LE";
	 public static final String PARAM_NUMERO_DE_DOCUMENTO_A_BUSCAR = "numeroDeDocumentoABuscar";
	 	 
	 public static final String PARAM_ELECCION_ELIMINAR_PACIENTE = "eleccionEliminarPaciente";
	 public static final String PARAM_SI = "SI";
	 public static final String PARAM_NO = "NO";
	 
	 public static final String LISTA_PACIENTES = "lista_pacientes";
	 
	 public static final String PARAM_ACCION = "accion";
	 public static final String ACCION_BORRAR = "borrar";
	 public static final String ACCION_ACTUALIZAR = "actualizar";
	 public static final String ACCION_LISTAR = "listar";
	 public static final String ACCION_GUARDAR = "guardar";
	 public static final String ACCION_CONSULTAR = "consultar";
	 public static final String ACCION_SELECCIONAR_PACIENTE_PARA_ACTUALIZAR = "seleccionarPacienteParaActualizar";
	 public static final String ACCION_SELECCIONAR_PACIENTE_PARA_BORRAR = "seleccionarPacienteParaBorrar";
	 
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public PacienteServlet() 
	{
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String accion = request.getParameter( PacienteServlet.PARAM_ACCION );
		
		//validar que el usuario está autenticado
		Usuario usuario = LoginServlet.getUsuarioEnSesion( request );
		if( !UsuarioServlet.ACCION_REGISTRAR.equals( accion ) && usuario == null )
		{
			UserNotification.addMessage(request, 
					"Está intentando acceder a un recurso restringido para el cual necesita estar autenticado, por favor regístrese o acceda con su username y su password ..!",
					Level.ERROR);
			request.getRequestDispatcher("index.jsp").forward(request, response);
			return;
		}
		
		//el procesamiento se realiza según el valor del parámetro "accion"
		if( ACCION_LISTAR.equals( accion ) ) 
		{
			doListar( request, response );
		}
		else if( ACCION_CONSULTAR.equals( accion ) )
		{
			doConsultar( request, response);
		}
		else if( ACCION_ACTUALIZAR.equals( accion ) )
		{
			doActualizar( request, response );
		}
		else if( ACCION_BORRAR.equals( accion ) )
		{
			doEliminar( request, response );
		}
		else if( ACCION_GUARDAR.equals( accion ) )
		{
			doRegistrar( request, response );
		}
		else if( ACCION_SELECCIONAR_PACIENTE_PARA_ACTUALIZAR.equals( accion ) )
		{
			doSeleccionar( request, response , "do_modifica_paciente.jsp");
		}
		else if( ACCION_SELECCIONAR_PACIENTE_PARA_BORRAR.equals( accion ) )
		{
			doSeleccionar( request, response, "do_elimina_paciente.jsp" );
		}
	}
	
	/**
	 * Método:	doRegistrar
	 * 			Responsable de llevar adelante la registración de un Paciente en la base de datos.
	 * @author 	ehv80
	 * @param 	request
	 * @param 	response
	 * @throws 	ServletException
	 * @throws 	IOException
	 */
	private void doRegistrar( HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		/* Toma del request los parámetros ocultos criterio de consulta y valor a buscar para setear en el otro
		 * formulario de consulta de Pacientes		 */
		String criterioConsulta = 	request.getParameter( PacienteServlet.PARAM_CRITERIO_CONSULTA );
		String valorBuscasdo =	request.getParameter( PacienteServlet.PARAM_VALOR_BUSCAR );
		try 
		{
			// Toma del request los parámetros del formulario de alta de Pacientes
			String nombre 				= request.getParameter( PacienteServlet.PARAM_NOMBRE );
			String apellido 			= request.getParameter( PacienteServlet.PARAM_APELLIDO );
			String anioNacimiento 		= request.getParameter( PacienteServlet.PARAM_ANIO_NACIMIENTO );
			String mesNacimiento 		= request.getParameter( PacienteServlet.PARAM_MES_NACIMIENTO );
			String diaNacimiento 		= request.getParameter( PacienteServlet.PARAM_DIA_NACIMIENTO );
			String tipoDeDocumento 		= request.getParameter( PacienteServlet.PARAM_TIPO_DOCUMENTO );
			String numeroDeDocumento 	= request.getParameter( PacienteServlet.PARAM_NRO_DOCUMENTO );
			String obraSocial 			= request.getParameter( PacienteServlet.PARAM_OBRA_SOCIAL );
			String sexo 				= request.getParameter( PacienteServlet.PARAM_SEXO );
			String estaVivo 			= request.getParameter( PacienteServlet.PARAM_ESTA_VIVO );
			
			Date fechaNac;
			Paciente paciente = new Paciente(); //Como registra por primera vez necesita un idPaciente distinto => puedo crear una nueva instancia
			String consultaHQL = "";
			
			boolean validos = paramsValidos( nombre, apellido, anioNacimiento, mesNacimiento, diaNacimiento, tipoDeDocumento, numeroDeDocumento,
					obraSocial, sexo, estaVivo, request);
			
			// verifica que la fecha de Nacimiento sea una fecha correcta
			String fechaNacStr = anioNacimiento + "-" + mesNacimiento + "-" + diaNacimiento;
			fechaNac = FechaUtil.validaFecha( request, fechaNacStr );
			if( fechaNac == null )
			{
				validos = false;
				FieldValueError.setFieldError( PacienteServlet.PARAM_DIA_NACIMIENTO, "Debe seleccionar una Fecha que sea válida ..!", request);
			}
			// verifica el campo tipo de documento
			if( tipoDeDocumento == null || tipoDeDocumento.trim().equals("") )
			{
				validos = false;
				FieldValueError.setFieldError( PacienteServlet.PARAM_TIPO_DOCUMENTO, "Este campo no puede ser vacío ..!", request);
			}
			// verifica el campo número de documento.
			if( numeroDeDocumento == null || numeroDeDocumento.trim().equals("") )
			{
				validos = false;
				FieldValueError.setFieldError( PacienteServlet.PARAM_NRO_DOCUMENTO, "Este campo no puede ser vacío ..!", request);
			}
			// verifica que no haya un Paciente registrado con ese tipo y número de documento
			if( tipoDeDocumento != null && !tipoDeDocumento.trim().equals("") && 
					numeroDeDocumento != null && !numeroDeDocumento.trim().equals("") )
			{	/*
				 * NO SIRVE PORQUE SOLO BUSCA A PACIENTES "VIVOS" CON ESE TIPO Y NRO. DE DOCUMENTO
				 * paciente = new Paciente( null, null, null, tipoDeDocumento, Integer.parseInt( numeroDeDocumento ), null, null, true);
				 */
				/*
				 * NO FUNCIONA PORQUE DEJA GUARDAR DOS Pacientes DISTINTOS CON MISMO TIPO Y NRO. DE DOCUMENTO
				 * paciente.setTpoDoc(tipoDeDocumento);
				 * paciente.setNroDoc( Integer.parseInt( numeroDeDocumento ) );
				 * List<Paciente> listaDePacientes = PacienteHome.encontrarPorEjemplo( paciente );//?
				 */
				
				// Obtiene una lista de Pacientes que tengan ese Tipo y Número de Documento
				consultaHQL = "select p from Paciente as p where p.tpoDoc = '" + tipoDeDocumento +"' and p.nroDoc = '" + numeroDeDocumento + "'";
				List<Paciente> listaDePacientes = PacienteHome.consultaPacientes( consultaHQL );
				if( !listaDePacientes.isEmpty() )
				{
					validos = false;
					FieldValueError.setFieldError( PacienteServlet.PARAM_NRO_DOCUMENTO, 
							"Este Tipo y Número de Documento corresponden a otro Paciente registrado , por favor verifique si son correctos y vuelva a intentarlo ..!",
							request);
				}
			}
			
			if( validos )
			{
				paciente.setNombre( nombre );
				paciente.setApellido( apellido );
				paciente.setFechaNac( fechaNac );				
				paciente.setTpoDoc( tipoDeDocumento) ;
				paciente.setNroDoc( Integer.parseInt( numeroDeDocumento ) );
				paciente.setObraSocial( obraSocial );
				paciente.setSexo( sexo );
				paciente.setEstaVivo( Boolean.valueOf( estaVivo ).booleanValue() );
				
				PacienteHome.modificaPaciente( paciente );
				
				UserNotification.addMessage( request, "El Paciente ha sido registrado satisfactoriamente ..!", Level.INFO);
			}
			else
			{
				UserNotification.addMessage( request, "Ha ocurrido un error, por favor verifique los datos ingresados ..!", Level.ERROR);
				setCamposDePaciente( request, nombre, apellido, anioNacimiento, mesNacimiento, diaNacimiento, 
						tipoDeDocumento, numeroDeDocumento, obraSocial, sexo, estaVivo );
				FieldValueError.setFieldValue( PacienteServlet.PARAM_CRITERIO_CONSULTA, criterioConsulta, request);
				FieldValueError.setFieldValue( PacienteServlet.PARAM_VALOR_BUSCAR, valorBuscasdo, request );
				request.getRequestDispatcher("do_alta_paciente.jsp").forward(request, response);
				return;
			}
		}
		catch( HibernateException e )
		{
			UserNotification.addMessage(request,
					"Ha ocurrido un error al acceder a la base de datos. Por favor comuníquelo al administrador del sitio.",
					Level.ERROR);
			FieldValueError.setFieldValue( PacienteServlet.PARAM_CRITERIO_CONSULTA, criterioConsulta, request);
			FieldValueError.setFieldValue( PacienteServlet.PARAM_VALOR_BUSCAR, valorBuscasdo, request );
		}
		request.getRequestDispatcher("gestor_pacientes_diagnosticos.jsp").forward(request, response);
	}
	
	/**
	 * Método:	doEliminar
	 * 			Responsable de borrar los datos de un Paciente en la base de datos.
	 * @param 	request
	 * @param 	response
	 * @throws 	IOException
	 * @throws 	ServletException
	 */
	private void doEliminar(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String eleccionEliminaPaciente = request.getParameter( PacienteServlet.PARAM_ELECCION_ELIMINAR_PACIENTE );
		
		// sea null o nó, lo pongo como atributo del request para el formulario de elección de eliminación de un Paciente
		request.setAttribute( PacienteServlet.PARAM_ELECCION_ELIMINAR_PACIENTE, eleccionEliminaPaciente);
		
		/*
		* //obtiene el paciente como atributo del request
		* Paciente paciente = (Paciente)request.getAttribute( PacienteServlet.PARAM_PACIENTE );
		* //da error por ser null
		*/
		Paciente paciente = (Paciente)request.getSession().getAttribute( PacienteServlet.PARAM_PACIENTE );
		
		/* 
		 * Para que al clickear el el botón de Eliminar los datos del Paciente
		 * no me borre los datos del selector por tipo y número de Documento:
		 * NO FUNCIONA
		 * FieldValueError.setFieldValue( PacienteServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO, tipoDeDocumentoAnterior, request);
		 * FieldValueError.setFieldValue( PacienteServlet.PARAM_NUMERO_DE_DOCUMENTO_A_BUSCAR, numeroDeDocumentoAnterior , request);
		 */
		if( paciente != null )
		{
			request.setAttribute( PacienteServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO, paciente.getTpoDoc() );
			request.setAttribute( PacienteServlet.PARAM_NUMERO_DE_DOCUMENTO_A_BUSCAR , String.valueOf( paciente.getNroDoc() ) );
			request.setAttribute( PacienteServlet.PARAM_PACIENTE, paciente );
			
			if( eleccionEliminaPaciente != null && eleccionEliminaPaciente.equals( PacienteServlet.PARAM_SI ) ) 
			{
				try 
				{	
					//if( paciente.getDiagnosticos() == null || paciente.getDiagnosticos().isEmpty() ) //Parece que Hibernate no es tan bueno!
					String consultaHQL = 
						"select d from Diagnostico as d where d.paciente.idPaciente = '" + String.valueOf( paciente.getIdPaciente() ) + "'";
					List<Diagnostico> listaDeDiagnosticosDelPaciente = DiagnosticoHome.consultaDiagnosticos( consultaHQL );
					if( listaDeDiagnosticosDelPaciente == null || listaDeDiagnosticosDelPaciente.isEmpty() )
					{
						PacienteHome.eliminaPaciente( paciente );
						UserNotification.addMessage( request, "Los datos del Paciente han sido borrados satisfactoriamente del sistema.", Level.INFO);
						// Una vez que el Paciente ha sido eliminado , borro el objeto Paciente del HttpSession
						request.getSession().removeAttribute( PacienteServlet.PARAM_PACIENTE );
						request.getRequestDispatcher("gestor_pacientes_diagnosticos.jsp").forward(request, response);
					}
					else
					{
						UserNotification.addMessage( request, 
								"Advertencia: Tenga en cuenta que por cuestiones de seguridad de la información no podrá eliminar un Paciente " +
								"que tenga Diagnósticos registrados. En su lugar deberá primero eliminar todos los Diagnósticos que tenga " +
								"el Paciente y luego podrá eliminar el Paciente.",
								Level.ERROR	);
						request.getRequestDispatcher("do_elimina_paciente.jsp").forward(request, response);
					}
					
				}
				catch( HibernateException hex )
				{
					UserNotification.addMessage(request,
							"Ha ocurrido un error al acceder a la base de datos. Por favor comuníquelo al administrador del sitio.",
							Level.ERROR);
					request.getRequestDispatcher("do_elimina_paciente.jsp").forward(request, response);
				}
			}
			else if( eleccionEliminaPaciente != null && eleccionEliminaPaciente.equals( PacienteServlet.PARAM_NO ) )
			{
				UserNotification.addMessage(request, "Usted ha elegido NO ELIMINAR Los datos del Paciente.", Level.INFO);
				request.getRequestDispatcher("do_elimina_paciente.jsp").forward(request, response);
			}
			else
			{
				UserNotification.addMessage(request, "Advertencia: Debe confirmar si desea Eliminar el Paciente ..!", Level.ERROR);
				FieldValueError.setFieldError( PacienteServlet.PARAM_ELECCION_ELIMINAR_PACIENTE, "Debe elegir por \"SI\" o por \"NO\" ..!", request);
				request.getRequestDispatcher("do_elimina_paciente.jsp").forward(request, response);
			}	
		}
	}
	
	/**
	 * Método:	doSeleccionar
	 * 			Responsable de seleccionar un Paciente que obtiene mediante una
	 * 			consulta HQL por Tipo y Número de Documento.
	 * 			Luego redirige la respuesta hacia la "urlDestino".
	 * @param 	request
	 * @param 	response
	 * @param 	urlDestino
	 * @throws ServletException
	 * @throws IOException
	 */
	private void doSeleccionar( HttpServletRequest request, HttpServletResponse response , String urlDestino ) throws ServletException, IOException
	{
		String tipoDeDocumento 	= request.getParameter( PacienteServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO );
		String numeroDeDocumeto	= request.getParameter( PacienteServlet.PARAM_NUMERO_DE_DOCUMENTO_A_BUSCAR );
				
		String consultaHQL;
		Paciente paciente;
		List<Paciente> listaDePacientes;
		
		boolean validos = true;
		
		// verifica el campo tipo de documento del formulario selector de Pacientes
		if( tipoDeDocumento == null || tipoDeDocumento.trim().equals("") )
		{
			validos = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO, 
					"Debe seleccionar uno de los Tipos de Documentos: DNI o LE o LC. ", request);
		}
		
		// verifica el campo número de documento del formulario selector de Pacientes
		if( numeroDeDocumeto == null || numeroDeDocumeto.trim().equals("") )
		{
			validos = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_NUMERO_DE_DOCUMENTO_A_BUSCAR, 
					"El campo Número de Documento no puede ser vacío.", request);
		}
		
		if( validos )
		{
			consultaHQL = "select p from Paciente as p where p.tpoDoc = '" + tipoDeDocumento + "' and p.nroDoc = '" + numeroDeDocumeto + "'";
			listaDePacientes = PacienteHome.consultaPacientes( consultaHQL );
			if( !listaDePacientes.isEmpty() && listaDePacientes.size() == 1 )
			{
				paciente = listaDePacientes.get(0);
				if( urlDestino.equals( "do_modifica_paciente.jsp" ) )
				{
					setCamposDePaciente(request, paciente);
				}
				request.setAttribute( PacienteServlet.PARAM_PACIENTE, paciente );
			}
			else
			{
				UserNotification.addMessage( request, 
						"El Tipo y Número de Documento que ha introducido no corresponde a un Paciente registrado en la Base de Datos. <BR />" +
						"Por favor verifique los datos ingresados e intente nuevamente. <BR />",
						Level.ERROR);
				FieldValueError.setFieldValue( PacienteServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO, tipoDeDocumento, request);
				FieldValueError.setFieldValue( PacienteServlet.PARAM_NUMERO_DE_DOCUMENTO_A_BUSCAR, numeroDeDocumeto, request);
			}
		}
		else
		{
			UserNotification.addMessage( request, 
					"Debe ingresar un Tipo y Número de Documento en el selector de Pacientes ..!",
					Level.ERROR);
			FieldValueError.setFieldValue( PacienteServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO, tipoDeDocumento, request);
			FieldValueError.setFieldValue( PacienteServlet.PARAM_NUMERO_DE_DOCUMENTO_A_BUSCAR, numeroDeDocumeto, request);
		}
		request.getRequestDispatcher( urlDestino ).forward(request, response);
	}
		
	/**
	 * Método:	doActualizar
	 * 			Responsable de actualizar los datos de un Paciente en la base de datos.
	 * @param 	request
	 * @param 	response
	 * @throws	ServletException
	 * @throws 	IOException
	 */
	private void doActualizar( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException 
	{
		// Toma del request los parámetros ocultos para setear los parámetros del formulario de selección del Paciente
		String tipoDeDocumentoAnterior		= request.getParameter( PacienteServlet.PARAM_TIPO_DOCUMENTO_ANTERIOR );
		String numeroDeDocumentoAnterior	= request.getParameter( PacienteServlet.PARAM_NRO_DOCUMENTO_ANTERIOR ) ;

		// Toma del request otro parámetros oculto necesario para realizar chequeo 
		String idPacienteAnteriorStr 		= request.getParameter( PacienteServlet.PARAM_ID_PACIENTE_ANTERIOR );
		int idPacienteAnterior				= Integer.parseInt( idPacienteAnteriorStr );
		
		try 
		{
			//Toma del request los parámetros para setear los parámetros del formulario de actualización de datos del Paciente
			String nombre 				= request.getParameter( PacienteServlet.PARAM_NOMBRE );
			String apellido 			= request.getParameter( PacienteServlet.PARAM_APELLIDO );
			String anioNacimiento 		= request.getParameter( PacienteServlet.PARAM_ANIO_NACIMIENTO );
			String mesNacimiento 		= request.getParameter( PacienteServlet.PARAM_MES_NACIMIENTO );
			String diaNacimiento 		= request.getParameter( PacienteServlet.PARAM_DIA_NACIMIENTO );
			String tipoDeDocumento 		= request.getParameter( PacienteServlet.PARAM_TIPO_DOCUMENTO );
			String numeroDeDocumento 	= request.getParameter( PacienteServlet.PARAM_NRO_DOCUMENTO );
			String obraSocial 			= request.getParameter( PacienteServlet.PARAM_OBRA_SOCIAL );
			String sexo 				= request.getParameter( PacienteServlet.PARAM_SEXO );
			String estaVivo 			= request.getParameter( PacienteServlet.PARAM_ESTA_VIVO );
			
			Date fechaNac;
			
			// Alternativa para no hacer otra consulta a la base de datos: obteniéndolo como atributo del HttpSession
			// previamente preparado por do_modifica_usuario.jsp
			Paciente paciente = (Paciente)request.getSession().getAttribute( PacienteServlet.PARAM_PACIENTE ); //da error por ser nul
			String consultaHQL = "";
			
			boolean validos = paramsValidos( nombre, apellido, anioNacimiento, mesNacimiento, diaNacimiento, tipoDeDocumento, numeroDeDocumento,
					obraSocial, sexo, estaVivo, request);

			//verifica que la fecha sea una fecha correcta
			String fechaNacStr = anioNacimiento + "-" + mesNacimiento + "-" + diaNacimiento;
			fechaNac = FechaUtil.validaFecha( request, fechaNacStr );
			if( fechaNac == null )
			{
				validos = false;
				FieldValueError.setFieldError( PacienteServlet.PARAM_DIA_NACIMIENTO, "Debe seleccionar una Fecha que sea válida ..!", request);
			}
			//verifica si el campo tipo de documento es inadecuado
			if( tipoDeDocumento == null || tipoDeDocumento.trim().equals("") )
			{
				validos = false;
				FieldValueError.setFieldError( PacienteServlet.PARAM_TIPO_DOCUMENTO, "Este campo no puede ser vacío ..!", request);
			}
			// verifica si el campo número de documento es inadecuado
			if( numeroDeDocumento == null || numeroDeDocumento.trim().equals("") )
			{
				validos = false;
				FieldValueError.setFieldError( PacienteServlet.PARAM_NRO_DOCUMENTO, "Este campo no puede ser vacío ..!", request);
			}
			//verifica SI HAY OTRO Paciente (otro idPaciente) registrado con ese tipo y número de Documento
			if( tipoDeDocumento.equals( tipoDeDocumentoAnterior ) && !numeroDeDocumento.equals( numeroDeDocumentoAnterior ) )
			{
				/*
				* NO FUNCIONA PORQUE DEJA GUARDAR DOS Pacientes DISTINTOS CON MISMO TIPO Y NRO. DE DOCUMENTO
				* Paciente sample = new Paciente();
				* sample.setTpoDoc(tipoDeDocumento);
				* sample.setNroDoc(Integer.parseInt( numeroDeDocumento ) );
				* List<Paciente> listaDePacientes = PacienteHome.encontrarPorEjemplo( sample );
				*/
				
				// Obtiene una lista de Pacientes que tengan los nuevos Tipo y Número de Documento (si es que el usuario los cambió)
				consultaHQL = "select p from Paciente as p where p.tpoDoc = '" + tipoDeDocumento +"' and p.nroDoc = '" + numeroDeDocumento + "'";
				List<Paciente> listaDePacientes = PacienteHome.consultaPacientes( consultaHQL );
				if( !listaDePacientes.isEmpty() )
				{
					if( listaDePacientes.size() == 1 && listaDePacientes.get(0).getIdPaciente() != idPacienteAnterior )
					{
						validos = false;
						FieldValueError.setFieldError( PacienteServlet.PARAM_NRO_DOCUMENTO, 
								"Este Tipo y Número de Documento corresponden a otro Paciente registrado, por favor verifique si son correctos y vuelva a intentarlo ..!",
								request);
					}
				}
			}
			
			if( validos )
			{
				paciente.setNombre( nombre );
				paciente.setApellido( apellido );
				paciente.setFechaNac( fechaNac );				
				paciente.setTpoDoc( tipoDeDocumento) ;
				paciente.setNroDoc( Integer.parseInt( numeroDeDocumento ) );
				paciente.setObraSocial( obraSocial );
				paciente.setSexo( sexo );
				paciente.setEstaVivo( Boolean.valueOf( estaVivo ).booleanValue() );
				
				PacienteHome.modificaPaciente( paciente );
				
				UserNotification.addMessage( request, "Los datos del Paciente han sido modificados satisfactoriamente ..!", Level.INFO);
				
				// Una vez que ha actualizado el Paciente satisfactoriamente puede sacar el Paciente que ha quedado como atributo del HttpSession
				request.getSession().removeAttribute( PacienteServlet.PARAM_PACIENTE ); //OK
			}
			else
			{
				UserNotification.addMessage(request, "Ha ocurrido un error, por favor verifique los datos ingresados ..!", UserNotification.Level.ERROR);
				setListaPacientes(request);
				setCamposDePaciente(request, nombre, apellido, anioNacimiento, mesNacimiento, diaNacimiento,
						tipoDeDocumento, numeroDeDocumento, obraSocial, sexo, estaVivo );
				// Para que al clickear el el botón de Actualizar los datos del Paciente no  borre los datos del selector por tipo y número de Documento
				FieldValueError.setFieldValue( PacienteServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO , tipoDeDocumentoAnterior, request);
				FieldValueError.setFieldValue( PacienteServlet.PARAM_NUMERO_DE_DOCUMENTO_A_BUSCAR, numeroDeDocumentoAnterior, request);
				request.setAttribute( PacienteServlet.PARAM_PACIENTE, paciente );
				request.getRequestDispatcher( "do_modifica_paciente.jsp" ).forward(request, response);
				return;
			}
		}
		catch( HibernateException hex)
		{
			UserNotification.addMessage(request, 
					"Ha ocurrido un error al acceder a la base de datos. Por favor comuníquelo al administrador del sitio.",
					Level.ERROR);
			// Para que al clickear el el botón de Actualizar los datos del Paciente no  borre los datos del selector por tipo y número de Documento
			FieldValueError.setFieldValue( PacienteServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO , tipoDeDocumentoAnterior, request);
			FieldValueError.setFieldValue( PacienteServlet.PARAM_NUMERO_DE_DOCUMENTO_A_BUSCAR, numeroDeDocumentoAnterior, request);
		}
		//setListaPacientes( request ); //ya no es necesario
		request.getRequestDispatcher("gestor_pacientes_diagnosticos.jsp").forward(request, response);
	}
	
	/**
	 * Método:	doListar
	 * 			Realiza una consulta HQL para obtener todos los Pacientes registrados en la base de datos Clinica, Tabla Pacientes.
	 * @param 	request
	 * @param 	response
	 * @throws 	ServletException
	 * @throws 	IOException
	 */
	private void doListar( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException 
	{
		try
		{
			setListaPacientes( request );
		}
		catch( HibernateException hex)
		{
			UserNotification.addMessage( request, 
					"Ha ocurrido un error al acceder a la base de datos. Por favor comuníquelo al administrador del sitio.",
					Level.ERROR);
		}
		request.getRequestDispatcher( "do_modifica_paciente.jsp" ).forward( request, response );
	}
	
	/**
	 * Método:	doConsultar
	 * 			Realiza una consulta HQL en la base de datos Clinica, Tabla PACIENTES de acuerdo a un
	 * 			criterio de búsqueda y un valor suministrados por los parámetros del formulario.
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	private void doConsultar( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException
	{
		//toma los campos ocultos para setear los campos del formulario de alta de Pacientes
		String nombre 			= request.getParameter( PacienteServlet.PARAM_NOMBRE );
		String apellido 		= request.getParameter( PacienteServlet.PARAM_APELLIDO );
		String anioNacimiento 	= request.getParameter(PacienteServlet.PARAM_ANIO_NACIMIENTO );
		String mesNacimiento 	= request.getParameter( PacienteServlet.PARAM_MES_NACIMIENTO );
		String diaNacimiento 	= request.getParameter( PacienteServlet.PARAM_DIA_NACIMIENTO );
		String tipoDeDocumento	= request.getParameter( PacienteServlet.PARAM_TIPO_DOCUMENTO );
		String numeroDeDocumento	= request.getParameter( PacienteServlet.PARAM_NRO_DOCUMENTO );
		String obraSocial		= request.getParameter( PacienteServlet.PARAM_OBRA_SOCIAL );
		String sexo				= request.getParameter(PacienteServlet.PARAM_SEXO );
		String estaVivo			= request.getParameter(PacienteServlet.PARAM_ESTA_VIVO );
		setCamposDePaciente(request, nombre, apellido, anioNacimiento, mesNacimiento, diaNacimiento, 
				tipoDeDocumento, numeroDeDocumento, obraSocial, sexo, estaVivo);
		
		String criterioBusqueda = request.getParameter( PacienteServlet.PARAM_CRITERIO_CONSULTA );
		String valorBuscar = request.getParameter( PacienteServlet.PARAM_VALOR_BUSCAR );
		
		//sean null, o nó, los pongo como atributo del request para asignarlos al formulario de consulta de Pacientes
		request.setAttribute(PacienteServlet.PARAM_CRITERIO_CONSULTA, criterioBusqueda);
		request.setAttribute(PacienteServlet.PARAM_VALOR_BUSCAR, valorBuscar);
		
		if( criterioBusqueda != null && !criterioBusqueda.trim().equals("") && valorBuscar != null && !valorBuscar.trim().equals("") )
		{
			//request.setAttribute(PacienteServlet.PARAM_CRITERIO_CONSULTA, criterioBusqueda);
			//request.setAttribute(PacienteServlet.PARAM_VALOR_BUSCAR, valorBuscar);
			try
			{
				setListaPacientes(request, criterioBusqueda, valorBuscar);
			}
			catch( HibernateException hex)
			{
				UserNotification.addMessage(request, 
						"Ha ocurrido un error al acceder a la base de datos. Por favor comuníquelo al administrador del sitio.",
						Level.ERROR);
			}
		}
		else
		{
			UserNotification.addMessage( request, 
					"Debe seleccionar un criterio de búsqueda y completar con el valor que desea buscar ..!",
					Level.ERROR);
			request.getRequestDispatcher( "do_alta_paciente.jsp" ).forward( request, response );
		}
		request.getRequestDispatcher( "do_alta_paciente.jsp" ).forward( request, response );
	}
	
	/**
	 * Método:	paramsValidos
	 * 			Responsable de validar los parámetros de los formularios.
	 * @param 	nombreReal
	 * @param 	apellido
	 * @param 	nombreAcceso
	 * @param 	claveAcceso
	 * @param 	request
	 * @return	ok
	 */
	private boolean paramsValidos( String nombre, String apellido, String anioNacimiento, String mesNacimiento, String diaNacimiento, 
			String tipoDeDocumento, String numeroDeDocumento, String obraSocial, String sexo, String estaVivo,  HttpServletRequest request) 
	{
		boolean ok = true;
		if( nombre == null || nombre.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_NOMBRE, "Este campo no puede ser vacío ..!", request);
		}
		if( apellido == null || apellido.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_APELLIDO, "Este campo no puede ser vacío ..!", request);
		}
		if( anioNacimiento == null || anioNacimiento.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_ANIO_NACIMIENTO, "Este campo no puede ser vacío ..!", request);
		}
		if( mesNacimiento == null || mesNacimiento.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_MES_NACIMIENTO, "Este campo no puede ser vacío ..!", request);
		}
		if( diaNacimiento == null || diaNacimiento.trim().equals(""))
		{
			ok = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_DIA_NACIMIENTO, "Este campo no puede ser vacío ..!", request);
		}
		if( tipoDeDocumento == null || tipoDeDocumento.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_TIPO_DOCUMENTO, "Este campo no puede ser vacío ..!", request);
		}
		if( numeroDeDocumento == null || numeroDeDocumento.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_NRO_DOCUMENTO, "Este campo no puede ser vacío ..!", request);
		}
		if( obraSocial == null || obraSocial.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_OBRA_SOCIAL, "Este campo no puede ser vacío ..!", request);
		}
		if( sexo == null || sexo.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_SEXO, "Este campo no puede ser vacío ..!", request);
		}
		if( estaVivo == null || estaVivo.trim().equals(""))
		{
			ok = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_ESTA_VIVO, "Este campo no puede ser vacío ..!", request);
		}
		return ok;
	}
		
	/**
	 * Método:	setListaPacientes
	 * 			Método auxiliar para agregar al request la lista de todos los Pacientes registrados.
	 * @param request
	 */
	private void setListaPacientes( HttpServletRequest request )
	{
		String consultaHQL = "select p from Paciente as p";
		List<Paciente> listaDePacientes = PacienteHome.consultaPacientes( consultaHQL );
		request.setAttribute( PacienteServlet.LISTA_PACIENTES , listaDePacientes );
	}
	
	/**
	 * Método:	setListaPacientes
	 * 			Método auxiliar para agregar al request la lista de todos los Pacientes registrados que cumplen con un criterio de consulta 
	 * 			y un valor a buscar.
	 * @param request
	 * @param criterioBusqueda
	 * @param valorBuscar
	 */
	private void setListaPacientes( HttpServletRequest request, String criterioBusqueda, String valorBuscar )
	{
		String consultaHQL = "";
		if( criterioBusqueda.trim().equals( PacienteServlet.PARAM_CRITERIO_CONSULTA_NOMBRE ) )
		{
			consultaHQL = "select p from Paciente as p where p.nombre = '" + valorBuscar + "'";
		}
		else if( criterioBusqueda.trim().equals( PacienteServlet.PARAM_CRITERIO_CONSULTA_APELLIDO ) )
		{
			consultaHQL = "select p from Paciente as p where p.apellido = '" + valorBuscar + "'";
		}
		else if( criterioBusqueda.trim().equals( PacienteServlet.PARAM_CRITERIO_CONSULTA_FECHA_NACIMIENTO ) )
		{
			Date fecha = FechaUtil.validaFecha( request, valorBuscar );
			if( fecha != null )
			{
				consultaHQL = "select p from Paciente as p where p.fechaNac = '" + valorBuscar + "'";
			}
			else
			{
				UserNotification.addMessage(request, 
						"La fecha que introduce como valor a buscar debe respetar el siguiente formato: \"YYYY-MM-DD\" " +
						"es decir, 4 cifras para el año, seguidas de un guión medio, luego 2 cifras para el mes, seguidas de otro guión medio, " +
						"y a continuación 2 cifras para el día. <BR />" +
						"Por favor intente nuevamente teniendo en cuenta esta aclaración.", 
						UserNotification.Level.ERROR);
				return;
			}
		}
		else if( criterioBusqueda.trim().equals( PacienteServlet.PARAM_CRITERIO_CONSULTA_TIPO_DOCUMENTO ) )
		{
			if( valorBuscar.trim().equals("DNI") || valorBuscar.trim().equals("LE") || valorBuscar.trim().equals("LC") )
			{
				consultaHQL = "select p from Paciente as p where p.tpoDoc = '" + valorBuscar + "'";
			}
			else
			{
				UserNotification.addMessage(request, 
						"Cuando realiza la consulta seleccionando el criterio de búsqueda: \"" + 
						PacienteServlet.PARAM_CRITERIO_CONSULTA_TIPO_DOCUMENTO +
						"\" debe introducir como valor a buscar la frase: \"DNI\" para consultar por Documento Nacional de Identidad; o bién <BR />" +
						"la frase: \"LE\" para consultar por Libreta de Enrolamiento; o bién <BR />" +
						"la frase: \"LC\" para consultar por Libreta Cívica <BR />" +
						"Por favor intente nuevamente teniendo en cuenta esta aclaración." , 
						UserNotification.Level.ERROR);
				return;
			}
		}
		else if( criterioBusqueda.trim().equals( PacienteServlet.PARAM_CRITERIO_CONSULTA_NUMERO_DOCUMENTO ) )
		{
			consultaHQL = "select p from Paciente as p where p.nroDoc = '" + valorBuscar + "'";
		}
		else if( criterioBusqueda.trim().equals( PacienteServlet.PARAM_CRITERIO_CONSULTA_OBRA_SOCIAL ) )
		{
			consultaHQL = "select p from Paciente as p where p.obraSocial = '" + valorBuscar + "'";
		}
		else if( criterioBusqueda.trim().equals( PacienteServlet.PARAM_CRITERIO_CONSULTA_SEXO ) )
		{
			if( valorBuscar.trim().equals("F") || valorBuscar.trim().equals("M") )
			{
				consultaHQL = "select p from Paciente as p where p.sexo = '" + valorBuscar + "'";
			}
			else
			{
				UserNotification.addMessage( request, 
						"Cuando realiza la consulta seleccionando el criterio de búsqueda: \"" + 
						PacienteServlet.PARAM_CRITERIO_CONSULTA_SEXO +
						"\" debe introducir como valor a buscar la letra: \"F\" para consultar por Pacientes de sexo femenino; o bién <BR />" +
						"la letra: \"M\" para consultar por Pacientes de sexo masculino <BR />" +
						"Por favor intente nuevamente teniendo en cuenta esta aclaración.", 
						Level.ERROR );
				return;
			}
		}
		else if( criterioBusqueda.trim().equals( PacienteServlet.PARAM_CRITERIO_CONSULTA_ESTA_VIVO ) )
		{
			if( valorBuscar.trim().equals("1") || valorBuscar.trim().equals("0") )
			{
				consultaHQL = "select p from Paciente as p where p.estaVivo = '" + valorBuscar  + "'";
			}
			else
			{
				UserNotification.addMessage(request, 
						"Cuando realiza la consulta seleccionando el criterio de búsqueda: \"" + 
						PacienteServlet.PARAM_CRITERIO_CONSULTA_ESTA_VIVO + "\" <BR />" +
						" debe introducir como valor a buscar el caracter numérico uno: 1 para buscar Pacientes con vida (true); o bién <BR />" +
						" debe introducir como valor a buscar el caracter numérico cero: 0 para buscar Pacientes que han fallecido (false).<BR />" +
						" Por favor intente nuevamente teniendo en cuenta esta aclaración.", 
						UserNotification.Level.ERROR);
				return;
			}
		}
		List<Paciente> listaDePacientes = PacienteHome.consultaPacientes( consultaHQL );
		request.setAttribute( PacienteServlet.LISTA_PACIENTES , listaDePacientes );
	}
	
	/**
	 * Método:	setCamposDePaciente
	 * 			Método auxiliar para completar los campos del formulario de edición de los datos referidos a un Paciente.
	 * 			En este caso extrae los datos del objeto Paciente que toma como argumento.
	 * @param request
	 * @param paciente
	 */
	private void setCamposDePaciente( HttpServletRequest request, Paciente paciente )
	{
		if( paciente != null )
		{
			Date fechaNac 	= paciente.getFechaNac();
			String anioNac 	= FechaUtil.getAnioFromDateToStr( fechaNac );
			String mesNac 	= FechaUtil.getMesFromDateToStr( fechaNac );
			String diaNac	= FechaUtil.getDiaFromDateToStr( fechaNac );
			
			FieldValueError.setFieldValue( PacienteServlet.PARAM_NOMBRE, paciente.getNombre(), request );
			FieldValueError.setFieldValue( PacienteServlet.PARAM_APELLIDO, paciente.getApellido(), request );
			
			FieldValueError.setFieldValue( PacienteServlet.PARAM_ANIO_NACIMIENTO, anioNac, request );
			FieldValueError.setFieldValue( PacienteServlet.PARAM_MES_NACIMIENTO, mesNac, request );
			FieldValueError.setFieldValue( PacienteServlet.PARAM_DIA_NACIMIENTO, diaNac, request );
			
			FieldValueError.setFieldValue( PacienteServlet.PARAM_TIPO_DOCUMENTO, paciente.getTpoDoc(), request );
			FieldValueError.setFieldValue( PacienteServlet.PARAM_NRO_DOCUMENTO, String.valueOf( paciente.getNroDoc() ), request );
			FieldValueError.setFieldValue( PacienteServlet.PARAM_OBRA_SOCIAL, paciente.getObraSocial(), request );
			FieldValueError.setFieldValue( PacienteServlet.PARAM_SEXO, paciente.getSexo(), request );
			FieldValueError.setFieldValue( PacienteServlet.PARAM_ESTA_VIVO, String.valueOf( paciente.isEstaVivo() ), request );
		}
		else
		{
			UserNotification.addMessage( request, 
					"Ha ocurrido un error al autocompletar los campos del formulario. Intente nuevamente.",
					Level.ERROR);
		}
	}
	
	/**
	 * Método:
	 * 			Método auxiliar para completar los campos del formulario de edición de los datos referidos a un Paciente.
	 * 			En este caso extrae los datos a partir de los argumentos del propio método. 
	 * @param request
	 * @param nombre
	 * @param apellido
	 * @param anioNacimiento
	 * @param mesNacimiento
	 * @param diaNacimiento
	 * @param tipoDeDocumento
	 * @param numeroDeDocumento
	 * @param obraSocial
	 * @param sexo
	 * @param estaVivo
	 */
	private void setCamposDePaciente( HttpServletRequest request, String nombre, String apellido , String anioNacimiento, String mesNacimiento,
			String diaNacimiento, String tipoDeDocumento, String numeroDeDocumento, String obraSocial, String sexo, String estaVivo )
	{
		FieldValueError.setFieldValue( PacienteServlet.PARAM_NOMBRE, nombre, request );
		FieldValueError.setFieldValue( PacienteServlet.PARAM_APELLIDO, apellido, request );
		FieldValueError.setFieldValue( PacienteServlet.PARAM_ANIO_NACIMIENTO, anioNacimiento, request );
		FieldValueError.setFieldValue( PacienteServlet.PARAM_MES_NACIMIENTO, mesNacimiento, request );
		FieldValueError.setFieldValue( PacienteServlet.PARAM_DIA_NACIMIENTO, diaNacimiento, request );
		FieldValueError.setFieldValue( PacienteServlet.PARAM_TIPO_DOCUMENTO, tipoDeDocumento, request );
		FieldValueError.setFieldValue( PacienteServlet.PARAM_NRO_DOCUMENTO, numeroDeDocumento, request );
		FieldValueError.setFieldValue( PacienteServlet.PARAM_OBRA_SOCIAL, obraSocial, request );
		FieldValueError.setFieldValue( PacienteServlet.PARAM_SEXO, sexo, request );
		FieldValueError.setFieldValue( PacienteServlet.PARAM_ESTA_VIVO, estaVivo, request );
	}
}