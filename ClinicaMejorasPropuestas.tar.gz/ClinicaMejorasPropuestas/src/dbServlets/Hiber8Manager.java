package dbServlets;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Hiber8Manager 
{

	private static SessionFactory hibernateSessionFactory;
	
	/**
	 * Método:	getHibernateSessionFactory
	 * 			Inicializa el único SessionFactory para toda la aplicación.
	 * @author 	patricio.keilty@gmail.com
	 * @return	Hiber8Manager.hibernateSessionFactory
	 * @throws 	HibernateException
	 */
	private static SessionFactory getHibernateSessionFactory() throws HibernateException
	{
		if( Hiber8Manager.hibernateSessionFactory == null )
		{
			Hiber8Manager.hibernateSessionFactory = new Configuration().configure().buildSessionFactory();
		}
		return Hiber8Manager.hibernateSessionFactory;
	}

	/**
	 * Método:	openHibernateSession
	 * 			Inicializa estáticamente la Session.
	 * @author	patricio.keilty@gmail.com
	 * @param 	void
	 * @return 	getHibernateSessionFactory().openSession();
	 */
	public static Session openHibernateSession() throws HibernateException 
	{
		return getHibernateSessionFactory().openSession();
	}

	/**
	 * Método:	closeHibernateSession
	 * 			Cierra estáticamente la Session.
	 * @param hibernateSession
	 * @throws HibernateException
	 */
	public static void closeHibernateSession(Session hibernateSession) throws HibernateException 
	{
		hibernateSession.close();
	}

}