package dbServlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import utility.UserNotification;
import utility.UserNotification.Level;

/**
 * Servlet implementation class for Servlet: LogoutServlet
 *
 */
 public class LogoutServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
 {
	 public static final String PARAM_ELECCION_LOGOUT = "eleccionLogout";
	 public static final String PARAM_SI = "SI";
	 public static final String PARAM_NO = "NO";
	 
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public LogoutServlet() 
	{
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String eleccionLogout;
		if( request.getParameter( PARAM_ELECCION_LOGOUT ) != null && !request.getParameter( PARAM_ELECCION_LOGOUT ).equals("") )
		{
			eleccionLogout = request.getParameter( PARAM_ELECCION_LOGOUT );
			if( eleccionLogout != null && eleccionLogout.equals( PARAM_SI ) )
			{
				request.getSession().setAttribute( LoginServlet.USUARIO , null);
				request.getSession().invalidate();
				request.getRequestDispatcher("index.jsp").forward(request, response);
				return;
			}
			if( eleccionLogout != null && eleccionLogout.equals( PARAM_NO ) )
			{
				UserNotification.addMessage(request, "Usted ha elegido continuar usando el Portal ..!", Level.INFO);
				request.getRequestDispatcher("logout.jsp").forward(request, response);
				return;
			}
		}
		else
		{
			UserNotification.addMessage(request, "Debe elegir por \"SI\" o por \"NO\" ..! ", Level.INFO);
			request.getRequestDispatcher("logout.jsp").forward(request, response);
			return;
		}
	}   	  	    
}