package hall;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class ThreeParams extends HttpServlet {
  public void doGet(HttpServletRequest request,HttpServletResponse response)
  throws ServletException, IOException {

    response.setContentType("text/html");
    PrintWriter out = response.getWriter();
    String title = "Reading Three Request Parameters";
    out.println(ServletUtilities.headWithTitle(title) +
                "&lt;BODY&gt;\n" +
                "&lt;H1 ALIGN=CENTER&gt;" + title + "&lt;/H1&gt;\n" +
                "&lt;UL&gt;\n" +
                "  &lt;LI&gt;param1: "
                + request.getParameter("param1") + "\n" +
                "  &lt;LI&gt;param2: "
                + request.getParameter("param2") + "\n" +
                "  &lt;LI&gt;param3: "
                + request.getParameter("param3") + "\n" +
                "&lt;/UL&gt;\n" +
                "&lt;/BODY&gt;&lt;/HTML&gt;");
  }

  public void doPost(HttpServletRequest request, HttpServletResponse response)
  throws ServletException, IOException {

    doGet(request, response);
  }

}