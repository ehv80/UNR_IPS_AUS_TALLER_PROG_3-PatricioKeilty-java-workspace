package hall;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class HelloWWW2 extends HttpServlet {

  public void doGet(HttpServletRequest request, HttpServletResponse response)
  throws ServletException, IOException {
    response.setContentType("text/html");
    PrintWriter out = response.getWriter();
    out.println(ServletUtilities.headWithTitle("Hello WWW") +
                "&lt;BODY&gt;\n" +
                "&lt;H1&gt;Hello WWW&lt;/H1&gt;\n" +
                "&lt;/BODY&gt;&lt;/HTML&gt;");
  }
}