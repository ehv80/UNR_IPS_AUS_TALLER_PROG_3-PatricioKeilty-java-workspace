package hall;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class HelloWWW extends HttpServlet {

  public void doGet(HttpServletRequest request, HttpServletResponse response)
  throws ServletException, IOException {
    response.setContentType("text/html");
    PrintWriter out = response.getWriter();
    out.println("&lt;!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 " +
                                        "Transitional//EN\"&gt;\n" +
                "&lt;HTML&gt;\n" +
                "&lt;HEAD&gt;&lt;TITLE&gt;Hello WWW&lt;/TITLE&gt;&lt;/HEAD&gt;\n" +
                "&lt;BODY&gt;\n" +
                "&lt;H1&gt;Hello WWW&lt;/H1&gt;\n" +
                "&lt;/BODY&gt;&lt;/HTML&gt;");
  }
}