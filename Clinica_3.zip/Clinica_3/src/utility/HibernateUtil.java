package utility;

import java.sql.ResultSet;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import clinica.Diagnostico;
import clinica.Paciente;

/**		@author ehv80		*/
public class HibernateUtil {

	private static SessionFactory sessionFactory;
		//	 = new Configuration().configure().buildSessionFactory();
	private static Session session;

	/**	Inicializa el único SessionFactory para toda la aplicación.
	 * 	@param void
	 * 	@return void
	 */
	public static void createSessionFactory()
	{
		try{
			sessionFactory = new Configuration().configure().buildSessionFactory();
		}
		catch(HibernateException ex)
		{
			System.err.println("Ha ocurrido una Excepción al inicializar el SessionFactory "+ex);
		}
	}
	
	/**
	 * Finaliza el único SessionFactory para toda la aplicación.
	 * @param void
	 * @return void"iteradorPacientes"
	 */
	public static void closeSessionFactory()
	{
		try{
			sessionFactory.close();
		}
		catch(HibernateException ex)
		{
			System.err.println("Ha ocurrido una Excepción al cerrar el SessionFactory " + ex);
		}
	}
	
	/**
	 * @param void
	 * @return SessionFactory
	 */
	public static SessionFactory getSessionFactory()
	{
		return sessionFactory;
	}
	
	/**
	 * Inicializa estáticamente la Session.
	 * @param void
	 * @return void
	 */
	public static void createSession()
	{
		try
		{
			if(sessionFactory != null )
			{
				session = sessionFactory.openSession();
			}
		}
		catch(HibernateException ex)
		{
			System.err.println("Ha ocurrido una Excepción al inicializar estáticamente la Session " + ex);
		}
	}
	
	/**
	 * Cierra estáticamente la Session.
	 * @param void
	 * @return void
	 */
	public static void closeSession()
	{
		try
		{
			session.close();
		}
		catch(HibernateException ex)
		{
			System.err.println("Ha ocurrido una Excepción al cerrar estáticamente la Session " + ex);
		}
	}
	
	/**
	 * Retorna la Session.
	 * @return Session.
	 */
	public static Session getSession()
	{
		return session;
	}
	
	/**
	 * Conecta mediante createSessionFactory y createSession.
	 */
	public static void conectar()
	{
		createSessionFactory();
		createSession();
	}
	
	/**
	 * Desconecta mediante  closeSession y closeSessionFactory.
	 */
	public static void desconectar()
	{
		closeSession();
		closeSessionFactory();
	}
	
	/**
	 * Hace una consulta HQL a la Base de Datos Clínica y retorna
	 * un listado de Pacientes.
	 * 
	 * @param String consultaHQL
	 * @return List<Pacientes> listaPacientes
	 */
	//public static Set<Paciente> consultaPacientes(String consultaHQL) <<< debería ser así mas fácil?
	public static List<Paciente> consultaPacientes(String consultaHQL)
	{
		if( consultaHQL != null && !consultaHQL.equals("") )
		{
			if( sessionFactory == null )
			{
				createSessionFactory();
			}
			if( session == null )
			{
				createSession();
			}
			List <Paciente> listaPacientes;
			Transaction transaccion;
			try
			{
				transaccion = session.beginTransaction();
				listaPacientes = (List<Paciente>) ( session.createQuery(consultaHQL).list() );
				transaccion.commit(); //indica fin y aplicación de la transacción
				
				return listaPacientes;
			}
			catch(Exception ex)
			{
				System.err.println("Ha ocurrido una Excepción al ejecutar la consulta HQL sobre la Tabla Clinica.PACIENTES: " + ex );
				System.err.println("En HibernateUtil.consultaPacientes(consultaHQL) ");
				return (List<Paciente>)null;
			}
			finally
			{
				//closeSession();
				//closeSessionFactory();
				//desconectar();
			}
		}
		else
		{
			System.err.println("La consulta HQL sobre la Tabla Clinica.PACIENTES: NO PUEDE SER UNA CADENA NULA..! " );
			System.err.println("En HibernateUtil.consultaPacientes(consultaHQL) ");
			return (List<Paciente>)null;
		}
	}
	
	/**
	 * Hace una consulta HQL a la Base de Datos Clínica y retorna
	 * un listado de Diagnósticos.
	 * 
	 * @param String consultaHQL
	 * @return List<Diagnostico> listaDiagnosticos
	 */
	//public static Set<Diagnostico> consultaDiagnosticos(String consultaHQL)  <<< debería ser así mas fácil?
	public static List<Diagnostico> consultaDiagnosticos(String consultaHQL)
	{
		if( consultaHQL != null && !consultaHQL.equals("") )
		{
			if( sessionFactory == null )
			{
				createSessionFactory();
			}
			if( session == null )
			{
				createSession();
			}
			List <Diagnostico> listaDiagnosticos;
			Transaction transaccion;
			try
			{
				transaccion = session.beginTransaction();
				listaDiagnosticos = (List<Diagnostico>) ( session.createQuery(consultaHQL).list() );
				transaccion.commit(); //indica fin y aplicación de la transacción
				
				return listaDiagnosticos;
			}
			catch(Exception ex)
			{
				System.err.println("Ha ocurrido una Excepción al ejecutar la consulta HQL sobre la Tabla Clinica.DIAGNOSTICOS: " + ex );
				System.err.println("En HibernateUtil.consultaDiagnosticos(consultaHQL) ");
				return (List<Diagnostico>)null;
			}
			finally
			{
				//closeSession();
				//closeSessionFactory();
				//desconectar(); >> parece que no se puede
			}
		}
		else
		{
			System.err.println("Ha ocurrido una Excepción al ejecutar la consulta HQL sobre la Tabla Clinica.DIAGNOSTICOS: ");
			System.err.println("En HibernateUtil.consultaDiagnosticos(consultaHQL) ");
			return (List<Diagnostico>)null;
		}
	}
	
}