package dbServlets;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import utility.HibernateUtil;
import clinica.Diagnostico;
import clinica.Paciente;

/**
 * Servlet implementation class for Servlet: DbServletBuscaDiagnostico
 *
 */
 public class DbServletBuscaDiagnostico extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public DbServletBuscaDiagnostico() {
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		if( HibernateUtil.getSessionFactory() == null )
		{
			HibernateUtil.createSessionFactory();
		}
		if( HibernateUtil.getSession() == null )
		{
			HibernateUtil.createSession();
		}
		if(HibernateUtil.getSession() != null && HibernateUtil.getSessionFactory() != null)
		{
			//Transaction transaccion; << ya lo maneja HibernateUtil.consultaPacientes
			String consultaHQL;
			List<Diagnostico> listaDiagnosticos;
			Iterator iteradorDiagnosticos;
			try
			{
				//Inicia una Transacción
				//transaccion = HibernateUtil.getSession().beginTransaction();
				consultaHQL = "select d from Diagnostico as d where 1=1 ";
				listaDiagnosticos = (List<Diagnostico>)(HibernateUtil.consultaDiagnosticos(consultaHQL));
				if( listaDiagnosticos != null )
				{					
					iteradorDiagnosticos = listaDiagnosticos.iterator();
					//transaccion.commit(); //indica fin y aplicación de la transacción
					request.getSession().setAttribute("iteradorDiagnosticos", iteradorDiagnosticos);
					response.sendRedirect("do_busca_diagnostico.jsp");
				}
			}
			catch( HibernateException hex)
			{
				//System.err.println("Ha ocurrido una Excepción al ejecutar DbServletBuscaDiagnostico :" + ex);
				String mensaje = "Ha ocurrido una Excepción al ejecutar DbServletBuscaDiagnostico.doPost(request, response) " +
					"Detalle: " + hex;
				request.getSession().setAttribute("mensaje", mensaje);
				response.sendRedirect("error.jsp");
			}
			catch( Exception ex )
			{
				//System.err.println("Ha ocurrido una Excepción al ejecutar DbServletBuscaDiagnostico :"+ ex);
				String mensaje = "Ha ocurrido una Excepción al ejecutar DbServletBuscaDiagnostico.doPost(request, response) " +
					"Detalles: " + ex;
				request.getSession().setAttribute("mensaje", mensaje);
				response.sendRedirect("error.jsp");
			}
			finally
			{
				//HibernateUtil.desconectar(); << ya lo hace HibernateUtil.consultaPacientes
				//HibernateUtil.closeSession();	<< ya lo hace HibernateUtil.consultaPacientes
				//Pero no cierra el SessionFactory para poder segir en otro intento... << mentira
				//response.sendRedirect("do_alta_diagnostico.jsp");
			}	
		}
	}   	  	    
}