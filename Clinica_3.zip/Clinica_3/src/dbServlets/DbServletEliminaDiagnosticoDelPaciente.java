package dbServlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;
import org.hibernate.Transaction;

import utility.HibernateUtil;
import clinica.Paciente;
import clinica.Diagnostico;

/**
 * Servlet implementation class for Servlet: DbServletEliminaDiagnosticoDelPaciente
 *
 */
 public class DbServletEliminaDiagnosticoDelPaciente extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public DbServletEliminaDiagnosticoDelPaciente() {
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String eleccion;
		Diagnostico diagnosticoAEliminar;
	
		if( HibernateUtil.getSessionFactory() == null )
		{
			HibernateUtil.createSessionFactory();
		}
		if( HibernateUtil.getSession() == null )
		{
			HibernateUtil.createSession();
		}
		if(HibernateUtil.getSession() != null && HibernateUtil.getSessionFactory() != null)
		{
			eleccion = request.getParameter("eleccion");
			if( eleccion != null && eleccion.equals("SI") )
			{
				diagnosticoAEliminar = (Diagnostico)request.getSession().getAttribute("diagnosticoAEliminar");
				if( diagnosticoAEliminar != null )
				{
					//request.getSession().setAttribute("diagnosticoAEliminar", null);
					try
					{
						//Inicia una Transacción
						Transaction transaccion = HibernateUtil.getSession().beginTransaction();
						HibernateUtil.getSession().delete(diagnosticoAEliminar);
						transaccion.commit(); //indica fin y aplicación de la transacción
						response.sendRedirect("do_elimina_diagnostico_del_paciente_ok.jsp"); // <<< FALTA HACER!
					}
					catch( HibernateException hex)
					{
						//System.err.println("Ha ocurrido una Excepción al almacenar un objeto Paciente en la Tabla Clinica.PACIENTES "+ ex);
						//System.err.println("	En DbServletAltaPaciente.doPost :"+ ex);
						String mensaje = "Ha ocurrido una Excepción al eliminar un Diagnóstico de la Tabla Clinica.DIAGNOSTICOS " +
							"En DbServletEliminaDiagnosticoDelPaciente.doPost(request, response) " +
							"Detalles: " + hex;
						request.getSession().setAttribute("mensaje", mensaje);
						response.sendRedirect("error.jsp");
					}
					catch( Exception ex)
					{
						//System.err.println("Ha ocurrido una Excepción al almacenar un objeto Paciente en la Tabla Clinica.PACIENTES "+ ex);
						//System.err.println("	En DbServletAltaPaciente.doPost :"+ ex);
						String mensaje = "Ha ocurrido una Excepción al eliminar un Diagnóstico de la Tabla Clinica.DIAGNOSTICOS " +
							"En DbServletEliminaDiagnosticoDelPaciente.doPost(request, response) " +
							"Detalles: " + ex;
						request.getSession().setAttribute("mensaje", mensaje);
						response.sendRedirect("error.jsp");
					}
					finally
					{
						//closeSession();
						//Para que pueda seguir agregando nuevos objetos paciente
						//HibernateUtil.desconectar(); << NO SE PUEDE usar HibernateUtil.desconctar() aquí
						//DEBE USARSE UNA SOLA VEZ AL HACER CLICK SOBRE EL ENLACE "logout"
						//response.sendRedirect("do_alta_paciente.jsp");
					}
				}
				else
				{
					String mensaje = "ERROR: Ha ocurrido un Error al eliminar un Diagnóstico de la Tabla Clinica.DIAGNOSTICOS " +
					"En DbServletEliminaDiagnosticoDelPaciente.doPost(request, response) " +
					"Detalles: " +
					"El Diagnostico a eliminar no puede ser nulo! ";
					request.getSession().setAttribute("mensaje", mensaje);
					response.sendRedirect("error.jsp");
				}
			}
			if( eleccion != null && eleccion.equals("NO") )
			{
				response.sendRedirect("do_gestion_diagnosticos.jsp");
			}
			if( eleccion == null )
			{
				//System.err.println("ERROR: ASEGURESE DE COMPLETAR TODOS LOS CAMPOS!");
				String mensaje = "ERROR: DEBE ASEGURARSE DE SELECCIONAR SOLO UNA DE LAS OPCIONES DISPONIBLES EN EL FORMULARIO ..! " +
				"DEBE ELEGIR \"SI\" PARA ELIMINAR EL DIAGNOSTICO ..!  " +
				"DEBE ELEGIR \"NO\" PARA CANCELAR LA ELIMINACION DEL DIAGNOSTICO ..! ";
				request.getSession().setAttribute("mensaje", mensaje);
				response.sendRedirect("error.jsp");
			}
		}
	}   	  	    
}