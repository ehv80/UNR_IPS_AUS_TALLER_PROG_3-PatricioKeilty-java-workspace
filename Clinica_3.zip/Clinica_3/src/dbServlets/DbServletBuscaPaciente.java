package dbServlets;



import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;
import org.hibernate.Transaction;

import clinica.Paciente;

import utility.HibernateUtil;

/**
 * Servlet implementation class for Servlet: DbServletBuscaPaciente
 *
 */
 public class DbServletBuscaPaciente extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public DbServletBuscaPaciente() {
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if( HibernateUtil.getSessionFactory() == null )
		{
			HibernateUtil.createSessionFactory();
		}
		if( HibernateUtil.getSession() == null )
		{
			HibernateUtil.createSession();
		}
		if(HibernateUtil.getSession() != null && HibernateUtil.getSessionFactory() != null)
		{
			//Transaction transaccion; << ya lo maneja HibernateUtil.consultaPacientes
			String consultaHQL;
			List<Paciente> listaPacientes;
			Iterator iteradorPacientes;
			try
			{
				//Inicia una Transacción
				//transaccion = HibernateUtil.getSession().beginTransaction();
				consultaHQL = "select p from Paciente as p where 1=1 ";
				listaPacientes = (List<Paciente>)(HibernateUtil.consultaPacientes(consultaHQL));
				if( listaPacientes != null )
				{					
					iteradorPacientes = listaPacientes.iterator();
					//transaccion.commit(); //indica fin y aplicación de la transacción
					request.getSession().setAttribute("iteradorPacientes", iteradorPacientes);
					response.sendRedirect("do_busca_paciente.jsp");
				}
			}
			catch( HibernateException hex)
			{
				//System.err.println("Ha ocurrido una Excepción al ejecutar DbServletBuscaPaciente: " + ex);
				String mensaje = "Ha ocurrido una Excepción al ejecutar DbServletBuscaPaciente.doPost(request, response): " + 
					"Detalles: " + hex;
				request.getSession().setAttribute("mensaje", mensaje);
				response.sendRedirect("error.jsp");
			}
			catch( Exception ex )
			{
				//System.err.println("Ha ocurrido una Excepción al ejecutar DbServletBuscaPaciente: " + ex);
				String mensaje = "Ha ocurrido una Excepción al ejecutar DbServletBuscaPaciente.doPost(request, response): " +
					"Detalles: " + ex;
				request.getSession().setAttribute("mensaje", mensaje);
				response.sendRedirect("error.jsp");
			}
			finally
			{
				//HibernateUtil.desconectar(); << ya lo hace HibernateUtil.consultaPacientes
				//HibernateUtil.closeSession();	<< ya lo hace HibernateUtil.consultaPacientes
				//Pero no cierra el SessionFactory para poder segir en otro intento... << mentira
				//response.sendRedirect("do_alta_diagnostico.jsp");
			}	
		}
		
	}   	  	    
}