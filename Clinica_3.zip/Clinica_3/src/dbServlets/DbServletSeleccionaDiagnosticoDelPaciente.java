package dbServlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import utility.HibernateUtil;
import clinica.Paciente;
import clinica.Diagnostico;

/**
 * Servlet implementation class for Servlet: DbServletSeleccionaDiagnosticoDelPaciente
 *
 */
 public class DbServletSeleccionaDiagnosticoDelPaciente extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public DbServletSeleccionaDiagnosticoDelPaciente() {
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		List<Diagnostico> listaDeDiagnosticosDelPaciente;
		Diagnostico diagnosticoSeleccionado;
		String IdDelDiagnosticoAModificar;
		String consultaHQL;
		
		if( HibernateUtil.getSessionFactory() == null)
		{
			HibernateUtil.createSessionFactory();
		}
		if( HibernateUtil.getSession() == null)
		{
			HibernateUtil.createSession();
		}
		try
		{
			IdDelDiagnosticoAModificar = request.getParameter("IdDelDiagnosticoAModificar");
			consultaHQL = " select d from Diagnostico as d where 1=1 ";
			if(IdDelDiagnosticoAModificar != null && !IdDelDiagnosticoAModificar.equals("") )
			{
				consultaHQL = consultaHQL + " and d.idDiagnostico='" + IdDelDiagnosticoAModificar + "'";
				listaDeDiagnosticosDelPaciente = (List<Diagnostico>)HibernateUtil.consultaDiagnosticos(consultaHQL);
				if( listaDeDiagnosticosDelPaciente != null && !listaDeDiagnosticosDelPaciente.isEmpty() && listaDeDiagnosticosDelPaciente.size() == 1 )
				{
					diagnosticoSeleccionado = (Diagnostico)listaDeDiagnosticosDelPaciente.get(0);//índice de List comienza en cero
					request.getSession().setAttribute("diagnosticoSeleccionado", diagnosticoSeleccionado);
					response.sendRedirect("do_modifica_diagnostico_del_paciente.jsp");
				}
				else
				{
					//request.getSession().setAttribute("diagnosticoSeleccionado" , null);
					String mensaje = "ADVERTENCIA: En consulta HQL al seleccionar un Diagnostico de la Tabla Clinica.DIAGNOSTICOS " + 
					"No existe un Diagnóstico que tenga ese Id de Diagnóstico! " +
					"En DbServletSeleccionaDiagnosticoDelPaciente.doPost(request, response) ";				
					request.getSession().setAttribute("mensaje", mensaje);
					response.sendRedirect("error.jsp");
				}
			}
			else
			{
				String mensaje = "ERROR: En consulta HQL al seleccionar un Diagnóstico de la Tabla Clinica.DIAGNOSTICOS " + 
					"El Id del Diagnóstico no puede ser nulo ..! " +
					"En DbServletSeleccionaDiagnosticoDelPaciente.doPost(request, response) ";
				request.getSession().setAttribute("mensaje", mensaje);
				response.sendRedirect("error.jsp");
			}
		}
		catch(HibernateException hex)
		{
			//System.err.println("Ha ocurrido una Excepción al actualizar un objeto Paciente de la Tabla Clinica.PACIENTES "+ ex);
			//JOptionPane.showMessageDialog(new JFrame(), "Error al actualizar los datos en la Base de Datos...!", "ERROR INESPERADO...!", JOptionPane.ERROR_MESSAGE);
			String mensaje = "Ha ocurrido una Excepción al seleccionar un Diagnóstico de la Tabla Clinica.DIAGNOSTICOS " +
				"En DbServletSeleccionaDiagnosticoDelPaciente.doPost(request, response) " +
				"Detalles: " + hex;				
			request.getSession().setAttribute("mensaje", mensaje);
			response.sendRedirect("error.jsp");
		}
		catch(Exception ex)
		{
			//System.err.println("Ha ocurrido una Excepción al actualizar un objeto Paciente de la Tabla Clinica.PACIENTES "+ ex);
			//JOptionPane.showMessageDialog(new JFrame(), "Error al actualizar los datos en la Base de Datos...!", "ERROR INESPERADO...!", JOptionPane.ERROR_MESSAGE);
			String mensaje = "Ha ocurrido una Excepción al seleccionar un Diagnóstico de la Tabla Clinica.DIAGNOSTICOS " +
				"En DbServletSeleccionaDiagnosticoDelPaciente.doPost(request, response) " +
				"Detalles: " + ex;				
			request.getSession().setAttribute("mensaje", mensaje);
			response.sendRedirect("error.jsp");
		}
		finally
		{
			//closeSession();
		}
	}   	  	    
}