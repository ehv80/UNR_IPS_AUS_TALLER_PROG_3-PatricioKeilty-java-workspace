package dbServlets;

import java.io.IOException;
import java.sql.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;
import org.hibernate.Transaction;

import utility.HibernateUtil;
import clinica.Diagnostico;
import clinica.Paciente;

/**
 * Servlet implementation class for Servlet: DbServletAltaDiagnostico
 *
 */
 public class DbServletAltaDiagnostico extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public DbServletAltaDiagnostico() {
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		if( HibernateUtil.getSessionFactory() == null )
		{
			HibernateUtil.createSessionFactory();
		}
		if( HibernateUtil.getSession() == null )
		{
			HibernateUtil.createSession();
		}
		if(HibernateUtil.getSession() != null && HibernateUtil.getSessionFactory() != null)
		{
			int idDiagnostico;
			String descripcion;
			Date fecha;
			int idPaciente;
			String consultaHQLDePacienteRelacionado;
			Transaction transaccionUno;
			Transaction transaccionDos;
			List<Paciente> listaPacientesRelacionados;
			Diagnostico diagnostico;
			try
			{
				if( !request.getParameter("id_diagnostico").equals("") &&
						!request.getParameter("descripcion").equals("") &&
						!request.getParameter("fecha").equals("") &&
						!request.getParameter("id_paciente").equals("")
					)
				{
					//Obtiene datos del pedido para miembros de instancia de Clase Diagnostico
					idDiagnostico = Integer.parseInt( request.getParameter("id_diagnostico") );
					descripcion = request.getParameter("descripcion");
					fecha = Date.valueOf( request.getParameter("fecha") );
					idPaciente = Integer.parseInt( request.getParameter("id_paciente") );
					try
					{
						consultaHQLDePacienteRelacionado = "select p from Paciente as p where 1=1 " + 
							"and p.idPaciente ='" + String.valueOf(idPaciente) + "'";
						transaccionUno = HibernateUtil.getSession().beginTransaction();
						listaPacientesRelacionados = (List<Paciente>)HibernateUtil.getSession().createQuery(consultaHQLDePacienteRelacionado).list();
						transaccionUno.commit();
						if( !listaPacientesRelacionados.isEmpty() && listaPacientesRelacionados.size() == 1)
						{
							Paciente pacienteRelacionado = listaPacientesRelacionados.get(0); //indice empieza desde cero
							//CONTROL ADICIONAL: NO PUEDE REGISTRAR UN DIAGNOSTICO A UN PACIENTE QUE NO ESTA VIVO
							if( pacienteRelacionado.isEstaVivo() )
							{
								diagnostico = new Diagnostico( idDiagnostico, pacienteRelacionado, descripcion, fecha );
								try
								{
									if(diagnostico != null )
									{
										//Inicia Transacción Dos
										transaccionDos = HibernateUtil.getSession().beginTransaction();
										HibernateUtil.getSession().save(diagnostico);
										transaccionDos.commit(); //indica fin y aplicación de la transacción
										response.sendRedirect("do_alta_diagnostico_ok.jsp");
									}
									else
									{
										//System.err.println("ERROR: Diagnostico es null al guardar en la Tabla Clinica.DIAGNOSTICOS ");
										//System.err.println("	En DbServletAltaDiagnostico");
										//System.err.println("	En Tranascción Dos");
										String mensaje = "ERROR: Diagnostico no puede ser nulo al guardar en la Tabla Clinica.DIAGNOSTICOS " +
											"Producido en: DbServletAltaDiagnostico.doPost(request, response) ";
										request.getSession().setAttribute("mensaje", mensaje);
										response.sendRedirect("error.jsp");
									}
								}
								catch( HibernateException ex)
								{
									//System.err.println("Ha ocurrido una Excepción al almacenar un objeto Diagnostico en la Tabla Clinica.DIAGNOSTICOS "+ ex);
									String mensaje = "Ha ocurrido una Excepción al almacenar un objeto Diagnostico en la Tabla Clinica.DIAGNOSTICOS : " 
										+ "	Detalles: " + ex;
									request.getSession().setAttribute("mensaje", mensaje);
									response.sendRedirect("error.jsp");
								}
							}
							if( !pacienteRelacionado.isEstaVivo() )
							{
								String mensaje = "ERROR: En DbServletAltaDiagnostico.doPost(request, response) " + 
									"Detalles: No puede registrar un Diagnóstico para un Paciente que no está vivo ..! " ;
								request.getSession().setAttribute("mensaje", mensaje);
								response.sendRedirect("error.jsp");
							}
						}
						else
						{
							//Diagnostico para un Paciente que no existe
							//System.err.println("ERROR: generado al ejecutar DbServletAltaDiagnostico.doPost(request, response) ");
							//System.err.println("Quiere ingresar un Diagnostico relacionado a un Paciente que aún no está registrado");
							//System.err.println("	En Transacción: Uno");
							String mensaje = "ERROR: generado al ejecutar DbServletAltaDiagnostico.doPost(request, response) " +
								"Quiere ingresar un Diagnostico relacionado a un Paciente que aún no está registrado " +
								"	En Transacción: Uno ";
							request.getSession().setAttribute("mensaje", mensaje);
							diagnostico = null;
							response.sendRedirect("error.jsp");
						}
					}
					catch(HibernateException hex)
					{
						//System.err.println("Ha ocurrido una Excepción al ejecutar consulta sobre la Tabla Clinica.PACIENTES ");
						//System.err.println("ERROR: generado al ejecutar DbServletAltaDiagnostico.doPost(request, response)");
						//System.err.println("Quiere ingresar un Diagnostico relacionado a un Paciente que aún no está registrado");
						//System.err.println("	En Transacción: Uno");
						String mensaje = "ERROR: generado al ejecutar DbServletAltaDiagnostico.doPost(request, response) " +
							"Quiere ingresar un Diagnostico relacionado a un Paciente que aún no está registrado " +
							"	En Transacción: Uno " +
							"	Detalles: " + hex 
							;
						request.getSession().setAttribute("mensaje", mensaje);
						response.sendRedirect("error.jsp");
					}
				}
				else
				{
					//System.err.println("ERROR: DEBE ASEGURARSE DE COMPLETAR TODOS LOS CAMPOS!");
					String mensaje = "ERROR: DEBE ASEGURARSE DE COMPLETAR TODOS LOS CAMPOS DEL FORMULARIO ..! ";
					request.getSession().setAttribute("mensaje", mensaje);
					response.sendRedirect("error.jsp");
				}
				
			}
			catch(Exception ex)
			{
				//System.err.println("Ha ocurrido una Excepción al recopilar los datos desde el request en DbServletAltaDiagnostico.doPost : " + ex);
				//System.err.println("o bién al consultar la Tabla Clinica.PACIENTES en DbServletAltaDiagnostico: " + ex);
				//System.err.println("o bién al guardar el Diagnostico en la Tabla Clinica.DIAGNOSTICOS en DbServletAltaDiagnostico.doPost : " + ex);
				String mensaje ="Ha ocurrido una Excepción al recopilar los datos desde el request en DbServletAltaDiagnostico.doPost(request, response) " +
					"o bién al consultar la Tabla Clinica.PACIENTES en DbServletAltaDiagnostico.doPost(request, response) " +
					"o bién al guardar el Diagnostico en la Tabla Clinica.DIAGNOSTICOS en DbServletAltaDiagnostico.doPost(request, response) " + 
					"Detalles: " + ex
				;
				request.getSession().setAttribute("mensaje", mensaje);
				response.sendRedirect("error.jsp");
			}			
			finally
			{
				//closeSession();
				//Para que pueda seguir agregando nuevos objetos paciente
				//HibernateUtil.desconectar(); << NO SE PUEDE usar HibernateUtil.desconctar() aquí
				// DEBE USARSE UNA SOLA VEZ AL HACER CLICK SOBRE EL ENLACE "logout"
				//response.sendRedirect("do_alta_paciente.jsp");
			}	
		}
	}   	  	    
}