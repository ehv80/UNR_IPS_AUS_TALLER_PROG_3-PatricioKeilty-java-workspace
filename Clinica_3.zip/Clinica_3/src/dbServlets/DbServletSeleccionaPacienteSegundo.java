package dbServlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import utility.HibernateUtil;
import clinica.Paciente;

/**
 * Servlet implementation class for Servlet: DbServletSeleccionaPacienteSegundo
 *
 */
 public class DbServletSeleccionaPacienteSegundo extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public DbServletSeleccionaPacienteSegundo() {
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Paciente> listaPacientesSeleccionarSegunda;
		Paciente pacienteSeleccionadoSegundo;
		String selectorIdPacienteSeleccionarSegundo;
		String consultaHQL;
		if( HibernateUtil.getSessionFactory() == null)
		{
			HibernateUtil.createSessionFactory();
		}
		if( HibernateUtil.getSession() == null)
		{
			HibernateUtil.createSession();
		}
		try
		{
			selectorIdPacienteSeleccionarSegundo = request.getParameter("selectorIdPacienteSeleccionarSegundo");
			consultaHQL = " select p from Paciente as p where 1=1 ";
			if(selectorIdPacienteSeleccionarSegundo != null && !selectorIdPacienteSeleccionarSegundo.equals("") )
			{
				consultaHQL = consultaHQL + " and p.idPaciente='" + selectorIdPacienteSeleccionarSegundo + "'";
				listaPacientesSeleccionarSegunda = (List<Paciente>)HibernateUtil.consultaPacientes(consultaHQL);
				if( listaPacientesSeleccionarSegunda != null && !listaPacientesSeleccionarSegunda.isEmpty() && listaPacientesSeleccionarSegunda.size() == 1 )
				{
					pacienteSeleccionadoSegundo = (Paciente)listaPacientesSeleccionarSegunda.get(0);//índice de List comienza en cero
					request.getSession().setAttribute("pacienteSeleccionadoSegundo", pacienteSeleccionadoSegundo);
					response.sendRedirect("do_elimina_paciente.jsp");
				}
				else
				{
					request.getSession().setAttribute("pacienteSeleccionadoSegundo", null);
					String mensaje = "ADVERTENCIA: En consulta HQL al seleccionar un Paciente de la Tabla Clinica.PACIENTES " + 
					"No existe un Paciente que tenga ese Id de Paciente! " +
					"En DbServletSeleccionaPacienteSegundo.doPost(request, response) ";				
					request.getSession().setAttribute("mensaje", mensaje);
					response.sendRedirect("error.jsp");
				}
			}
			else
			{
				String mensaje = "ERROR: En consulta HQL al seleccionar un Paciente de la Tabla Clinica.PACIENTES " + 
					"El Id del Paciente no puede ser nulo! " +
					"En DbServletSeleccionaPacienteSegundo.doPost(request, response) ";
				request.getSession().setAttribute("mensaje", mensaje);
				response.sendRedirect("error.jsp");
			}
		}
		catch(HibernateException ex)
		{
			//System.err.println("Ha ocurrido una Excepción al actualizar un objeto Paciente de la Tabla Clinica.PACIENTES "+ ex);
			//JOptionPane.showMessageDialog(new JFrame(), "Error al actualizar los datos en la Base de Datos...!", "ERROR INESPERADO...!", JOptionPane.ERROR_MESSAGE);
			String mensaje = "Ha ocurrido una Excepción al seleccionar un Paciente de la Tabla Clinica.PACIENTES " +
			"En DbServletSeleccionaPacienteSegundo.doPost(request, response) " +
				"Detalles: " + ex;				
			request.getSession().setAttribute("mensaje", mensaje);
			response.sendRedirect("error.jsp");
		}
		finally
		{
			//closeSession();
		}
	}   	  	    
}