package dbServlets;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;
import org.hibernate.Transaction;

import clinica.Paciente;

import utility.HibernateUtil;

/**
 * Servlet implementation class for Servlet: DbServletAltaPaciente
 *
 */
 public class DbServletAltaPaciente extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public DbServletAltaPaciente() {
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		int idPaciente;
		String nombre;
		String apellido;
		Date fechaNac;
		String tpoDoc;
		int nroDoc;
		String obraSocial;
		String sexo;
		boolean estavivo;

		Paciente paciente;
		
		if( HibernateUtil.getSessionFactory() == null )
		{
			HibernateUtil.createSessionFactory();
		}
		if( HibernateUtil.getSession() == null )
		{
			HibernateUtil.createSession();
		}
		if(HibernateUtil.getSession() != null && HibernateUtil.getSessionFactory() != null)
		{
			if( !request.getParameter("id_paciente").equals("") &&
					!request.getParameter("nombre").equals("") &&
					!request.getParameter("apellido").equals("") &&
					!request.getParameter("fecha_nac").equals("") &&
					!request.getParameter("tpo_doc").equals("") &&
					!request.getParameter("nro_doc").equals("") &&
					!request.getParameter("obra_social").equals("") &&
					!request.getParameter("sexo").equals("") &&
					!request.getParameter("estavivo").equals("")
				)
			{	
				//Obtiene datos del pedido para miembros de instancia de Clase Paciente
				idPaciente = Integer.parseInt( request.getParameter("id_paciente") );
				nombre = request.getParameter("nombre");
				apellido = request.getParameter("apellido");
				fechaNac = Date.valueOf( request.getParameter("fecha_nac") );
				tpoDoc = request.getParameter("tpo_doc");
				nroDoc = Integer.parseInt( request.getParameter("nro_doc") );
				obraSocial = request.getParameter("obra_social");
				sexo = request.getParameter("sexo");
				estavivo = Boolean.parseBoolean( request.getParameter("estavivo") );
			
				paciente = new Paciente( 
						idPaciente, nombre, apellido, fechaNac, tpoDoc, nroDoc, obraSocial, sexo, estavivo
					);
				try
				{
					//Inicia una Transacción
					Transaction transaccion = HibernateUtil.getSession().beginTransaction();
					HibernateUtil.getSession().save(paciente);
					transaccion.commit(); //indica fin y aplicación de la transacción
					response.sendRedirect("do_alta_paciente_ok.jsp");
				}
				catch( HibernateException ex)
				{
					//System.err.println("Ha ocurrido una Excepción al almacenar un objeto Paciente en la Tabla Clinica.PACIENTES "+ ex);
					//System.err.println("	En DbServletAltaPaciente.doPost :"+ ex);
					String mensaje = "Ha ocurrido una Excepción al almacenar un objeto Paciente en la Tabla Clinica.PACIENTES " +
						"En DbServletAltaPaciente.doPost(request, response) " +
						"Detalles: " + ex;
					request.getSession().setAttribute("mensaje", mensaje);
					response.sendRedirect("error.jsp");
				}
				finally
				{
					//closeSession();
					//Para que pueda seguir agregando nuevos objetos paciente
					//HibernateUtil.desconectar(); << NO SE PUEDE usar HibernateUtil.desconctar() aquí
					//DEBE USARSE UNA SOLA VEZ AL HACER CLICK SOBRE EL ENLACE "logout"
					//response.sendRedirect("do_alta_paciente.jsp");
				}	
			}
			else
			{
				//System.err.println("ERROR: ASEGURESE DE COMPLETAR TODOS LOS CAMPOS!");
				String mensaje = "ERROR: DEBE ASEGURARSE DE COMPLETAR TODOS LOS CAMPOS DEL FORMULARIO..! ";
				request.getSession().setAttribute("mensaje", mensaje);
				response.sendRedirect("error.jsp");
			}
		}
	}   	  	    
}