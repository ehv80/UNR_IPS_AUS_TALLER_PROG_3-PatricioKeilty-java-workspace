package dbServlets;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;
import org.hibernate.Transaction;

import utility.HibernateUtil;
import clinica.Paciente;
import clinica.Diagnostico;

/**
 * Servlet implementation class for Servlet: DbServletModificaDiagnosticoDelPaciente
 *
 */
 public class DbServletModificaDiagnosticoDelPaciente extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public DbServletModificaDiagnosticoDelPaciente() {
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		int idDiagnostico;
		String descripcion;
		Date fecha;
		int idPaciente;
		
		Diagnostico diagnosticoAModificar;
		
		if( HibernateUtil.getSessionFactory() == null )
		{
			HibernateUtil.createSessionFactory();
		}
		if( HibernateUtil.getSession() == null )
		{
			HibernateUtil.createSession();
		}
		if(HibernateUtil.getSession() != null && HibernateUtil.getSessionFactory() != null)
		{
			if( !request.getParameter("id_diagnostico").equals("") &&
					!request.getParameter("descripcion").equals("") &&
					!request.getParameter("fecha").equals("") &&
					!request.getParameter("id_paciente").equals("")
				)
			{	
				//Obtiene datos del pedido para miembros de instancia de Clase Paciente
				idDiagnostico = Integer.parseInt( request.getParameter("id_diagnostico") );
				descripcion = request.getParameter("descripcion");
				fecha = Date.valueOf( request.getParameter("fecha") );
				idPaciente = Integer.parseInt( request.getParameter("id_paciente") );
			
				diagnosticoAModificar = (Diagnostico)request.getSession().getAttribute("diagnosticoAModificar");
				if( diagnosticoAModificar != null )
				{
					try
					{
						diagnosticoAModificar.setIdDiagnostico(idDiagnostico);//?
						diagnosticoAModificar.setDescripcion(descripcion);
						diagnosticoAModificar.setFecha(fecha);
						diagnosticoAModificar.getPacientes().setIdPaciente(idPaciente);//?
						//Inicia una Transacción
						Transaction transaccion = HibernateUtil.getSession().beginTransaction();
						HibernateUtil.getSession().saveOrUpdate(diagnosticoAModificar);
						transaccion.commit(); //indica fin y aplicación de la transacción
						response.sendRedirect("do_modfica_diagnostico_del_paciente_ok.jsp");
					}
					catch( HibernateException hex)
					{
						//System.err.println("Ha ocurrido una Excepción al almacenar un objeto Paciente en la Tabla Clinica.PACIENTES "+ ex);
						//System.err.println("	En DbServletAltaPaciente.doPost :"+ ex);
						String mensaje = "Ha ocurrido una Excepción al modificar un Diagnóstico de la Tabla Clinica.DIAGNOSTICOS " +
							"En DbServletModificaDiagnosticoDelPaciente.doPost(request, response) " +
							"Detalles: " + hex;
						request.getSession().setAttribute("mensaje", mensaje);
						response.sendRedirect("error.jsp");
					}
					catch( Exception ex)
					{
						//System.err.println("Ha ocurrido una Excepción al almacenar un objeto Paciente en la Tabla Clinica.PACIENTES "+ ex);
						//System.err.println("	En DbServletAltaPaciente.doPost :"+ ex);
						String mensaje = "Ha ocurrido una Excepción al modificar un Diagnóstico de la Tabla Clinica.DIAGNOSTICOS " +
							"En DbServletModificaDiagnosticoDelPaciente.doPost(request, response) " +
							"Detalles: " + ex;
						request.getSession().setAttribute("mensaje", mensaje);
						response.sendRedirect("error.jsp");
					}
					finally
					{
						//closeSession();
						//Para que pueda seguir agregando nuevos objetos paciente
						//HibernateUtil.desconectar(); << NO SE PUEDE usar HibernateUtil.desconctar() aquí
						//DEBE USARSE UNA SOLA VEZ AL HACER CLICK SOBRE EL ENLACE "logout"
						//response.sendRedirect("do_alta_paciente.jsp");
					}
				}
				else
				{
					//		pacienteSeleccionado = new Paciente( 
					//		idPaciente, nombre, apellido, fechaNac, tpoDoc, nroDoc, obraSocial, sexo, estavivo
					//	);
					String mensaje = "ERROR: Ha ocurrido un error al modificar un Diagnóstico de la Tabla Clinica.DIAGNOSTICOS " +
						"En DbServletModificaDiagnosticoDelPaciente.doPost(request, response) " +
						"Detalles: " + 
						"El Diagnóstico a modificar no puede ser nulo ..! ";
					request.getSession().setAttribute("mensaje", mensaje);
					response.sendRedirect("error.jsp");
				}
			}
			else
			{
				//System.err.println("ERROR: ASEGURESE DE COMPLETAR TODOS LOS CAMPOS!");
				String mensaje = "ERROR: DEBE ASEGURARSE DE COMPLETAR TODOS LOS CAMPOS DEL FORMULARIO ..! ";
				request.getSession().setAttribute("mensaje", mensaje);
				response.sendRedirect("error.jsp");
			}
		}
	}   	  	    
}