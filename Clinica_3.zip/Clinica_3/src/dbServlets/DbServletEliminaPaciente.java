package dbServlets;

import java.io.IOException;
import java.sql.Date;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;
import org.hibernate.Transaction;

import utility.HibernateUtil;
import clinica.Diagnostico;
import clinica.Paciente;

/**
 * Servlet implementation class for Servlet: DbServletEliminaPaciente
 *
 */
 public class DbServletEliminaPaciente extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public DbServletEliminaPaciente() {
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String eleccion;
		Paciente pacienteAEliminar;
		if( HibernateUtil.getSessionFactory() == null )
		{
			HibernateUtil.createSessionFactory();
		}
		if( HibernateUtil.getSession() == null )
		{
			HibernateUtil.createSession();
		}
		if(HibernateUtil.getSession() != null && HibernateUtil.getSessionFactory() != null)
		{
			eleccion = request.getParameter("eleccion");
			if( eleccion != null && eleccion.equals("SI") )
			{
				pacienteAEliminar = (Paciente)request.getSession().getAttribute("pacienteAEliminar");
				if( pacienteAEliminar != null )
				{
					request.getSession().setAttribute("pacienteAEliminar", null);
					if( pacienteAEliminar.getDiagnosticoses().isEmpty() )
					{
						try
						{
							//Inicia una Transacción
							Transaction transaccion = HibernateUtil.getSession().beginTransaction();
							HibernateUtil.getSession().delete(pacienteAEliminar);
							transaccion.commit(); //indica fin y aplicación de la transacción
							response.sendRedirect("do_elimina_paciente_ok.jsp");
						}
						catch( HibernateException ex)
						{
							//System.err.println("Ha ocurrido una Excepción al almacenar un objeto Paciente en la Tabla Clinica.PACIENTES "+ ex);
							//System.err.println("	En DbServletAltaPaciente.doPost :"+ ex);
							String mensaje = "Ha ocurrido una Excepción al eliminar un Paciente de la Tabla Clinica.PACIENTES " +
								"En DbServletEliminaPaciente.doPost(request, response) " +
								"Detalles: " + ex;
							request.getSession().setAttribute("mensaje", mensaje);
							response.sendRedirect("error.jsp");
						}
						finally
						{
							//closeSession();
							//Para que pueda seguir agregando nuevos objetos paciente
							//HibernateUtil.desconectar(); << NO SE PUEDE usar HibernateUtil.desconctar() aquí
							//DEBE USARSE UNA SOLA VEZ AL HACER CLICK SOBRE EL ENLACE "logout"
							//response.sendRedirect("do_alta_paciente.jsp");
						}
					}
					if( !pacienteAEliminar.getDiagnosticoses().isEmpty() )
					{
						//Si el Paciente tiene Diagnosticos, no puede eliminarse. Primero se deben eliminar los Diagnosticos que tenga.
						String mensaje = "Ha ocurrido un Error al eliminar un Paciente de la Tabla Clinica.PACIENTES " +
						"En DbServletEliminaPaciente.doPost(request, response) " +
						"Detalles: " + 
						"No puede eliminar un Paciente que posee Diagn&oacute;sticos registrados " +
						"Debe Primero eliminar todos los Diagn&oacute;sticos que tenga el Paciente ..!" ;
					request.getSession().setAttribute("mensaje", mensaje);
					response.sendRedirect("error.jsp");
					}
				}
				else
				{
					String mensaje = "ERROR: Ha ocurrido un Error al eliminar un Paciente de la Tabla Clinica.PACIENTES " +
					"En DbServletEliminaPaciente.doPost(request, response) " +
					"Detalles:  " +
					"El Paciente a eliminar no puede ser nulo ..! ";
					request.getSession().setAttribute("mensaje", mensaje);
					response.sendRedirect("error.jsp");
				}
			}
			if( eleccion != null && eleccion.equals("NO") )
			{
				response.sendRedirect("do_gestion_pacientes.jsp");
			}
			if( eleccion == null )
			{
				//System.err.println("ERROR: ASEGURESE DE COMPLETAR TODOS LOS CAMPOS!");
				String mensaje = "ERROR: DEBE ASEGURARSE DE SELECCIONAR SOLO UNA DE LAS OPCIONES DISPONIBLES EN EL FORMULARIO..! " +
				"DEBE ELEGIR \"SI\" PARA ELIMINAR EL PACIENTE ..! " +
				"DEBE ELEGIR \"NO\" PARA CANCELAR LA ELIMINACION DEL PACIENTE ..! ";
				request.getSession().setAttribute("mensaje", mensaje);
				response.sendRedirect("error.jsp");
			}
		}
	}   	  	    
}