package dbServlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import utility.HibernateUtil;
import clinica.Paciente;

/**
 * Servlet implementation class for Servlet: DbServletSeleccionaPacienteCuarto
 *
 */
 public class DbServletSeleccionaPacienteCuarto extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public DbServletSeleccionaPacienteCuarto() {
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Paciente> listaPacientesSeleccionarCuarta;
		Paciente pacienteSeleccionadoCuarto;
		String selectorIdPacienteSeleccionarCuarto;
		String consultaHQL;
		if( HibernateUtil.getSessionFactory() == null)
		{
			HibernateUtil.createSessionFactory();
		}
		if( HibernateUtil.getSession() == null)
		{
			HibernateUtil.createSession();
		}
		try
		{
			selectorIdPacienteSeleccionarCuarto = request.getParameter("selectorIdPacienteSeleccionarCuarto");
			consultaHQL = " select p from Paciente as p where 1=1 ";
			if(selectorIdPacienteSeleccionarCuarto != null && !selectorIdPacienteSeleccionarCuarto.equals("") )
			{
				consultaHQL = consultaHQL + " and p.idPaciente='" + selectorIdPacienteSeleccionarCuarto + "'";
				listaPacientesSeleccionarCuarta = (List<Paciente>)HibernateUtil.consultaPacientes(consultaHQL);
				if( listaPacientesSeleccionarCuarta != null && !listaPacientesSeleccionarCuarta.isEmpty() && listaPacientesSeleccionarCuarta.size() == 1 )
				{
					pacienteSeleccionadoCuarto = (Paciente)listaPacientesSeleccionarCuarta.get(0);//índice de List comienza en cero
					request.getSession().setAttribute("pacienteSeleccionadoCuarto", pacienteSeleccionadoCuarto);
					response.sendRedirect("do_selecciona_diagnosticos_del_paciente.jsp");
				}
				else
				{
					request.getSession().setAttribute("pacienteSeleccionadoTercero", null);
					String mensaje = "ADVERTENCIA: En consulta HQL al seleccionar un Paciente de la Tabla Clinica.PACIENTES " + 
					"No existe un Paciente que tenga ese Id de Paciente! " +
					"En DbServletSeleccionaPacienteCuarto.doPost(request, response) ";				
					request.getSession().setAttribute("mensaje", mensaje);
					response.sendRedirect("error.jsp");
				}
			}
			else
			{
				String mensaje = "ERROR: En consulta HQL al seleccionar un Paciente de la Tabla Clinica.PACIENTES " + 
					"El Id del Paciente no puede ser nulo! " +
					"En DbServletSeleccionaPacienteCuarto.doPost(request, response) ";
				request.getSession().setAttribute("mensaje", mensaje);
				response.sendRedirect("error.jsp");
			}
		}
		catch(HibernateException hex)
		{
			//System.err.println("Ha ocurrido una Excepción al actualizar un objeto Paciente de la Tabla Clinica.PACIENTES "+ ex);
			//JOptionPane.showMessageDialog(new JFrame(), "Error al actualizar los datos en la Base de Datos...!", "ERROR INESPERADO...!", JOptionPane.ERROR_MESSAGE);
			String mensaje = "Ha ocurrido una Excepción al seleccionar un Paciente de la Tabla Clinica.PACIENTES " +
			"En DbServletSeleccionaPacienteCuarto.doPost(request, response) " +
				"Detalles: " + hex;				
			request.getSession().setAttribute("mensaje", mensaje);
			response.sendRedirect("error.jsp");
		}
		catch(Exception ex)
		{
			//System.err.println("Ha ocurrido una Excepción al actualizar un objeto Paciente de la Tabla Clinica.PACIENTES "+ ex);
			//JOptionPane.showMessageDialog(new JFrame(), "Error al actualizar los datos en la Base de Datos...!", "ERROR INESPERADO...!", JOptionPane.ERROR_MESSAGE);
			String mensaje = "Ha ocurrido una Excepción al seleccionar un Paciente de la Tabla Clinica.PACIENTES " +
			"En DbServletSeleccionaPacienteCuarto.doPost(request, response) " +
				"Detalles: " + ex;				
			request.getSession().setAttribute("mensaje", mensaje);
			response.sendRedirect("error.jsp");
		}
		finally
		{
			//closeSession();
		}
	}   	  	    
}