package clinica;

import java.io.IOException;
import java.io.PrintWriter;
//import java.util.Date;
import java.sql.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;
import org.hibernate.Transaction;

/**
 * Servlet implementation class for Servlet: AltaPaciente
 *
 */
 public class AltaPaciente extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public AltaPaciente() {
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Obtiene datos del pedido para miembros de instancia de Clase Paciente
		int id_paciente = Integer.parseInt( request.getParameter("id_paciente") );
		String nombre = request.getParameter("nombre");
		String apellido = request.getParameter("apellido");
		Date fecha_nac = Date.valueOf( request.getParameter("fecha_nac") );
		String tpo_doc = request.getParameter("tpo_doc");
		int nro_doc = Integer.parseInt( request.getParameter("nro_doc") );
		String obra_social = request.getParameter("obra_social");
		String sexo = request.getParameter("sexo");
		boolean estavivo = Boolean.parseBoolean( request.getParameter("estavivo") );
		
		Paciente paciente = new Paciente( 
				id_paciente, nombre, apellido, fecha_nac, tpo_doc, nro_doc, obra_social, sexo, estavivo
				);
		//PrintWriter out = response.getWriter();
		//out.println(paciente);
		if( HibernateUtil.getSessionFactory() == null )
		{
			HibernateUtil.createSessionFactory();
		}
		if( HibernateUtil.getSession() == null )
		{
			HibernateUtil.createSession();
		}
		if(HibernateUtil.getSession() != null && HibernateUtil.getSessionFactory() != null)
		{
			try
			{
				//Inicia una Transacción
				Transaction transaccion = HibernateUtil.getSession().beginTransaction();
				HibernateUtil.getSession().save(paciente);
				transaccion.commit(); //indica fin y aplicación de la transacción
				response.sendRedirect("do_alta_paciente.jsp");
			}
			catch( HibernateException ex)
			{
				System.err.println("Ha ocurrido una Excepción al almacenar un objeto Paciente "+ ex);
				response.sendRedirect("error.jsp");
			}
			finally
			{
				//closeSession();
				//Para que pueda seguir agregando nuevos objetos paciente
				HibernateUtil.desconectar();
			}	
		}
		
	}   	  	    
}