package clinica;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



/**
 * @author ehv80
 *
 */
public class JConexion {
	
	/**
	 * ATRIBUTOS DE CLASE: static
	 * Uno para todos los objetos que se instancien
	 * de esta Clase.
	 */ 
	private static Connection conexion = null;
	private static Statement sentencia = null;
	private static String nombreClaseDriverJDBC = "com.mysql.jdbc.Driver";
	private static String urlBaseDeDatos = "jdbc:mysql://127.0.0.1/Clinica";
	private static String usuario = "mysql";
	private static String password = "4dm1nsql";
	
	/* ATRIBUTOS DE CADA INSTANCIA DE LA CLASE */
	/* ? */
	
	/* MÉTODOS DE CLASE: static
	 * Uno para todos los objetos que se instancien
	 * de esta Clase.
	 */
	/**
	 * Método de Clase: conectar
	 * Sirve para conectar a la Base de Datos.
	 * 
	 * @param String usuario
	 * @param String contrasenia
	 * @return void
	 * @author ehv80
	 */
	public static void conectar()
	{
		if( conexion == null )
		{
			try {
				Class.forName(nombreClaseDriverJDBC);
				conexion = DriverManager.getConnection(urlBaseDeDatos, usuario, password);
				sentencia = conexion.createStatement();
			}
			catch (SQLException exSQL) {
				System.err.println("No se puede conectar a la Base de Datos..!");
				System.err.println("SQLException: " + exSQL.getMessage());
				System.err.println("SQLState: " + exSQL.getSQLState());
				System.err.println("VendorError: " + exSQL.getErrorCode());				
				
			} 
			catch (ClassNotFoundException exClassNotFound) {
				System.err.println("No se encuentra el driver JDBC..!");
				exClassNotFound.printStackTrace();
			}
		}
	}
	
	/**
	 * Método de Clase: desconectar
	 * Sirve para desconectar de la Base de Datos.
	 * 
	 * @return void
	 */
	public static void desconectar()
	{
		if( conexion != null )
		{
			try {
				sentencia.close();
			}
			catch (SQLException exSQL) {
				System.err.println("No se puede terminar la sentencia SQL..!");
				System.err.println("SQLException: " + exSQL.getMessage());
				System.err.println("SQLState: " + exSQL.getSQLState());
				System.err.println("VendorError: " + exSQL.getErrorCode());
				exSQL.printStackTrace();
			}
			try {
				conexion.close();
			} catch (SQLException exSQL) {
				System.err.println("No se puede cerrar la conexión con la Base de Datos..!");
				System.err.println("SQLException: " + exSQL.getMessage());
				System.err.println("SQLState: " + exSQL.getSQLState());
				System.err.println("VendorError: " + exSQL.getErrorCode());
				exSQL.printStackTrace();
			}
			sentencia = null;
			conexion = null;			
		}
	}
	
	/**
	 * Método de Clase: ejecutarSentencia
	 * Ejecuta la sentencia en lenguaje SQL
	 * que se pasa como argumento: operacion
	 * 
	 * @param String operacion
	 * @return void
	 */
	public static void ejecutarSentencia(String operacion)
	{
		if(sentencia != null)
		{
			try {
				sentencia.executeUpdate(operacion);
			} catch (SQLException exSQL) {
				System.err.println("No se puede ejecutar la sentencia SQL: " + operacion);
				System.err.println("SQLException: " + exSQL.getMessage());
				System.err.println("SQLState: " + exSQL.getSQLState());
				System.err.println("VendorError: " + exSQL.getErrorCode());
				exSQL.printStackTrace();
			}
		}
	}
	
	/**
	 * Método de Clase: consulta
	 * Sirve para obtener un objeto de la clase ResultSet
	 * que tiene el resultado arrojado por una consulta en Lenguaje
	 * SQL hecho sobre la Base de Datos.
	 * 
	 * @param String consultaSQL
	 * @return ResultSet
	 */
	public static ResultSet consulta(String consultaSQL)
	{
		if(sentencia != null)
		{
			ResultSet resultado;
			try {
				resultado = sentencia.executeQuery(consultaSQL);
				return resultado;
			}
			catch (SQLException exSQL) {
				System.err.println("SQLException: " + exSQL.getMessage());
				System.err.println("SQLState: " + exSQL.getSQLState());
				System.err.println("VendorError: " + exSQL.getErrorCode());
				exSQL.printStackTrace();
			}
		}
		//else
		return null;
	}
	
	/**
	 * Constructor 
	 *
	public JConexion() {
		// TODO Auto-generated constructor stub
		conexion = null;
		sentencia = null;
		usuario = "mysql";
		nombreClaseDriverJDBC = "com.mysql.jdbc.Driver";
		urlBaseDeDatos = "jdbc:mysql://127.0.0.1/Clinica";
		password = "4dm1nsql";
	}
	*/
}
