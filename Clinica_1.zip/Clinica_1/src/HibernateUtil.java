

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**		@author ehv80		*/
public class HibernateUtil {

	private static SessionFactory sessionFactory;// = new Configuration().configure().buildSessionFactory();
	private static Session session;

	/**
	 * Inicializa el único SessionFactory para toda la aplicación.
	 * @param void
	 * @return void
	 */
	public static void createSessionFactory()
	{
		try{
			sessionFactory = new Configuration().configure().buildSessionFactory();
		}
		catch(HibernateException ex)
		{
			System.err.println("Ha ocurrido una Excepción al inicializar el SessionFactory "+ex);
		}
	}
	
	/**
	 * Finaliza el único SessionFactory para toda la aplicación.
	 * @param void
	 * @return void
	 */
	public static void closeSessionFactory()
	{
		try{
			sessionFactory.close();
		}
		catch(HibernateException ex)
		{
			System.err.println("Ha ocurrido una Excepción al cerrar el SessionFactory " + ex);
		}
	}
	
	/**
	 * @param void
	 * @return SessionFactory
	 */
	public static SessionFactory getSessionFactory()
	{
		return sessionFactory;
	}
	
	/**
	 * Inicializa estáticamente la Session.
	 * @param void
	 * @return void
	 */
	public static void createSession()
	{
		try
		{
			if(sessionFactory != null )
			{
				session = sessionFactory.openSession();
			}
		}
		catch(HibernateException ex)
		{
			System.err.println("Ha ocurrido una Excepción al inicializar estáticamente la Session " + ex);
		}
	}
	
	/**
	 * Cierra estáticamente la Session.
	 * @param void
	 * @return void
	 */
	public static void closeSession()
	{
		try
		{
			session.close();
		}
		catch(HibernateException ex)
		{
			System.err.println("Ha ocurrido una Excepción al cerrar estáticamente la Session " + ex);
		}
	}
	
	/**
	 * Retorna la Session.
	 * @return Session.
	 */
	public static Session getSession()
	{
		return session;
	}
	
	/**
	 * Conecta mediante createSessionFactory y createSession.
	 */
	public static void conectar()
	{
		createSessionFactory();
		createSession();
	}
	
	/**
	 * Desconecta mediante  closeSession y closeSessionFactory.
	 */
	public static void desconectar()
	{
		closeSession();
		closeSessionFactory();
	}
	
	/**
	 * Almacena objeto Abm en la Base de Datos: Taller3
	 * haciendo uso del método "save" de Session.
	 * @param AbmAlta
	 *
	public static void guardarAbm(Abm abmAlta )
	{
		try
		{
			//Inicia una Transacción
			Transaction transaccion = session.beginTransaction();
			session.save(abmAlta);
			transaccion.commit(); //indica fin y aplicación de la transacción
		}
		catch(HibernateException ex)
		{
			System.err.println("Ha ocurrido una Excepción al almacenar un objeto Abm "+ ex);
			JOptionPane.showMessageDialog(new JFrame(), "Error al almacenar los datos en la Base de Datos...!", "ERROR INESPERADO...!", JOptionPane.ERROR_MESSAGE);
		}
		finally{
			//closeSession();
			//Para que pueda seguir agregando nuevos objetos Abm
		}
	}
	*/
	
	/**
	 * Elimina objeto Abm de la Base de Datos: Taller3
	 * haciendo uso del método "delete" de Session.
	 * @param AbmBaja
	 *
	pulic static void eliminarAbm(Abm abmBaja )
	{
		if(sessionFactory == null)
		{
			createSessionFactory();
		}
		if( session == null)
		{
			createSession();
		}
		try
		{
			//Inicia una Transacción
			Transaction transaccion = session.beginTransaction();
			session.delete(abmBaja);
			transaccion.commit(); //indica fin y aplicación de la transacción
		}
		catch(HibernateException ex)
		{
			System.err.println("Ha ocurrido una Excepción al eliminar un objeto Abm "+ ex);
			JOptionPane.showMessageDialog(new JFrame(), "Error al eliminar los datos en la Base de Datos...!", "ERROR INESPERADO...!", JOptionPane.ERROR_MESSAGE);
		}
		finally {
			closeSession();//?
		}
	}
	*/
	
	/**
	 * Actualiza objeto Abm de la Base de Datos: Taller3
	 * haciendo uso del método "saveOrUpdate" de Session.
	 * @param AbmBaja
	 *
	public static void actualizarAbm(Abm abm )
	{
		if(sessionFactory == null)
		{
			createSessionFactory();
		}
		if( session == null)
		{
			createSession();
		}
		try
		{
			//Inicia una Transacción
			Transaction transaccion = session.beginTransaction();
			session.saveOrUpdate(abm);
			transaccion.commit(); //indica fin y aplicación de la transacción
		}
		catch(HibernateException ex)
		{
			System.err.println("Ha ocurrido una Excepción al actualizar un objeto Abm "+ ex);
			JOptionPane.showMessageDialog(new JFrame(), "Error al actualizar los datos en la Base de Datos...!", "ERROR INESPERADO...!", JOptionPane.ERROR_MESSAGE);
		}
		finally {
			closeSession();//?
		}
	}
	*/
	
	//public static ResultadoConsulta consulta(String consulta)
	/* 
	 * Ejecuta una sentencia en Lenguaje HQL.
	 * @param sentenciaHQL
	 * @return void
	 * 
	public static void ejecutarSentenciaHQL(String sentenciaHQL )
	{
		if( sessionFactory != null && session != null )
		{
			JResultadoConsulta resultadoConsulta;
			try
			{
				resultadoConsulta = new JResultadoConsulta( session.createQuery(sentenciaHQL).list() );
				return resultadoConsulta,
			}
			catch(HibernateException ex)
			{
				System.err.println("Ha ocurrido una Excepción al ejecutar una sentencia HQL " + ex);
				JOptionPane.showMessageDialog(
						new JFrame(),
						"Error extraño al procesar los datos en la Base de Datos...!" ,
						"Advertencia...!", JOptionPane.ERROR_MESSAGE
					);
			}
		}
	}
	*/
	
	/*
	public static JResultadoConsulta consulta(String consultaHQL)
	{
		if( session == null )
		{
			if( sessionFactory == null )
			{
				createSessionFactory();
			}
			createSession();
		}
		JResultadoConsulta resultadoConsulta;
		List <Abm> listaAbm;
		try
		{
			//return new JResultadoConsulta( (List<Abm>)(session.createQuery(consultaHQL).list() ) );
			listaAbm = (List<Abm>) ( session.createQuery(consultaHQL).list() );
			resultadoConsulta = new JResultadoConsulta(listaAbm);
			return resultadoConsulta;
		}
		catch(Exception ex)
		{
			System.err.println("Ha ocurrido una Excepción al ejecutar la consulta HQL " + ex );
			JOptionPane.showMessageDialog(
					new JFrame(),
					"Error al realizar la consulta a la Base de Datos...!",
					"ERROR INESPERADO..!",
					JOptionPane.ERROR_MESSAGE
				);
			return (JResultadoConsulta)null;
		}
		finally
		{
			//TODO
		}
	}
	*/
}
