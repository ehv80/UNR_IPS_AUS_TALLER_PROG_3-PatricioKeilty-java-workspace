#!/bin/bash
#/data/mysql-standard-5.0.24a-linux-i686/bin/mysqld_safe --log -umysql --character-set-server=utf8 --collation-server=utf8_general_ci &
/home/ehv80/mysql-standard-5.0.24a-linux-i686/bin/mysqld_safe --log -umysql --character-set-server=utf8 --collation-server=utf8_general_ci &
