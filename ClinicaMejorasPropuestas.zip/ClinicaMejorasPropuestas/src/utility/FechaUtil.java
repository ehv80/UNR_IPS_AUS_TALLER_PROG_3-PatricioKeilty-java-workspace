/**
 * 
 */
package utility;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Date;

import utility.UserNotification.Level;
import utility.UserNotification;

import javax.servlet.http.HttpServletRequest;

/**
 * @author ehv80
 *
 */
public class FechaUtil 
{
	private static ArrayList<String> listaDeAnios;
	private static ArrayList<String> listaDeMeses;
	private static ArrayList<String> listaDeDias;
	
	/**
	 * M�todo:	getIteradorListaDeAnios
	 * 			Retorna un iterador que posee un listado de a�os entre 1900 y 2099.
	 * 
	 * @return	iteradorListaDeAnios
	 */
	public static Iterator<String> getIteradorListaDeAnios()
	{
		listaDeAnios = new  ArrayList<String>();
		for( int i = 1900 ; i <= 2099 ; i++ )
		{
			String anioTemp = String.valueOf( i );
			listaDeAnios.add( anioTemp );
		}
		Iterator<String> iteradorListaDeAnios = (Iterator<String>)listaDeAnios.iterator();
		return iteradorListaDeAnios;
	}
	
	/**
	 * M�todo:	getIteradorListaDeMeses
	 * 			Retorna un iterador que posee un listado de meses entre 01 y 12.
	 * 
	 * @return	iteradorListaDeMeses
	 */
	public static Iterator<String> getIteradorListaDeMeses()
	{
		listaDeMeses = new ArrayList<String>();
		for( int i = 1 ; i <= 12 ; i++ )
		{
			if( i <= 9 )
			{
				String mesTemp = "0" + String.valueOf(i);
				listaDeMeses.add(mesTemp);
			}
			if( i > 9 )
			{
				String mesTemp = String.valueOf(i);
				listaDeMeses.add(mesTemp);
			}
		}
		Iterator<String> iteradorListaDeMeses = (Iterator<String>) listaDeMeses.iterator();
		return iteradorListaDeMeses;
	}
	
	/**
	 * M�todo:	getIteradorListaDeDias
	 * 			Retorna un iterador que posee un listado de d�as entre 01 y 31.
	 * 
	 * @return	iteradorListaDeDias
	 */
	public static Iterator<String> getIteradorListaDeDias()
	{
		listaDeDias = new ArrayList<String>();
		for( int i = 1 ; i <= 31 ; i++ )
		{
			if( i <= 9 )
			{
				String diaTemp = "0" + String.valueOf(i);
				listaDeDias.add(diaTemp);
			}
			if( i > 9 )
			{
				String diaTemp = String.valueOf(i);
				listaDeDias.add(diaTemp);
			}
		}
		Iterator<String> iteradorListaDeDias = (Iterator<String>) listaDeDias.iterator();
		return iteradorListaDeDias;
	}
	
	/**
	 * M�todo:	validaFecha
	 * 			Verifica si la cadena String cumple con el formato "yyyy-MM-dd" y si representa
	 * 			una fecha v�lida.
	 * 			En caso de representar una fecha v�lida retorna el objeto Date correspondiente.
	 * 			En caso contrario retorna null.
	 *  
	 * @param 	request
	 * @param 	cadenaFecha
	 * @return
	 */
	public static Date validaFecha( HttpServletRequest request, String cadenaFecha )
	{
		String mascaraFecha = "yyyy-MM-dd"; //[a�o]-[mes del a�o]-[d�a del mes]
		Date fecha;
		SimpleDateFormat formateadorFechaSimple;
		try
		{
			formateadorFechaSimple = new SimpleDateFormat( mascaraFecha );
			formateadorFechaSimple.setLenient( false );//no sea indulgente, sino mas bi�n riguroso
			fecha = formateadorFechaSimple.parse( cadenaFecha );
			if( fecha != null )
			{
				return fecha;
			}
			else
			{
				UserNotification.addMessage(request, "Debe seleccionar una Fecha que sea v�lida ..!", Level.ERROR);
				return null;
			}
		}
		catch( ParseException pex )
		{
			UserNotification.addMessage(request, 
					"Debe seleccionar una Fecha que sea v�lida ..! <BR />Detalles : La fecha \"" + cadenaFecha + "\" es incorrecta ..! <BR /> " +
							"Por favor seleccione una Fecha que sea correcta."
					, Level.ERROR);
			return null;
		}
		catch( IllegalArgumentException iaex)
		{
			UserNotification.addMessage(request, 
					"Debe seleccionar una Fecha que sea v�lida ..! <BR />Detalles : La fecha \"" + cadenaFecha + "\" es incorrecta ..! <BR /> " +
					"Por favor seleccione una Fecha que sea correcta.",
					Level.ERROR);
			return null;
		}
	}
	
	/**
	 * M�todo:	getFechaActual
	 * 			Retorna la fecha actual obtenida del sistema operativo subyacente.
	 * 
	 * @return	hoy
	 */
	public static Date getFechaActual()
	{
		Date hoy = new Date( System.currentTimeMillis() );
		return hoy;
	}
	
	/**
	 * M�todo:	getAnioFromDateToStr
	 * 			Extrae a partir de un objeto Date la representaci�n del a�o en formato de cadena String.
	 * 
	 * @param 	fecha
	 * @return	anio
	 */
	public static String getAnioFromDateToStr( Date fecha )
	{
		// getYear() retorna el a�o menos 1900
		int anioNro = ( fecha.getYear() + 1900 );
		String anio = String.valueOf( anioNro );
		return anio;
	}
	
	/**
	 * M�todo:	getMesFromDateToStr
	 * 			Extrae a partir de un objeto Date la representaci�n del mes en formato de cadena String.
	 * 
	 * @param 	fecha
	 * @return	mes
	 */
	public static String getMesFromDateToStr( Date fecha )
	{
		//getMonth() retorna el mes entre 0 y 11
		int mesNro = (fecha.getMonth() + 1 );
		String mes;
		if( mesNro <= 9 )
		{
			mes = "0" + String.valueOf( mesNro );
		}
		else
		{
			mes = String.valueOf(mesNro);
		}
		return mes;
	}
	
	/**
	 * M�todo:	getDiaFromDateToStr
	 * 			Extrae a partir de un objeto Date la representaci�n del d�a en formato de cadena String.
	 * 
	 * @param 	fecha
	 * @return	dia
	 */
	public static String getDiaFromDateToStr( Date fecha )
	{
		//getDate() retorna el d�a entre 1 y 31
		int diaNro = fecha.getDate();
		String dia;
		if( diaNro <= 9 )
		{
			dia = "0" + String.valueOf( diaNro );
		}
		else
		{
			dia = String.valueOf( diaNro );
		}
		return dia;
	}
}