package utility;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

/**
 * Helper utility class to manage form fields values and error messages.
 * Clase de Utilidad que ayuda a manejar los valores y mensajes de error de los campos de un formulario.
 * 
 * @author patricio.keilty@gmail.com
 *
 */
public class FieldValueError
{

	private static final String PARAMS_ERRORS = "form_errors";
	private static final String PARAMS_VALUES = "form_values";
	
	/**
	 * M�todo:	getParamsMap
	 * 			Retorna un HashMap<String, String>, que contiene pares clave-valor, ambos objetos String.
	 * 			Se trata del mapa para almacenar par�metros de un formulario.
	 * 
	 * @author 	patricio.keilty@gmail.com 
	 * @param 	request
	 * @return	mapa
	 */
	private static Map<String, String> getParamsMap( HttpServletRequest request )
	{
		Map<String, String> mapa = (Map<String, String>)request.getAttribute( FieldValueError.PARAMS_VALUES );
		if( mapa == null )
		{
			mapa = new HashMap<String, String>();
			request.setAttribute( FieldValueError.PARAMS_VALUES, mapa );
		}
		return mapa;
	}
	
	/**
	 * M�todo:	getErrorsMap
	 * 			Retorna un HashMap<String, String>, que contiene pares clave-valor ambos objetos String.
	 * 			Se trata del mapa para almacenar los errores relacionados a los par�metros de un formulario.
	 * 
	 * @author 	patricio.keilty@gmail.com
	 * @param 	request
	 * @return 	mapa
	 */
	private static Map<String, String> getErrorsMap( HttpServletRequest request )
	{
		Map<String, String> mapa = (Map<String, String>)request.getAttribute( FieldValueError.PARAMS_ERRORS );
		if( mapa == null )
		{
			mapa = new HashMap<String, String>();
			request.setAttribute( FieldValueError.PARAMS_ERRORS, mapa );
		}
		return mapa;
	}
	
	/**
	 * M�todo:	getFieldValue
	 * 			M�todo auxiliar para obtener el valor de un campo por nombre.
	 * 			Intenta obtenerlo del atributo, sino del param equivalente, y sino lo encuentra retorna vac�o.
	 * 
	 * @author 	patricio.keilty@gmail.com
	 * @param 	fieldName
	 * @param 	request
	 * @return 	value
	 */
	public static String getFieldValue( String fieldName, HttpServletRequest request )
	{
		Map<String, String> mapa = (Map<String, String>)request.getAttribute( FieldValueError.PARAMS_VALUES );
		String value = "";
		String found = null;
		if( mapa != null )
		{
			found = mapa.get( fieldName );
			if( found != null )
			{
				value = found;
			}
			else
			{
				found = request.getParameter( fieldName );
			}
			if( found != null )
			{
				value = found;
			}
		}
		return value;
	}
	
	/**
	 * M�todo:	setFieldValue
	 * 			Introduce una cadena String del valor de un campo de un formulario en el HashMap de Par�metros.
	 * 
	 * @author 	patricio.keilty@gmail.com
	 * @param 	fieldName
	 * @param 	fieldValue
	 * @param 	request
	 */
	public static void setFieldValue( String fieldName, String fieldValue, HttpServletRequest request )
	{
		Map<String, String> mapa = getParamsMap(request);
		mapa.put( fieldName, fieldValue );
	}
	
	/**
	 * M�todo:	getFieldError
	 * 			M�todo auxiliar para obtener la descripci�n del error relacionado a un campo por su nombre.
	 * 
	 * @author 	patricio.keilty@gmail.com
	 * @param 	fieldName
	 * @param 	request
	 * @return	value
	 */
	public static String getFieldError( String fieldName, HttpServletRequest request )
	{
		Map<String, String> mapa = (Map<String, String>)request.getAttribute( FieldValueError.PARAMS_ERRORS );
		String value = "";
		if( mapa != null )
		{
			String valor = mapa.get( fieldName );
			if( valor != null )
			{
				value = valor;
			}
		}
		return value;
	}
	
	/**
	 * M�todo:	setFieldError
	 * 			Introduce una cadena String de un error relacionado a un campo de un formulario en el HashMap de Errores de los Par�metros.
	 * 
	 * @author 	patricio.keilty@gmail.com
	 * @param 	fieldName
	 * @param 	fieldError
	 * @param 	request
	 */
	public static void setFieldError( String fieldName, String fieldError, HttpServletRequest request )
	{
		Map<String, String> mapa = getErrorsMap( request );
		mapa.put( fieldName, fieldError );
	}
}