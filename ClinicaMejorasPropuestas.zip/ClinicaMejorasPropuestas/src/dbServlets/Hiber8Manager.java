package dbServlets;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Hiber8Manager 
{

	private static SessionFactory hibernateSessionFactory;
	
	/**
	 * M�todo:	getHibernateSessionFactory
	 * 			Inicializa el �nico SessionFactory para toda la aplicaci�n.
	 * 
	 * @author 	patricio.keilty@gmail.com
	 * @return	Hiber8Manager.hibernateSessionFactory
	 * @throws 	HibernateException
	 */
	private static SessionFactory getHibernateSessionFactory() throws HibernateException
	{
		if( Hiber8Manager.hibernateSessionFactory == null )
		{
			Hiber8Manager.hibernateSessionFactory = new Configuration().configure().buildSessionFactory();
		}
		return Hiber8Manager.hibernateSessionFactory;
	}

	/**
	 * M�todo:	openHibernateSession
	 * 			Inicializa est�ticamente la Session de Hibernate.
	 * 
	 * @author	patricio.keilty@gmail.com
	 * @param 	void
	 * @return 	getHibernateSessionFactory().openSession();
	 */
	public static Session openHibernateSession() throws HibernateException 
	{
		return getHibernateSessionFactory().openSession();
	}

	/**
	 * M�todo:	closeHibernateSession
	 * 			Cierra est�ticamente la Session de Hibernate.
	 * 
	 * @param hibernateSession
	 * @throws HibernateException
	 */
	public static void closeHibernateSession(Session hibernateSession) throws HibernateException 
	{
		hibernateSession.close();
	}
}