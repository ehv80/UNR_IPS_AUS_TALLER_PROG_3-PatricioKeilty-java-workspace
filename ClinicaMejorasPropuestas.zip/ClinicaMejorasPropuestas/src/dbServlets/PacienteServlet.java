package dbServlets;

import java.io.IOException;

import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import utility.FechaUtil;
import utility.FieldValueError;
import utility.UserNotification;
import utility.UserNotification.Level;

import clinica.Diagnostico;
import clinica.DiagnosticoHome;
import clinica.Paciente;
import clinica.PacienteHome;
import clinica.Usuario;

/**
 * Servlet implementation class for Servlet: PacienteServlet
 * @author ehv80
 */
 public class PacienteServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
 {
	 public static final String PARAM_NOMBRE 			= "nombre";
	 public static final String PARAM_APELLIDO 			= "apellido";
	 public static final String PARAM_ANIO_NACIMIENTO 	= "anioNacimiento";
	 public static final String PARAM_MES_NACIMIENTO 	= "mesNacimiento";
	 public static final String PARAM_DIA_NACIMIENTO 	= "diaNacimiento";
	 public static final String PARAM_TIPO_DOCUMENTO 	= "tipoDeDocumento";
	 public static final String PARAM_NRO_DOCUMENTO 	= "numeroDeDocumento";
	 public static final String PARAM_OBRA_SOCIAL 		= "obraSocial";
	 public static final String PARAM_SEXO 				= "sexo";
	 public static final String PARAM_ESTA_VIVO 		= "estaVivo";
	 
	 public static final String PARAM_TIPO_DOCUMENTO_ANTERIOR 	= "tipoDeDocumentoAnterior";
	 public static final String PARAM_NRO_DOCUMENTO_ANTERIOR 	= "numeroDeDocumentoAnterior";
	 public static final String PARAM_ID_PACIENTE_ANTERIOR 		= "idPacienteAnterior";
	 
	 public static final String PARAM_CRITERIO_CONSULTA 					= "selectorCriterioConsulta";
	 public static final String PARAM_CRITERIO_CONSULTA_NOMBRE 				= "Nombre";
	 public static final String PARAM_CRITERIO_CONSULTA_APELLIDO 			= "Apellido";
	 public static final String PARAM_CRITERIO_CONSULTA_FECHA_NACIMIENTO 	= "Fecha de Nacimiento [Nota: YYYY-MM-DD ]";
	 public static final String PARAM_CRITERIO_CONSULTA_TIPO_DOCUMENTO 		= "Tipo de Documento [Nota: DNI o LC o LE ]";
	 public static final String PARAM_CRITERIO_CONSULTA_NUMERO_DOCUMENTO 	= "Nro. de Documento [Nota: sin los puntos]";
	 public static final String PARAM_CRITERIO_CONSULTA_OBRA_SOCIAL		 	= "Obra Social";
	 public static final String PARAM_CRITERIO_CONSULTA_SEXO 				= "Sexo [Nota: F=femenino , M=masculino ]";
	 public static final String PARAM_CRITERIO_CONSULTA_ESTA_VIVO 			= "Esta con Vida [Nota: 1 indica Paciente vivo]";
	 
	 public static final String PARAM_VALOR_BUSCAR = "valorBuscar";
	 
	 public static final String PARAM_SELECTOR_TIPO_DE_DOCUMENTO 	= "selectorTipoDeDocumento";
	 public static final String PARAM_TIPO_DE_DOCUMENTO_DNI 		= "DNI";
	 public static final String PARAM_TIPO_DE_DOCUMENTO_LC 			= "LC";
	 public static final String PARAM_TIPO_DE_DOCUMENTO_LE 			= "LE";
	 public static final String PARAM_NUMERO_DE_DOCUMENTO_A_BUSCAR 	= "numeroDeDocumentoABuscar";
	 	 
	 public static final String PARAM_ELECCION_ELIMINAR_PACIENTE 	= "eleccionEliminarPaciente";
	 public static final String PARAM_SI 							= "SI";
	 public static final String PARAM_NO 							= "NO";
	 
	 public static final String PARAM_PACIENTE = "Paciente";
	 
	 public static final String LISTA_PACIENTES = "lista_pacientes";
	 
	 public static final String PARAM_ACCION 									= "accion";
	 public static final String ACCION_BORRAR 									= "borrar";
	 public static final String ACCION_ACTUALIZAR 								= "actualizar";
	 public static final String ACCION_LISTAR 									= "listar";
	 public static final String ACCION_GUARDAR 									= "guardar";
	 public static final String ACCION_CONSULTAR 								= "consultar";
	 public static final String ACCION_CONSULTAR_PARA_REGISTRAR 				= "consultarParaRegistrar";
	 public static final String ACCION_SELECCIONAR_PACIENTE_PARA_ACTUALIZAR 	= "seleccionarPacienteParaActualizar";
	 public static final String ACCION_SELECCIONAR_PACIENTE_PARA_BORRAR 		= "seleccionarPacienteParaBorrar";
	 
	 
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public PacienteServlet() 
	{
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	/**
	 * M�todo:	doPost
	 * 			Responsable de seleccionar en base a un par�metro obtenido 
	 * 			a partir de la url, cuando el servlet es invocado desde una
	 * 			p�gina "jsp", la acci�n y el m�todo interno del servlet a ejecutar.
	 * 
	 * @param	request
	 * @param	response
	 * @throws	ServletException
	 * @throws	IOExcepction
	 */
	protected void doPost( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException 
	{
		// para la codificaci�n de caracteres
		request.setCharacterEncoding("UTF-8");
		
		String accion = request.getParameter( PacienteServlet.PARAM_ACCION );
		
		//validar que el usuario est� autenticado
		Usuario usuario = LoginServlet.getUsuarioEnSesion( request );
		if( !UsuarioServlet.ACCION_REGISTRAR.equals( accion ) && usuario == null )
		{
			UserNotification.addMessage(request, 
					"Est� intentando acceder a un recurso restringido para el cual necesita estar autenticado, por favor reg�strese o acceda con su username y su password ..!",
					Level.ERROR);
			request.getRequestDispatcher("index.jsp").forward(request, response);
			return;
		}
		
		//el procesamiento se realiza seg�n el valor del par�metro "accion"
		if( ACCION_LISTAR.equals( accion ) ) 
		{
			doListar( request, response );
		}
		else if( ACCION_CONSULTAR.equals( accion ) )
		{
			doConsultar( request, response, "do_consulta_pacientes.jsp");
		}
		else if( ACCION_CONSULTAR_PARA_REGISTRAR.equals( accion ) )
		{
			doConsultar( request, response, "do_alta_paciente.jsp");
		}
		else if( ACCION_ACTUALIZAR.equals( accion ) )
		{
			doActualizar( request, response );
		}
		else if( ACCION_BORRAR.equals( accion ) )
		{
			doEliminar( request, response );
		}
		else if( ACCION_GUARDAR.equals( accion ) )
		{
			doRegistrar( request, response );
		}
		else if( ACCION_SELECCIONAR_PACIENTE_PARA_ACTUALIZAR.equals( accion ) )
		{
			doSeleccionar( request, response , "do_modifica_paciente.jsp");
		}
		else if( ACCION_SELECCIONAR_PACIENTE_PARA_BORRAR.equals( accion ) )
		{
			doSeleccionar( request, response, "do_elimina_paciente.jsp" );
		}
	}
	
	/**
	 * M�todo:	doRegistrar
	 * 			Responsable de almacenar el registro de los datos de un Paciente en la base de datos: Clinica,
	 * 			Tabla: PACIENTES.
	 * 
	 * 			No se pueden registrar Pacientes distintos con un mismo Tipo y N�mero de Documento.
	 * 
	 * 			Toma del request los par�metros del formulario de edici�n de los datos de un Paciente
	 * 			que est� en la p�gina: "do_alta_paciente.jsp".
	 * 
	 * 			Verifica la validez de los par�metros.
	 * 
	 * 			Verifica la validez de la fecha.
	 * 
	 * 			Verifica la validez del Tipo y N�mero de Documento.
	 * 
	 * 			Verifica que el N�mero de Documento no contenga puntos.
	 * 
	 * 			Verifica que el Tipo y N�mero de Documento no se repitan.
	 * 			
	 * 			En el caso de que los par�metros son v�lidos:
	 * 
	 * 				Almacena el registro del Paciente mediante la invocaci�n al m�todo:
	 * 			
	 * 				PacienteHome.modificaPaciente( paciente )
	 * 
	 * 				Notifica con un mensaje al usuario que le indica el registro satisfactorio del Paciente
	 * 
	 * 				Redirige hacia: "gestor_pacientes_diagnosticos.jsp"
	 * 	
	 * 				Retorna con "return".
	 * 
	 * 				En caso de ocurrir una HibernateException :
	 *
	 *					Notifica con un mensaje al usuario que le indica el error
	 *
	 *				En caso de ocurrir una NumberFormatException :
	 *
	 *					Notifica con un mensaje al usuario que le indica el error
	 *
	 *					Asigna un mensaje de error relacionado al campo N�mero de Documento mediante la invocaci�n
	 *					al m�todo:
	 *
	 *					FieldValueError.setFieldError( PacienteServlet.PARAM_NRO_DOCUMENTO, 
	 *						"El N�mero de Documento debe introducirlo <b>SIN LOS PUNTOS</b> ..!", request);
	 *		
	 * 			En caso de que los par�metros son inv�lidos:
	 * 
	 * 				Notifica con un mensaje al usuario que le indica el error
	 * 
	 * 			Finalmente:
	 * 
	 * 				Completa los campos del formulario de edici�n de los datos de un Paciente
	 * 				mediante la invocaci�n al m�todo:
	 * 
	 * 				setCamposDePaciente( request, nombre, apellido, anioNacimiento, mesNacimiento, diaNacimiento, 
	 *					tipoDeDocumento, numeroDeDocumento, obraSocial, sexo, estaVivo )
	 *
	 *				Asigna los valores de los campos "criterio de consulta" y "valor a buscar" del formulario
	 *			 	de consulta de Pacientes que est�n en la p�gina "do_alta_paciente.jsp"
	 *
	 *				Redirige hacia: "do_alta_paciente.jsp"
	 * 			
	 * @author 	ehv80
	 * @param 	request
	 * @param 	response
	 * @throws 	ServletException
	 * @throws 	IOException
	 */
	private void doRegistrar( HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		/* Toma del request los par�metros ocultos criterio de consulta y valor a buscar para setear en el otro
		 * formulario de consulta de Pacientes		 */
		String criterioConsulta = request.getParameter( PacienteServlet.PARAM_CRITERIO_CONSULTA );
		String valorBuscasdo 	= request.getParameter( PacienteServlet.PARAM_VALOR_BUSCAR );
		
		// Toma del request los par�metros del formulario de alta de Pacientes
		String nombre 				= request.getParameter( PacienteServlet.PARAM_NOMBRE );
		String apellido 			= request.getParameter( PacienteServlet.PARAM_APELLIDO );
		String anioNacimiento 		= request.getParameter( PacienteServlet.PARAM_ANIO_NACIMIENTO );
		String mesNacimiento 		= request.getParameter( PacienteServlet.PARAM_MES_NACIMIENTO );
		String diaNacimiento 		= request.getParameter( PacienteServlet.PARAM_DIA_NACIMIENTO );
		String tipoDeDocumento 		= request.getParameter( PacienteServlet.PARAM_TIPO_DOCUMENTO );
		String numeroDeDocumento 	= request.getParameter( PacienteServlet.PARAM_NRO_DOCUMENTO );
		String obraSocial 			= request.getParameter( PacienteServlet.PARAM_OBRA_SOCIAL );
		String sexo 				= request.getParameter( PacienteServlet.PARAM_SEXO );
		String estaVivo 			= request.getParameter( PacienteServlet.PARAM_ESTA_VIVO );
			
		Date fechaNac;
		Paciente paciente = new Paciente(); //Como registra por primera vez necesita un idPaciente distinto => puedo crear una nueva instancia
		String consultaHQL = "";
			
		boolean validos = paramsValidos( nombre, apellido, anioNacimiento, mesNacimiento, diaNacimiento, tipoDeDocumento, numeroDeDocumento,
				obraSocial, sexo, estaVivo, request);
			
		// verifica que la fecha de Nacimiento sea una fecha correcta
		String fechaNacStr = anioNacimiento + "-" + mesNacimiento + "-" + diaNacimiento;
		fechaNac = FechaUtil.validaFecha( request, fechaNacStr );
		if( fechaNac == null )
		{
			validos = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_DIA_NACIMIENTO, "Debe seleccionar una Fecha que sea v�lida ..!", request);
		}
		// verifica el campo tipo de documento
		if( tipoDeDocumento == null || tipoDeDocumento.trim().equals("") )
		{
			validos = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_TIPO_DOCUMENTO, "Este campo no puede ser vac�o ..!", request);
		}
		// verifica el campo N�mero de documento.
		if( numeroDeDocumento == null || numeroDeDocumento.trim().equals("") )
		{
			validos = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_NRO_DOCUMENTO, "Este campo no puede ser vac�o ..!", request);
		}
		if( numeroDeDocumento.contains(".") )
		{
			validos = false;
			FieldValueError.setFieldError(PacienteServlet.PARAM_NRO_DOCUMENTO, "El N�mero de Documento debe introducirlo <b>SIN LOS PUNTOS</b> ..!",
					request);
		}
		// verifica que no haya un Paciente registrado con ese tipo y N�mero de documento
		if( tipoDeDocumento != null && !tipoDeDocumento.trim().equals("") && 
				numeroDeDocumento != null && !numeroDeDocumento.trim().equals("") )
		{	/*
			 * ESTA PORCI�N DE C�DIGO COMENTADA:
			 * NO SIRVE PORQUE SOLO BUSCA A PACIENTES "VIVOS" CON ESE TIPO Y NRO. DE DOCUMENTO
			 * paciente = new Paciente( null, null, null, tipoDeDocumento, Integer.parseInt( numeroDeDocumento ), null, null, true);
			 */
			/* ESTA PORCI�N DE C�DIGO COMENTADA:
			 * NO FUNCIONA PORQUE DEJA GUARDAR DOS Pacientes DISTINTOS CON MISMO TIPO Y NRO. DE DOCUMENTO
			 * paciente.setTpoDoc(tipoDeDocumento);
			 * paciente.setNroDoc( Integer.parseInt( numeroDeDocumento ) );
			 * List<Paciente> listaDePacientes = PacienteHome.encontrarPorEjemplo( paciente );//?
			 */
			try
			{
				// Obtiene una lista de Pacientes que tengan ese Tipo y N�mero de Documento mediante una consulta HQL
				consultaHQL = "select p from Paciente as p where p.tpoDoc = '" + tipoDeDocumento +"' and p.nroDoc = '" + numeroDeDocumento + "'";
				List<Paciente> listaDePacientes = PacienteHome.consultaPacientes( consultaHQL );
				if( !listaDePacientes.isEmpty() )
				{
					validos = false;
					FieldValueError.setFieldError( PacienteServlet.PARAM_NRO_DOCUMENTO, 
						"Este Tipo y N�mero de Documento corresponden a otro Paciente registrado , por favor verifique si son correctos y vuelva a intentarlo ..!",
						request);
				}
			}
			catch(HibernateException hex)
			{
				UserNotification.addMessage(request,
						"Ha ocurrido un error al acceder a la base de datos. Por favor comun�quelo al administrador del sitio.",
						Level.ERROR);
			}
		}
			
		if( validos )
		{
			try
			{
				paciente.setNombre( 		nombre 										);
				paciente.setApellido( 		apellido 									);
				paciente.setFechaNac( 		fechaNac 									);				
				paciente.setTpoDoc( 		tipoDeDocumento								);
				paciente.setNroDoc( 		Integer.parseInt( numeroDeDocumento ) 		);
				paciente.setObraSocial( 	obraSocial 									);
				paciente.setSexo( 			sexo 										);
				paciente.setEstaVivo( 		Boolean.valueOf( estaVivo ).booleanValue() 	);
				
				PacienteHome.modificaPaciente( paciente );
				
				UserNotification.addMessage( request, "El Paciente ha sido registrado satisfactoriamente ..!", Level.INFO);
				
				request.getRequestDispatcher("gestor_pacientes_diagnosticos.jsp").forward(request, response);
				
				return;
			}
			catch( HibernateException e )
			{
				UserNotification.addMessage(request,
					"Ha ocurrido un error al acceder a la base de datos. Por favor comun�quelo al administrador del sitio.",
					Level.ERROR);
			}
			catch( NumberFormatException nfex )
			{
				UserNotification.addMessage(request,
					"Ha ocurrido un error: por favor verifique los datos ingresados ..!",
					Level.ERROR);
				FieldValueError.setFieldError( PacienteServlet.PARAM_NRO_DOCUMENTO, 
						"El N�mero de Documento debe introducirlo <b>SIN LOS PUNTOS</b> ..!", request);
			}
		}
		else
		{
			UserNotification.addMessage( request, "Ha ocurrido un error, por favor verifique los datos ingresados ..!", Level.ERROR);
		}
		setCamposDePaciente( request, nombre, apellido, anioNacimiento, mesNacimiento, diaNacimiento, 
				tipoDeDocumento, numeroDeDocumento, obraSocial, sexo, estaVivo );
		FieldValueError.setFieldValue( PacienteServlet.PARAM_CRITERIO_CONSULTA, criterioConsulta, request);
		FieldValueError.setFieldValue( PacienteServlet.PARAM_VALOR_BUSCAR, valorBuscasdo, request );
		request.getRequestDispatcher("do_alta_paciente.jsp").forward(request, response);
	}
	
	/**
	 * M�todo:	doEliminar
	 * 			Responsable de borrar el registro de los datos de un Paciente en la base de datos: Clinica,
	 * 			Tabla: PACIENTES.
	 * 
	 * 			Toma del request el par�metro del formulario de confirmaci�n de eliminaci�n
	 * 			del registro del Paciente que est� en la p�gina: "do_elimina_paciente.jsp".
	 * 			
	 * 			Obtiene el paciente desde el HttpSession mediante la invocaci�n al m�todo:
	 *			
	 *			Paciente paciente = (Paciente)request.getSession().getAttribute( PacienteServlet.PARAM_PACIENTE );
	 * 			
	 * 			que previamente fue seteado en la p�gina: "do_elimina_paciente.jsp"
	 * 
	 * 			En caso de que la opci�n elegida es eliminar el registro del paciente:
	 * 			
	 * 				Verifica mediante una consulta HQL a la Base de Datos: Clinica, Tabla: DIAGNOSTICOS
	 * 				si el paciente que va a eliminar posee diagn�sticos registrados a su nombre:
	 * 
	 * 					En caso de que el paciente que va a eliminar posee diagn�sticos:
	 * 
	 * 						Notifica al usuario que no va a poder eliminar el paciente
	 * 
	 * 					En caso de que el paciente que va a eliminar no posee diagn�sticos:
	 * 
	 * 						Elimina el registro del paciente mediante la invocaci�n al m�todo:
	 * 						
	 * 						PacienteHome.eliminaPaciente( paciente )
	 * 
	 * 						Notifica al usuario la eliminaci�n satisfactoria del registro del paciente
	 * 
	 *						Redirige hacia: "gestor_pacientes_diagnosticos.jsp"
	 * 
	 * 						Retorna con "return"
	 * 
	 * 					En caso de que ocurra una HibernateException:
	 * 
	 * 						Notifica al usuario con un mensaje de error
	 * 
	 * 			En caso de que la opci�n elegida es no eliminar el registro del paciente:
	 * 
	 * 				Notifica al usuario con un mensaje
	 * 
	 * 			En otro caso:
	 * 
	 * 				Notifica al usuario con un mensaje que le indica que debe elegir por SI o por NO
	 * 
	 * 				Asigna el mensaje de error del formulario de selecci�n del Paciente correspondiente al atributo nombrado:

	 * 				PacienteServlet.PARAM_ELECCION_ELIMINAR_PACIENTE
	 * 
	 * 			Finalmente:
	 * 
	 * 				Para que al clickear en el bot�n de Eliminar se mantengan las opciones elegidas en 
	 * 				el formulario del selector por Tipo y N�mero de Documento, que est� en la p�gina:
	 * 				"do_elimina_paciente.jsp":
	 * 
	 * 					Asigna el campo del selector por Tipo de Documento mediante la invocaci�n al m�todo:
	 * 
	 * 					FieldValueError.setFieldValue( PacienteServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO, paciente.getTpoDoc() , request);
	 * 
	 * 					Asigna el campo del selector por N�mero de Documento mediante la invocaci�n al m�todo:
	 * 
	 *					FieldValueError.setFieldValue( PacienteServlet.PARAM_NUMERO_DE_DOCUMENTO_A_BUSCAR, String.valueOf( paciente.getNroDoc() ), request);
	 * 
	 * 					Pone en el request al atributo nombrado: PacienteServlet.PARAM_PACIENTE
	 * 					con el valor: paciente
	 * 
	 * 
	 * 				El par�metro del formulario de confirmaci�n de eliminaci�n del registro del Paciente 
	 * 				lo asigna mediante la invocaci�n al m�todo:
	 * 
	 * 				FieldValueError.setFieldValue( PacienteServlet.PARAM_ELECCION_ELIMINAR_PACIENTE, eleccionEliminaPaciente , request);
	 * 
	 *  			para que al redirigir 
	 * 				hacia "do_elimina_paciente.jsp" se mantenga la opci�n elegida.
	 * 				
	 * 				Redirige hacia: "do_elimina_paciente.jsp"
	 * 
	 * @param 	request
	 * @param 	response
	 * @throws 	IOException
	 * @throws 	ServletException
	 */
	private void doEliminar(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String eleccionEliminaPaciente = request.getParameter( PacienteServlet.PARAM_ELECCION_ELIMINAR_PACIENTE );
		
		// para evitar otra consulta a la base de datos: obtiene el paciente desde el HttpSession mediante el m�todo
		
		Paciente paciente = (Paciente)request.getSession().getAttribute( PacienteServlet.PARAM_PACIENTE );
				
		if( paciente != null )
		{
			if( eleccionEliminaPaciente != null && eleccionEliminaPaciente.equals( PacienteServlet.PARAM_SI ) ) 
			{
				try 
				{	
					String consultaHQL = 
						"select d from Diagnostico as d where d.paciente.idPaciente = '" + String.valueOf( paciente.getIdPaciente() ) + "'";
					
					List<Diagnostico> listaDeDiagnosticosDelPaciente = DiagnosticoHome.consultaDiagnosticos( consultaHQL );
					
					if( listaDeDiagnosticosDelPaciente == null || listaDeDiagnosticosDelPaciente.isEmpty() )
					{
						PacienteHome.eliminaPaciente( paciente );
						
						UserNotification.addMessage( request, "Los datos del Paciente han sido borrados satisfactoriamente del sistema.", Level.INFO);
						
						request.getRequestDispatcher("gestor_pacientes_diagnosticos.jsp").forward(request, response);
						
						return;
					}
					else
					{
						UserNotification.addMessage( request, 
								"Advertencia: Tenga en cuenta que por cuestiones de seguridad de la informaci�n no podr� eliminar un Paciente " +
								"que tenga Diagn�sticos registrados. En su lugar deber� primero eliminar todos los Diagn�sticos que tenga " +
								"el Paciente y luego podr� eliminar el Paciente.",
								Level.ERROR	);
					}
				}
				catch( HibernateException hex )
				{
					UserNotification.addMessage(request,
							"Ha ocurrido un error al acceder a la base de datos. Por favor comun�quelo al administrador del sitio.",
							Level.ERROR);
				}
			}
			else if( eleccionEliminaPaciente != null && eleccionEliminaPaciente.equals( PacienteServlet.PARAM_NO ) )
			{
				UserNotification.addMessage(request, "Usted ha elegido NO ELIMINAR Los datos del Paciente.", Level.INFO);
			}
			else
			{
				UserNotification.addMessage(request, "Advertencia: Debe confirmar si desea Eliminar el Paciente ..!", Level.ERROR);
				FieldValueError.setFieldError( PacienteServlet.PARAM_ELECCION_ELIMINAR_PACIENTE, "Debe elegir por \"SI\" o por \"NO\" ..!", request);
			}	
		}
		
		// Para que al clickear en el bot�n de Eliminar los datos del Paciente no me borre los datos del selector por Tipo y N�mero de Documento:
		FieldValueError.setFieldValue( PacienteServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO, paciente.getTpoDoc() , request);
		FieldValueError.setFieldValue( PacienteServlet.PARAM_NUMERO_DE_DOCUMENTO_A_BUSCAR, String.valueOf( paciente.getNroDoc() ), request);
		
		//pone el paciente como atributo del request, necesario para la p�gina: "do_elimina_paciente.jsp"
		request.setAttribute( PacienteServlet.PARAM_PACIENTE, paciente );
		
		// lo asigna para el formulario de confirmaci�n de eliminaci�n de un Paciente que est� en la p�gina: "do_elimina_paciente.jsp"
		FieldValueError.setFieldValue( PacienteServlet.PARAM_ELECCION_ELIMINAR_PACIENTE, eleccionEliminaPaciente , request);

		request.getRequestDispatcher("do_elimina_paciente.jsp").forward(request, response);
	}
	
	/**
	 * M�todo:	doSeleccionar
	 * 			Responsable de seleccionar el registro de un paciente que obtiene mediante una
	 * 			consulta HQL por Tipo y N�mero de Documento a la Base de datos: Clinica, 
	 * 			Tabla: PACIENTES.
	 * 			
	 * 			Toma del request los par�metros del formulario de selecci�n de un paciente por Tipo y 
	 * 			N�mero de Documento.
	 * 			
	 * 			Verifica la validez de los par�metros, el Tipo y N�mero de Documento.
	 * 
	 * 			Verifica que el N�mero de Documento no contenga puntos.
	 * 
	 * 			En caso de que los par�metros son v�lidos:
	 * 			
	 * 			Realiza la consulta HQL por Tipo y N�mero de Documento mediante la invocaci�n al
	 * 			m�todo: 
	 * 			
	 * 			PacienteHome.consultaPacientes( consultaHQL )
	 * 
	 * 			De la consulta HQL obtiene un objeto List<Paciente> que posee la lista de pacientes
	 * 			que tienen ese Tipo y N�mero de Documento. Siempre deber�a contener un solo paciente,
	 * 			o bi�n, ninguno.
	 * 
	 * 			En el caso de que el paciente se encuentra en la lista:
	 * 
	 * 				Obtiene el paciente de la lista
	 * 
	 * 				Verifica el valor de la cadena String "urlDestino":
	 * 
	 * 					En caso de que la "urlDestino" es "do_modifica_paciente.jsp":
	 * 
	 * 				 		Completa los campos del formulario de edici�n de los datos de un Paciente mediante
	 * 				  		la invocaci�n al m�todo: 
	 * 
	 * 						setCamposDePaciente(request, paciente)
	 * 
	 * 						Pone en el request al atributo nombrado: PacienteServlet.PARAM_PACIENTE
	 * 						con el valor: paciente
	 * 
	 * 			En caso de que el paciente no se encuentra en la lista:
	 * 
	 * 				Notifica al usuario con un mensaje
	 * 
	 * 				Completa los campos del formulario de selecci�n de un paciente por Tipo y N�mero de Documento
	 * 		
	 * 			En caso de que los par�metros son inv�lidos:
	 * 
	 * 			Notifica al usuario con un mensaje
	 * 
	 * 			Completa los campos del formulario de selecci�n de un paciente por Tipo y N�mero de Documento
	 * 
	 * 			Luego redirige la respuesta hacia la "urlDestino".
	 * 
	 * @param 	request
	 * @param 	response
	 * @param 	urlDestino
	 * @throws 	ServletException
	 * @throws 	IOException
	 */
	private void doSeleccionar( HttpServletRequest request, HttpServletResponse response , String urlDestino ) throws ServletException, IOException
	{
		String tipoDeDocumento 	= request.getParameter( PacienteServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO );
		String numeroDeDocumeto	= request.getParameter( PacienteServlet.PARAM_NUMERO_DE_DOCUMENTO_A_BUSCAR );
				
		String consultaHQL;
		Paciente paciente;
		List<Paciente> listaDePacientes;
		
		boolean validos = true;
		
		// verifica el campo tipo de documento del formulario selector de Pacientes
		if( tipoDeDocumento == null || tipoDeDocumento.trim().equals("") )
		{
			validos = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO, 
					"Debe seleccionar uno de los Tipos de Documentos: DNI o LE o LC. ", request);
		}
		
		// verifica el campo n�mero de documento del formulario selector de Pacientes
		if( numeroDeDocumeto == null || numeroDeDocumeto.trim().equals("") )
		{
			validos = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_NUMERO_DE_DOCUMENTO_A_BUSCAR, 
					"El campo N�mero de Documento no puede ser vac�o.", request);
		}
		if( numeroDeDocumeto.contains(".") )
		{
			validos = false;
			FieldValueError.setFieldError(PacienteServlet.PARAM_NUMERO_DE_DOCUMENTO_A_BUSCAR,
					"El N�mero de Documento debe introducirlo <b>SIN LOS PUNTOS</b> ..!", request);
		}
		
		if( validos )
		{
			try
			{
				consultaHQL = "select p from Paciente as p where p.tpoDoc = '" + tipoDeDocumento + "' and p.nroDoc = '" + numeroDeDocumeto + "'";
				listaDePacientes = PacienteHome.consultaPacientes( consultaHQL );
				if( !listaDePacientes.isEmpty() && listaDePacientes.size() == 1 )
				{
					paciente = listaDePacientes.get(0);
					if( urlDestino.equals( "do_modifica_paciente.jsp" ) )
					{
						setCamposDePaciente(request, paciente);
					}
					request.setAttribute( PacienteServlet.PARAM_PACIENTE, paciente );
				}
				else
				{
					UserNotification.addMessage( request, 
						"El Tipo y N�mero de Documento que ha introducido no corresponden a un Paciente registrado en la Base de Datos. <BR />" +
						"Por favor verifique los datos ingresados e intente nuevamente. <BR />",
						Level.ERROR);
				}
			}
			catch( HibernateException hex)
			{
				UserNotification.addMessage(request,
						"Ha ocurrido un error al acceder a la base de datos. Por favor comun�quelo al administrador del sitio.",
						Level.ERROR);
			}
		}
		else
		{
			UserNotification.addMessage( request, 
					"Debe ingresar un Tipo y N�mero de Documento en el selector de Pacientes ..!",
					Level.ERROR);
		}
		FieldValueError.setFieldValue( PacienteServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO, 	tipoDeDocumento, 	request);
		FieldValueError.setFieldValue( PacienteServlet.PARAM_NUMERO_DE_DOCUMENTO_A_BUSCAR, 	numeroDeDocumeto, 	request);
		request.getRequestDispatcher( urlDestino ).forward(request, response);
	}
		
	/**
	 * M�todo:	doActualizar
	 * 			Responsable de actualizar el registro de los datos de un Paciente 
	 * 			en la Base de datos: Clinica, Tabla: PACIENTES.
	 * 			
	 * 			Toma del request los par�metros ocultos del formulario de edici�n
	 * 			de los datos de un Paciente que est�n en la p�gina: 
	 * 			"do_modifica_paciente.jsp", nombrados: 
	 * 
	 * 				PacienteServlet.PARAM_TIPO_DOCUMENTO_ANTERIOR
	 * 
	 * 				PacienteServlet.PARAM_NRO_DOCUMENTO_ANTERIOR
	 * 
	 * 				PacienteServlet.PARAM_ID_PACIENTE_ANTERIOR
	 * 
	 * 			para poder controlar que no existan registros de pacientes distintos
	 * 			con un mismo Tipo y N�mero de Documento al realizar la actualizaci�n.
	 * 		
	 *			Toma del request los restantes par�metros del formulario de edici�n de 
	 *			los datos de un paciente para poder realizar la actualizaci�n del registro
	 *			del paciente con esos nuevos datos.
	 *
	 *			Obtiene el paciente desde el HttpSession mediante la invocaci�n al m�todo:
	 *
	 *			Paciente paciente = (Paciente)request.getSession().getAttribute( PacienteServlet.PARAM_PACIENTE );
	 *
	 *			que previamente fue seteado en la p�gina: "do_modifica_paciente.jsp" 
	 *
	 *			Verifica la validez de los par�metros.
	 *
	 *			Verifica la validez de la fecha de nacimiento del paciente.
	 *
	 *			Verifica que el nuevo Tipo y N�mero de Documento no pertenezca 
	 *			a un usuario que ya est� registrado en la Base de datos, pues 
	 *			no pueden existir registros de pacientes distintos que tengan 
	 *			el mismo Tipo y N�mero de Documento.
	 *			
	 *			En el caso de que los par�metros son v�lidos:
	 *
	 *				Actualiza el registro de los datos del paciente mediante la
	 *				invocaci�n al m�todo: 
	 *
	 *				PacienteHome.modificaPaciente( paciente )
	 *
	 *				Notifica al usuario con un mensaje que le indica la actualizaci�n
	 *				satisfactoria del registro de los datos del paciente
	 *
	 *				Redirige hacia: "gestor_pacientes_diagnosticos.jsp"
	 *
	 *				Retorna con "return"
	 *
	 *				En el caso de que ocurre una HibernateException:
     *
     *					Notifica al usuario con un mensaje de error
     *
	 *				En el caso de que ocurre una NumberFormatException :
	 *
	 *					Notifica con un mensaje al usuario que le indica el error
	 *
	 *					Asigna un mensaje de error relacionado al campo N�mero de Documento mediante la invocaci�n
	 *					al m�todo:
	 *
	 *					FieldValueError.setFieldError( PacienteServlet.PARAM_NRO_DOCUMENTO, 
	 *						"El N�mero de Documento debe introducirlo <b>SIN LOS PUNTOS</b> ..!", request);
	 *
	 *			En el caso de que los par�metros son inv�lidos:
	 *
	 *				Notifica al usuario con un mensaje de error
	 *
	 *			Finalmente:
	 *
	 *				Completa los campos del formulario de edici�n de los datos de un paciente 
	 *				mediante la invocaci�n al m�todo: 
	 *				
	 *				setCamposDePaciente(request, nombre, apellido, anioNacimiento, mesNacimiento, diaNacimiento,
     *										tipoDeDocumento, numeroDeDocumento, obraSocial, sexo, estaVivo )
     *			
     *				Completa los campos del formulario de selecci�n de un paciente por Tipo y
     *				N�mero de Documento
     *			
     *				Pone en el request al atributo nombrado: PacienteServlet.PARAM_PACIENTE
     *				con el valor: paciente
     *
     *				Redirige hacia: "do_modifica_paciente.jsp"
     *
	 * @param 	request
	 * @param 	response
	 * @throws	ServletException
	 * @throws 	IOException
	 */
	private void doActualizar( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException 
	{
		// Toma del request los par�metros ocultos para setear los par�metros del formulario de selecci�n del Paciente
		String tipoDeDocumentoAnterior		= request.getParameter( PacienteServlet.PARAM_TIPO_DOCUMENTO_ANTERIOR );
		String numeroDeDocumentoAnterior	= request.getParameter( PacienteServlet.PARAM_NRO_DOCUMENTO_ANTERIOR ) ;

		// Toma del request otro par�metro oculto necesario para realizar chequeo 
		String idPacienteAnteriorStr 		= request.getParameter( PacienteServlet.PARAM_ID_PACIENTE_ANTERIOR );
		int idPacienteAnterior				= Integer.parseInt( idPacienteAnteriorStr );
		
		//Toma del request los par�metros para setear los par�metros del formulario de actualizaci�n de datos del Paciente
		String nombre 				= request.getParameter( PacienteServlet.PARAM_NOMBRE 			);
		String apellido 			= request.getParameter( PacienteServlet.PARAM_APELLIDO 			);
		String anioNacimiento 		= request.getParameter( PacienteServlet.PARAM_ANIO_NACIMIENTO 	);
		String mesNacimiento 		= request.getParameter( PacienteServlet.PARAM_MES_NACIMIENTO 	);
		String diaNacimiento 		= request.getParameter( PacienteServlet.PARAM_DIA_NACIMIENTO 	);
		String tipoDeDocumento 		= request.getParameter( PacienteServlet.PARAM_TIPO_DOCUMENTO 	);
		String numeroDeDocumento 	= request.getParameter( PacienteServlet.PARAM_NRO_DOCUMENTO 	);
		String obraSocial 			= request.getParameter( PacienteServlet.PARAM_OBRA_SOCIAL 		);
		String sexo 				= request.getParameter( PacienteServlet.PARAM_SEXO 				);
		String estaVivo 			= request.getParameter( PacienteServlet.PARAM_ESTA_VIVO 		);
			
		Date fechaNac;
			
		//Alternativa para no hacer otra consulta a la base de datos: obtiene el paciente desde el HttpSession mediante la invocaci�n al m�todo
		Paciente paciente = (Paciente)request.getSession().getAttribute( PacienteServlet.PARAM_PACIENTE );
		
		String consultaHQL = "";
		
		boolean validos = paramsValidos( nombre, apellido, anioNacimiento, mesNacimiento, diaNacimiento, tipoDeDocumento, numeroDeDocumento,
				obraSocial, sexo, estaVivo, request);

		//verifica que la fecha sea una fecha correcta
		String fechaNacStr = anioNacimiento + "-" + mesNacimiento + "-" + diaNacimiento;
		fechaNac = FechaUtil.validaFecha( request, fechaNacStr );
		if( fechaNac == null )
		{
			validos = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_DIA_NACIMIENTO, "Debe seleccionar una Fecha que sea v�lida ..!", request);
		}
		//verifica si el campo tipo de documento es inadecuado
		if( tipoDeDocumento == null || tipoDeDocumento.trim().equals("") )
		{
			validos = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_TIPO_DOCUMENTO, "Este campo no puede ser vac�o ..!", request);
		}
		// verifica si el campo N�mero de documento es inadecuado
		if( numeroDeDocumento == null || numeroDeDocumento.trim().equals("") )
		{
			validos = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_NRO_DOCUMENTO, "Este campo no puede ser vac�o ..!", request);
		}
		//verifica SI HAY OTRO Paciente (otro idPaciente) registrado con ese tipo y n�mero de Documento
		if( tipoDeDocumento.equals( tipoDeDocumentoAnterior ) && !numeroDeDocumento.equals( numeroDeDocumentoAnterior ) )
		{
			/*
			* ESTA PORCI�N C�DIGO EST� COMENTADA: 
			* NO FUNCIONA PORQUE DEJA GUARDAR DOS Pacientes DISTINTOS CON MISMO TIPO Y NRO. DE DOCUMENTO
			* Paciente sample = new Paciente();
			* sample.setTpoDoc(tipoDeDocumento);
			* sample.setNroDoc(Integer.parseInt( numeroDeDocumento ) );
			* List<Paciente> listaDePacientes = PacienteHome.encontrarPorEjemplo( sample );
			*/
			try
			{
				// Obtiene una lista de Pacientes que tengan los nuevos Tipo y N�mero de Documento (si es que el usuario los cambi�)
				// mediante una consulta HQL
				consultaHQL = "select p from Paciente as p where p.tpoDoc = '" + tipoDeDocumento +"' and p.nroDoc = '" + numeroDeDocumento + "'";
				List<Paciente> listaDePacientes = PacienteHome.consultaPacientes( consultaHQL );
				if( !listaDePacientes.isEmpty() )
				{
					if( listaDePacientes.size() == 1 && listaDePacientes.get(0).getIdPaciente() != idPacienteAnterior )
					{
						validos = false;
						FieldValueError.setFieldError( PacienteServlet.PARAM_NRO_DOCUMENTO, 
								"Este Tipo y N�mero de Documento corresponden a otro Paciente registrado, " +
								"por favor verifique si son correctos y vuelva a intentarlo ..!",
								request);
					}
				}
			}
			catch( HibernateException hex)
			{
				UserNotification.addMessage(request, 
						"Ha ocurrido un error al acceder a la base de datos. Por favor comun�quelo al administrador del sitio.",
						Level.ERROR);
			}
		}
			
		if( validos )
		{
			try
			{
				paciente.setNombre( 		nombre 										);
				paciente.setApellido( 		apellido 									);
				paciente.setFechaNac( 		fechaNac 									);				
				paciente.setTpoDoc( 		tipoDeDocumento								);
				paciente.setNroDoc( 		Integer.parseInt( numeroDeDocumento ) 		);
				paciente.setObraSocial( 	obraSocial 									);
				paciente.setSexo( 			sexo 										);
				paciente.setEstaVivo( 		Boolean.valueOf( estaVivo ).booleanValue() 	);
				
				PacienteHome.modificaPaciente( paciente );
				
				UserNotification.addMessage( request, "Los datos del Paciente han sido modificados satisfactoriamente ..!", Level.INFO);
				
				request.getRequestDispatcher("gestor_pacientes_diagnosticos.jsp").forward(request, response);
				
				return;
			}
			catch( HibernateException hex)
			{
				UserNotification.addMessage(request, 
						"Ha ocurrido un error al acceder a la base de datos. Por favor comun�quelo al administrador del sitio.",
						Level.ERROR);
			}
			catch( NumberFormatException nfex )
			{
				UserNotification.addMessage(request,
					"Ha ocurrido un error: por favor verifique los datos ingresados ..!",
					Level.ERROR);
				FieldValueError.setFieldError( PacienteServlet.PARAM_NRO_DOCUMENTO, 
						"El N�mero de Documento debe introducrirlo <b>SIN LOS PUNTOS</b> ..!", request);
			}
		}
		else
		{
				UserNotification.addMessage(request, "Ha ocurrido un error, por favor verifique los datos ingresados ..!", UserNotification.Level.ERROR);
		}

		setCamposDePaciente(request, nombre, apellido, anioNacimiento, mesNacimiento, diaNacimiento,
			tipoDeDocumento, numeroDeDocumento, obraSocial, sexo, estaVivo );
		
		// Para que al clickear el el bot�n de Actualizar los datos del Paciente no borre los datos del selector por Tipo y N��mero de Documento
		FieldValueError.setFieldValue( PacienteServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO , tipoDeDocumentoAnterior, request);
		FieldValueError.setFieldValue( PacienteServlet.PARAM_NUMERO_DE_DOCUMENTO_A_BUSCAR, numeroDeDocumentoAnterior, request);
		
		request.setAttribute( PacienteServlet.PARAM_PACIENTE, paciente );
		
		request.getRequestDispatcher( "do_modifica_paciente.jsp" ).forward(request, response);
	}
	
	/**
	 * M�todo:	doListar
	 * 			Realiza una consulta HQL para obtener un objeto List<Paciente>
	 * 			que posee la lista de todos los Pacientes registrados en la 
	 * 			Base de datos: Clinica, Tabla: PACIENTES, mediante la invocaci�n
	 * 			al m�todo: setListaPacientes( request )
	 * 			En caso de ocurrir una HibernateException notifica al usuario con un mensaje de error.
	 * 			Finalmente redirige hacia la p�gina: "do_modifica_paciente.jsp"
	 * 
	 * 			Este m�todo no se est� usando actualmente, por considerarse una mala pr�ctica
	 * 			de programaci�n: "seleccionar todos los registros de una Tabla en una Base de Datos".
	 * 
	 * @param 	request
	 * @param 	response
	 * @throws 	ServletException
	 * @throws 	IOException
	 */
	private void doListar( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException 
	{
		try
		{
			setListaPacientes( request );
		}
		catch( HibernateException hex)
		{
			UserNotification.addMessage( request, 
					"Ha ocurrido un error al acceder a la base de datos. Por favor comun�quelo al administrador del sitio.",
					Level.ERROR);
		}
		request.getRequestDispatcher( "do_modifica_paciente.jsp" ).forward( request, response );
	}
	
	/**
	 * M�todo:	doConsultar
	 * 			Realiza una consulta HQL en la Base de datos: Clinica, Tabla: PACIENTES 
	 * 			de acuerdo a un criterio de b�squeda y un valor a buscar suministrados 
	 * 			por los par�metros del formulario de consulta de un paciente, que est�
	 * 			en las p�ginas:
	 * 			
	 * 				"do_consulta_pacientes.jsp"
	 * 
	 * 				"do_alta_paciente.jsp"
	 * 
	 * 			Si la cadena String "urlDestino" es "do_alta_paciente.jsp" toma del request
	 * 			los par�metros ocultos del formulario de consulta de un paciente
	 * 			seg�n un criterio de b�squeda y un valor a buscar, 
	 * 			que est� en la p�gina: "do_alta_paciente.jsp". 
	 * 			Luego invoca al m�todo:
	 *  		
	 *  		setCamposDePaciente(request, nombre, apellido, anioNacimiento, mesNacimiento, diaNacimiento, 
	 *					tipoDeDocumento, numeroDeDocumento, obraSocial, sexo, estaVivo)
	 *			
	 *			para que se mantengan los datos que el usuario ha introducido en el formulario de edici�n
	 *			de los datos de un paciente que est� en la misma p�gina: "do_alta_paciente.jsp", cuando el
	 *			usuario realiza la consulta por criterio de b�squeda y valor a buscar.
	 * 
	 * 			Toma del request los par�metros del formulario de consulta de un paciente 
	 * 			seg�n un criterio de b�squeda y un valor a buscar. Estos mismos par�metros
	 * 			los asigna a los campos del mismo formulario mediante la invocaci�n a los
	 * 			m�todos:
	 * 
	 * 			FieldValueError.setFieldValue(PacienteServlet.PARAM_CRITERIO_CONSULTA, criterioBusqueda, request)
	 * 			
	 * 			FieldValueError.setFieldValue(PacienteServlet.PARAM_VALOR_BUSCAR, valorBuscar, request)
	 * 
	 * 			En el caso de que los par�metros son v�lidos:
	 * 			
	 * 			Realiza la consulta HQL a la Base de datos: Clinica, Tabla: PACIENTES,
	 * 			mediante la invocaci�n al m�todo: 
	 * 
	 * 			setListaPacientes(request, criterioBusqueda, valorBuscar)
	 * 
	 * 			En caso de ocurrir una HibernateException:
	 * 			
	 * 				Notifica al usuario con un mensaje de error
	 * 			
	 * 			En el caso de que los par�metros son inv�lidos:
	 * 			
	 * 				Notifica al usuario con un mensaje de error
	 * 
	 * 			Finalmente redirige hacia: "urlDestino"
	 * 			
	 * @param 	request
	 * @param 	response
	 * @throws 	ServletException
	 * @throws 	IOException
	 */
	private void doConsultar( HttpServletRequest request, HttpServletResponse response, String urlDestino ) throws ServletException, IOException
	{
		// si urlDestino es "do_alta_paciente.jsp" toma los campos ocultos para setear los campos del formulario de alta de Pacientes
		if( urlDestino != null && urlDestino.trim().equals("do_alta_paciente.jsp") )
		{
			String nombre 				= request.getParameter( PacienteServlet.PARAM_NOMBRE );
			String apellido 			= request.getParameter( PacienteServlet.PARAM_APELLIDO );
			String anioNacimiento 		= request.getParameter(PacienteServlet.PARAM_ANIO_NACIMIENTO );
			String mesNacimiento 		= request.getParameter( PacienteServlet.PARAM_MES_NACIMIENTO );
			String diaNacimiento 		= request.getParameter( PacienteServlet.PARAM_DIA_NACIMIENTO );
			String tipoDeDocumento		= request.getParameter( PacienteServlet.PARAM_TIPO_DOCUMENTO );
			String numeroDeDocumento	= request.getParameter( PacienteServlet.PARAM_NRO_DOCUMENTO );
			String obraSocial			= request.getParameter( PacienteServlet.PARAM_OBRA_SOCIAL );
			String sexo					= request.getParameter(PacienteServlet.PARAM_SEXO );
			String estaVivo				= request.getParameter(PacienteServlet.PARAM_ESTA_VIVO );
			
			setCamposDePaciente(request, nombre, apellido, anioNacimiento, mesNacimiento, diaNacimiento, 
				tipoDeDocumento, numeroDeDocumento, obraSocial, sexo, estaVivo);
		}
		
		String criterioBusqueda = request.getParameter( PacienteServlet.PARAM_CRITERIO_CONSULTA );
		String valorBuscar = request.getParameter( PacienteServlet.PARAM_VALOR_BUSCAR );
		
		//sean null, o n�, los pongo como atributo del request para asignarlos al formulario de consulta de Pacientes
		FieldValueError.setFieldValue(PacienteServlet.PARAM_CRITERIO_CONSULTA, criterioBusqueda, request);
		FieldValueError.setFieldValue(PacienteServlet.PARAM_VALOR_BUSCAR, valorBuscar, request);
		
		if( criterioBusqueda != null && !criterioBusqueda.trim().equals("") && valorBuscar != null && !valorBuscar.trim().equals("") )
		{
			try
			{
				setListaPacientes(request, criterioBusqueda, valorBuscar);
			}
			catch( HibernateException hex)
			{
				UserNotification.addMessage(request, 
						"Ha ocurrido un error al acceder a la base de datos. Por favor comun�quelo al administrador del sitio.",
						Level.ERROR);
			}
		}
		else
		{
			UserNotification.addMessage( request, 
					"Debe seleccionar un criterio de b�squeda y completar con el valor que desea buscar ..!",
					Level.ERROR);
		}
		request.getRequestDispatcher( urlDestino ).forward( request, response );
	}
	
	/**
	 * M�todo:	paramsValidos
	 * 			Responsable de validar los par�metros del formulario de edici�n de los datos referidos a un Paciente.
	 * 
	 * @param 	nombreReal
	 * @param 	apellido
	 * @param 	nombreAcceso
	 * @param 	claveAcceso
	 * @param 	request
	 * @return	ok
	 */
	private boolean paramsValidos( String nombre, String apellido, String anioNacimiento, String mesNacimiento, String diaNacimiento, 
			String tipoDeDocumento, String numeroDeDocumento, String obraSocial, String sexo, String estaVivo,  HttpServletRequest request) 
	{
		boolean ok = true;
		String mensaje = "Este campo no puede ser vac�o ..!";
		if( nombre == null || nombre.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_NOMBRE, mensaje, request);
		}
		if( apellido == null || apellido.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_APELLIDO, mensaje, request);
		}
		if( anioNacimiento == null || anioNacimiento.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_ANIO_NACIMIENTO, mensaje, request);
		}
		if( mesNacimiento == null || mesNacimiento.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_MES_NACIMIENTO, mensaje, request);
		}
		if( diaNacimiento == null || diaNacimiento.trim().equals(""))
		{
			ok = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_DIA_NACIMIENTO, mensaje, request);
		}
		if( tipoDeDocumento == null || tipoDeDocumento.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_TIPO_DOCUMENTO, mensaje, request);
		}
		if( numeroDeDocumento == null || numeroDeDocumento.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_NRO_DOCUMENTO, mensaje, request);
		}
		if( obraSocial == null || obraSocial.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_OBRA_SOCIAL, mensaje, request);
		}
		if( sexo == null || sexo.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_SEXO, mensaje, request);
		}
		if( estaVivo == null || estaVivo.trim().equals(""))
		{
			ok = false;
			FieldValueError.setFieldError( PacienteServlet.PARAM_ESTA_VIVO, mensaje, request);
		}
		return ok;
	}
		
	/**
	 * M�todo:	setListaPacientes
	 * 			M�todo auxiliar para agregar al request la lista de todos los Pacientes registrados en la Base de Datos: Clinica,
	 * 			Tabla: PACIENTES.
	 * 
	 * 			No se ha utilizado en este proyecto por considerarse una mala pr�ctica de programaci�n: "seleccionar todos los registros 
	 * 			de una Tabla en una Base de Datos".
	 * 
	 * @param request
	 */
	private void setListaPacientes( HttpServletRequest request )
	{
		String consultaHQL = "select p from Paciente as p";
		List<Paciente> listaDePacientes = PacienteHome.consultaPacientes( consultaHQL );
		request.setAttribute( PacienteServlet.LISTA_PACIENTES , listaDePacientes );
	}
	
	/**
	 * M�todo:	setListaPacientes
	 * 			M�todo auxiliar para agregar al request la lista de todos los Pacientes 
	 * 			registrados que cumplen con un criterio de b�squeda	y un valor a buscar.
	 * 
	 * @param 	request
	 * @param 	criterioBusqueda
	 * @param 	valorBuscar
	 */
	private void setListaPacientes( HttpServletRequest request, String criterioBusqueda, String valorBuscar )
	{
		String consultaHQL = "";
		if( criterioBusqueda.trim().equals( PacienteServlet.PARAM_CRITERIO_CONSULTA_NOMBRE ) )
		{
			consultaHQL = "select p from Paciente as p where p.nombre = '" + valorBuscar + "'";
		}
		else if( criterioBusqueda.trim().equals( PacienteServlet.PARAM_CRITERIO_CONSULTA_APELLIDO ) )
		{
			consultaHQL = "select p from Paciente as p where p.apellido = '" + valorBuscar + "'";
		}
		else if( criterioBusqueda.trim().equals( PacienteServlet.PARAM_CRITERIO_CONSULTA_FECHA_NACIMIENTO ) )
		{
			Date fecha = FechaUtil.validaFecha( request, valorBuscar );
			if( fecha != null )
			{
				consultaHQL = "select p from Paciente as p where p.fechaNac = '" + valorBuscar + "'";
			}
			else
			{
				UserNotification.addMessage(request, 
						"La fecha que introduce como valor a buscar debe respetar el siguiente formato: \"YYYY-MM-DD\" <BR />" +
						"es decir, 4 cifras para el a�o, seguidas de un gui�n medio, luego 2 cifras para el mes, <BR />" +
						" seguidas de otro gui�n medio, y a continuaci�n 2 cifras para el d�a. <BR />" +
						"Por favor intente nuevamente teniendo en cuenta esta aclaraci�n.", 
						UserNotification.Level.ERROR);
				return;
			}
		}
		else if( criterioBusqueda.trim().equals( PacienteServlet.PARAM_CRITERIO_CONSULTA_TIPO_DOCUMENTO ) )
		{
			if( valorBuscar.trim().equals("DNI") || valorBuscar.trim().equals("LE") || valorBuscar.trim().equals("LC") )
			{
				consultaHQL = "select p from Paciente as p where p.tpoDoc = '" + valorBuscar + "'";
			}
			else
			{
				UserNotification.addMessage(request, 
						"Cuando realiza la consulta seleccionando el criterio de b�squeda: <BR />" + 
						"\"" + PacienteServlet.PARAM_CRITERIO_CONSULTA_TIPO_DOCUMENTO + "\"" +
						" debe introducir como valor a buscar la frase: <BR />" +
						"\"DNI\" para consultar por Documento Nacional de Identidad; o bi�n <BR />" +
						"la frase: \"LE\" para consultar por Libreta de Enrolamiento; o bi�n <BR />" +
						"la frase: \"LC\" para consultar por Libreta C�vica <BR />" +
						"Por favor intente nuevamente teniendo en cuenta esta aclaraci�n." , 
						UserNotification.Level.ERROR);
				return;
			}
		}
		else if( criterioBusqueda.trim().equals( PacienteServlet.PARAM_CRITERIO_CONSULTA_NUMERO_DOCUMENTO ) )
		{
			if( valorBuscar.contains(".") )
			{
				UserNotification.addMessage(request, "Ha ocurrido un error: por favor verifique los datos ingresados ..!", 
						UserNotification.Level.ERROR);
				FieldValueError.setFieldError( PacienteServlet.PARAM_VALOR_BUSCAR, "El N�mero de Documento debe introducirlo <b>SIN LOS PUNTOS</b> ..!",
						request);
			}
			consultaHQL = "select p from Paciente as p where p.nroDoc = '" + valorBuscar + "'";
		}
		else if( criterioBusqueda.trim().equals( PacienteServlet.PARAM_CRITERIO_CONSULTA_OBRA_SOCIAL ) )
		{
			consultaHQL = "select p from Paciente as p where p.obraSocial = '" + valorBuscar + "'";
		}
		else if( criterioBusqueda.trim().equals( PacienteServlet.PARAM_CRITERIO_CONSULTA_SEXO ) )
		{
			if( valorBuscar.trim().equals("F") || valorBuscar.trim().equals("M") )
			{
				consultaHQL = "select p from Paciente as p where p.sexo = '" + valorBuscar + "'";
			}
			else
			{
				UserNotification.addMessage( request, 
						"Cuando realiza la consulta seleccionando el criterio de b�squeda: <BR />" +
						"\"" + PacienteServlet.PARAM_CRITERIO_CONSULTA_SEXO + "\" debe introducir como valor a buscar <BR />" +
						"la letra: \"F\" para consultar por Pacientes de sexo femenino; o bi�n <BR />" +
						"la letra: \"M\" para consultar por Pacientes de sexo masculino <BR />" +
						"Por favor intente nuevamente teniendo en cuenta esta aclaraci�n.", 
						Level.ERROR );
				return;
			}
		}
		else if( criterioBusqueda.trim().equals( PacienteServlet.PARAM_CRITERIO_CONSULTA_ESTA_VIVO ) )
		{
			if( valorBuscar.trim().equals("1") || valorBuscar.trim().equals("0") )
			{
				consultaHQL = "select p from Paciente as p where p.estaVivo = '" + valorBuscar  + "'";
			}
			else
			{
				UserNotification.addMessage(request, 
						"Cuando realiza la consulta seleccionando el criterio de b�squeda: <BR />" +
						"\"" + PacienteServlet.PARAM_CRITERIO_CONSULTA_ESTA_VIVO + "\" <BR />" +
						"debe introducir como valor a buscar el caracter num�rico:<BR />" +
						" uno: 1 para buscar Pacientes con vida (true); o bi�n <BR />" +
						"cero: 0 para buscar Pacientes que han fallecido (false).<BR />" +
						" Por favor intente nuevamente teniendo en cuenta esta aclaraci�n.", 
						UserNotification.Level.ERROR);
				return;
			}
		}
		List<Paciente> listaDePacientes = PacienteHome.consultaPacientes( consultaHQL );
		request.setAttribute( PacienteServlet.LISTA_PACIENTES , listaDePacientes );
	}
	
	/**
	 * M�todo:	setCamposDePaciente
	 * 			M�todo auxiliar para completar los campos del formulario de edici�n de los datos
	 * 			referidos a un Paciente.
	 * 			En este caso extrae los datos del objeto Paciente que toma como argumento.
	 * 
	 * @param 	request
	 * @param 	paciente
	 */
	private void setCamposDePaciente( HttpServletRequest request, Paciente paciente )
	{
		if( paciente != null )
		{
			Date fechaNac 	= paciente.getFechaNac();
			String anioNac 	= FechaUtil.getAnioFromDateToStr( 	fechaNac );
			String mesNac 	= FechaUtil.getMesFromDateToStr( 	fechaNac );
			String diaNac	= FechaUtil.getDiaFromDateToStr( 	fechaNac );
			
			FieldValueError.setFieldValue( PacienteServlet.PARAM_NOMBRE, 	paciente.getNombre(), 	request );
			FieldValueError.setFieldValue( PacienteServlet.PARAM_APELLIDO, 	paciente.getApellido(), request );
			
			FieldValueError.setFieldValue( PacienteServlet.PARAM_ANIO_NACIMIENTO, 	anioNac, 	request );
			FieldValueError.setFieldValue( PacienteServlet.PARAM_MES_NACIMIENTO, 	mesNac, 	request );
			FieldValueError.setFieldValue( PacienteServlet.PARAM_DIA_NACIMIENTO, 	diaNac, 	request );
			
			FieldValueError.setFieldValue( PacienteServlet.PARAM_TIPO_DOCUMENTO, 	paciente.getTpoDoc(), 						request );
			FieldValueError.setFieldValue( PacienteServlet.PARAM_NRO_DOCUMENTO, 	String.valueOf( paciente.getNroDoc() ), 	request );
			FieldValueError.setFieldValue( PacienteServlet.PARAM_OBRA_SOCIAL, 		paciente.getObraSocial(), 					request );
			FieldValueError.setFieldValue( PacienteServlet.PARAM_SEXO, 				paciente.getSexo(), 						request );
			FieldValueError.setFieldValue( PacienteServlet.PARAM_ESTA_VIVO, 		String.valueOf( paciente.isEstaVivo() ), 	request );
		}
		else
		{
			UserNotification.addMessage( request, 
					"Ha ocurrido un error al autocompletar los campos del formulario. Intente nuevamente.",
					Level.ERROR);
		}
	}
	
	/**
	 * M�todo:	setCamposDePaciente
	 * 			M�todo auxiliar para completar los campos del formulario de edici�n de los datos 
	 * 			referidos a un Paciente.
	 * 			En este caso extrae los datos a partir de los argumentos del propio m�todo.
	 *  
	 * @param 	request
	 * @param 	nombre
	 * @param 	apellido
	 * @param 	anioNacimiento
	 * @param 	mesNacimiento
	 * @param 	diaNacimiento
	 * @param 	tipoDeDocumento
	 * @param 	numeroDeDocumento
	 * @param 	obraSocial
	 * @param 	sexo
	 * @param 	estaVivo
	 */
	private void setCamposDePaciente( HttpServletRequest request, String nombre, String apellido , String anioNacimiento, String mesNacimiento,
			String diaNacimiento, String tipoDeDocumento, String numeroDeDocumento, String obraSocial, String sexo, String estaVivo )
	{
		FieldValueError.setFieldValue( PacienteServlet.PARAM_NOMBRE, 			nombre, 			request );
		FieldValueError.setFieldValue( PacienteServlet.PARAM_APELLIDO,	 		apellido, 			request );
		FieldValueError.setFieldValue( PacienteServlet.PARAM_ANIO_NACIMIENTO, 	anioNacimiento, 	request );
		FieldValueError.setFieldValue( PacienteServlet.PARAM_MES_NACIMIENTO, 	mesNacimiento, 		request );
		FieldValueError.setFieldValue( PacienteServlet.PARAM_DIA_NACIMIENTO, 	diaNacimiento, 		request );
		FieldValueError.setFieldValue( PacienteServlet.PARAM_TIPO_DOCUMENTO, 	tipoDeDocumento, 	request );
		FieldValueError.setFieldValue( PacienteServlet.PARAM_NRO_DOCUMENTO, 	numeroDeDocumento, 	request );
		FieldValueError.setFieldValue( PacienteServlet.PARAM_OBRA_SOCIAL, 		obraSocial, 		request );
		FieldValueError.setFieldValue( PacienteServlet.PARAM_SEXO, 				sexo, 				request );
		FieldValueError.setFieldValue( PacienteServlet.PARAM_ESTA_VIVO, 		estaVivo, 			request );
	}
}