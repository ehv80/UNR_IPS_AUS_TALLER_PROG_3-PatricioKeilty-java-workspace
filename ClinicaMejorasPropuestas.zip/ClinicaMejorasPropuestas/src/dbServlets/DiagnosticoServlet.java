package dbServlets;

import java.io.IOException;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import utility.FechaUtil;
import utility.FieldValueError;
import utility.UserNotification;
import utility.UserNotification.Level;

import clinica.Diagnostico;
import clinica.DiagnosticoHome;
import clinica.Paciente;
import clinica.PacienteHome;
import clinica.Usuario;

/**
 * Servlet implementation class for Servlet: DiagnosticoServlet
 *
 */
 public class DiagnosticoServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
 {
	public static final String ACCION_ACTUALIZAR 										= "actualizar";
	public static final String ACCION_BORRAR 											= "borrar";
	public static final String ACCION_GUARDAR 											= "guardar";
	public static final String ACCION_SELECCIONAR_PACIENTE_PARA_ACTUALIZAR_DIAGNOSTICO 	= "seleccionarPacienteParaActualizarDiagnostico";
	public static final String ACCION_SELECCIONAR_PACIENTE_PARA_ELIMINAR_DIAGNOSTICO 	= "seleccionarPacienteParaEliminarDiagnostico";
	public static final String ACCION_SELECCIONAR_PACIENTE_PARA_CONSULTAR_DIAGNOSTICOS	= "seleccionarPacienteParaConsultarDiagnosticos";
	public static final String ACCION_SELECCIONAR_DIAGNOSTICO_PARA_ACTUALIZAR 			= "seleccionarDiagnosticoParaActualizar";
	public static final String ACCION_SELECCIONAR_DIAGNOSTICO_PARA_ELIMINAR 			= "seleccionarDiagnosticoParaEliminar";
	 
	public static final String PARAM_TIPO_DOCUMENTO 	= "tipoDeDocumento";
	public static final String PARAM_NRO_DOCUMENTO 		= "numeroDeDocumento";
	public static final String PARAM_ANIO 				= "anio";
	public static final String PARAM_MES 				= "mes";
	public static final String PARAM_DIA 				= "dia";
	public static final String PARAM_DESCRIPCION		= "descripcion";
	public static final String PARAM_ID_DIAGNOSTICO		= "idDiagnostico";
	 
	public static final String PACIENTE					= "paciente";
	public static final String DIAGNOSTICO				= "diagnostico";
	public static final String LISTA_DE_DIAGNOSTICOS	= "listaDeDiagnosticos";
	 
	public static final String PARAM_SELECTOR_TIPO_DE_DOCUMENTO 		= "selectorTipoDeDocumento";
	public static final String PARAM_SELECTOR_TIPO_DE_DOCUMENTO_DNI 	= "DNI";
	public static final String PARAM_SELECTOR_TIPO_DE_DOCUMENTO_LC 		= "LC";
	public static final String PARAM_SELECTOR_TIPO_DE_DOCUMENTO_LE 		= "LE";
	public static final String PARAM_SELECTOR_NUMERO_DE_DOCUMENTO 		= "selectorNumeroDocumento";
	public static final String PARAM_SELECTOR_DIAGNOSTICO				= "selectorDiagnostico";
	 
	public static final String PARAM_ELECCION_ELIMINAR_DIAGNOSTICO 	= "eleccionEliminarDiagnostico";
	public static final String PARAM_SI								= "SI";
	public static final String PARAM_NO								= "NO";
	
	
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public DiagnosticoServlet() 
	{
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	/**
	 * M�todo:	doPost
	 * 			Responsable de seleccionar en base a un par�metro obtenido 
	 * 			a partir de la url, cuando el servlet es invocado desde una
	 * 			p�gina "jsp", la acci�n y el m�todo interno del servlet a ejecutar.
	 * 
	 * @param	request
	 * @param	response
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// para la codificaci�n de caracteres
		request.setCharacterEncoding("UTF-8");
		
		String accion = request.getParameter( PacienteServlet.PARAM_ACCION );
		
		//validar que el usuario est� autenticado
		Usuario usuario = LoginServlet.getUsuarioEnSesion( request );
		if( !UsuarioServlet.ACCION_REGISTRAR.equals( accion ) && usuario == null )
		{
			UserNotification.addMessage(request, 
					"Est� intentando acceder a un recurso restringido para el cual necesita estar autenticado, " +
					"por favor reg�strese o acceda con su username y su password ..!",
					Level.ERROR);
			request.getRequestDispatcher("index.jsp").forward(request, response);
			return;
		}
		
		//el procesamiento se realiza seg�n el valor del par�metro "accion"
		if( ACCION_ACTUALIZAR.equals( accion ) )
		{
			doActualizar( request, response );
		}
		else if( ACCION_BORRAR.equals( accion ) )
		{
			doEliminar( request, response );
		}
		else if( ACCION_GUARDAR.equals( accion ) )
		{
			doGuardar( request, response );
		}
		else if( ACCION_SELECCIONAR_PACIENTE_PARA_CONSULTAR_DIAGNOSTICOS.equals( accion ) )
		{
			doSeleccionarPaciente(request, response, "do_consulta_diagnosticos.jsp");
		}
		else if( ACCION_SELECCIONAR_PACIENTE_PARA_ACTUALIZAR_DIAGNOSTICO.equals( accion ) )
		{
			doSeleccionarPaciente( request, response , "do_modifica_diagnostico.jsp" );
		}
		else if( ACCION_SELECCIONAR_PACIENTE_PARA_ELIMINAR_DIAGNOSTICO.equals( accion ) )
		{
			doSeleccionarPaciente( request, response , "do_elimina_diagnostico.jsp" );
		}
		else if( ACCION_SELECCIONAR_DIAGNOSTICO_PARA_ACTUALIZAR.equals( accion ) )
		{
			doSeleccionarDiagnostico( request, response, "do_modifica_diagnostico.jsp" );
		}
		else if( ACCION_SELECCIONAR_DIAGNOSTICO_PARA_ELIMINAR.equals( accion ) )
		{
			doSeleccionarDiagnostico( request, response, "do_elimina_diagnostico.jsp" );
		}
	}
	
	/**
	 * M�todo:	setCamposDeDiagnostico
	 * 			M�todo auxiliar para completar los campos del formulario
	 * 			de edici�n de los datos referidos a un Diagn�stico.
	 * 			Toma los datos del diagn�stico a partir de los argumentos propios del m�todo.
	 * 
	 * @param request
	 * @param tipoDeDocumento
	 * @param numeroDeDocumento
	 * @param anio
	 * @param mes
	 * @param dia
	 * @param descripcion
	 */
	private void setCamposDeDiagnostico( HttpServletRequest request, String tipoDeDocumento, String numeroDeDocumento,
			String anio, String mes, String dia, String descripcion )
	{
		FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_TIPO_DOCUMENTO, tipoDeDocumento, 	request );
		FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_NRO_DOCUMENTO, 	numeroDeDocumento, 	request );
		FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_ANIO, 			anio, 				request );
		FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_MES, 			mes, 				request );
		FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_DIA, 			dia, 				request );
		FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_DESCRIPCION, 	descripcion, 		request );
	}
	
	/**
	 * M�todo:	setCamposDelDiagnostico
	 * 			M�todo auxiliar para completar los campos del formulario
	 * 			de edici�n de los datos referidos a un Diagn�stico.
	 * 			Toma los datos del diagn�stico a partir del objeto diagnostico y 
	 * 			del objeto paciente que toma como argumentos.
	 * 
	 * @param request
	 * @param diagnostico
	 * @param paciente
	 */
	private void setCamposDeDiagnostico( HttpServletRequest request, Diagnostico diagnostico , Paciente paciente )
	{
		if( paciente != null && diagnostico != null )
		{
			FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_TIPO_DOCUMENTO, paciente.getTpoDoc(), 					request );
			FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_NRO_DOCUMENTO, 	String.valueOf( paciente.getNroDoc() ), request );
			
			Date fecha 	= diagnostico.getFecha();
			String anio = FechaUtil.getAnioFromDateToStr( 	fecha );
			String mes	= FechaUtil.getMesFromDateToStr( 	fecha );
			String dia 	= FechaUtil.getDiaFromDateToStr( 	fecha );
			
			FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_ANIO, 	anio,	request );
			FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_MES, 	mes, 	request );
			FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_DIA, 	dia, 	request );
			
			FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_DESCRIPCION, diagnostico.getDescripcion(), request );
		}
	}
	
	/**
	 * M�todo:	paramsValidos
	 * 			Responsable de validar los par�metros del formulario de edici�n de los datos referidos al Diagn�stico
	 * 			de un Paciente.
	 * 
	 * @param 	tipoDeDocumento
	 * @param 	numeroDeDocumento
	 * @param 	anio
	 * @param 	mes
	 * @param 	dia
	 * @param 	descripcion
	 * @param 	request
	 * @return	ok
	 */
	private boolean paramsValidos( String tipoDeDocumento, String numeroDeDocumento, String anio, String mes, String dia, String descripcion,
			HttpServletRequest request )
	{
		boolean ok = true;
		String mensaje = "Este campo no puede ser vac�o ..!";
		if( tipoDeDocumento == null || tipoDeDocumento.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( DiagnosticoServlet.PARAM_TIPO_DOCUMENTO, 
					"Debe seleccionar uno de los Tipos de Documentos: DNI o LC o LE ..!", request);
		}
		if( numeroDeDocumento == null || numeroDeDocumento.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( DiagnosticoServlet.PARAM_NRO_DOCUMENTO, mensaje, request);
		}
		if( anio == null || anio.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( DiagnosticoServlet.PARAM_ANIO, mensaje, request);
		}
		if( mes == null || mes.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( DiagnosticoServlet.PARAM_MES, mensaje, request);
		}
		if( dia == null || dia.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( DiagnosticoServlet.PARAM_DIA, mensaje, request);
		}
		if( descripcion == null || descripcion.trim().equals("") )
		{
			ok = false;
			FieldValueError.setFieldError( DiagnosticoServlet.PARAM_DESCRIPCION, mensaje, request);
		}
		
		return ok;
	}
	
	/**
	 * M�todo:	doGuardar
	 * 			Responsable de almacenar el registro de los datos del Diagn�stico de un Paciente
	 * 			en la Base de Datos: Clinica, Tabla: DIAGNOSTICOS.
	 * 			
	 * 			Toma del request los par�metros del formulario de edici�n de los datos del 
	 * 			Diagn�stico de un Paciente que est� en la p�gina: "do_alta_diagnostico.jsp".
	 * 			
	 * 			Verifica la validez de los par�metros.
	 * 
	 * 			Verifica que el campo N�mero de Documento no contenga puntos.
	 * 
	 * 			Verifica la validez de la fecha en que se realiza el diagn�stico. 
	 * 			En la p�gina: "do_alta_diagnostico.jsp" se sugiere la fecha actual como
	 * 			fecha del diagn�stico.
	 * 
	 * 			Verifica la validez del Tipo y N�mero de Documento ingresados por el usuario,
	 * 			es decir, si existe un registro en la Base de datos: Clinica, Tabla: PACIENTES
	 * 			que contenga ese Tipo y N�mero de Documento, mediante una consulta HQL. De la
	 * 			consulta HQL obtiene un objeto List<Paciente>, una lista de Pacientes que deber�a
	 * 			contener el Paciente con ese Tipo y N�mero de Documento.
	 * 			
	 * 			En el caso en que todos los par�metros son v�lidos:
	 * 			
	 * 			Verifica si la lista de Pacientes posee el Paciente, esta lista deber�a siempre contener
	 * 			un �nico objeto paciente:
	 *			
	 *				En el caso de que la lista posee un solo objeto paciente:
	 *			
	 *				Obtiene el Paciente a partir de la lista de Pacientes que arroj� 
	 *				la consulta HQL por Tipo y N�mero de Documento realizada con anterioridad.
	 *
	 *				Verifica si el paciente sigue con vida:
	 *
	 *					En el caso de que el paciente sigue con vida puede almacenar un Diagn�stico:
	 *					
	 *						Registra el diagn�stico mediante la invocaci�n al m�todo:
	 *
	 *						DiagnosticoHome.modificaDiagnostico( diagnostico )
	 *
	 *						Notifica al usuario la registraci�n satisfactoria del Diagn�stico en
	 *						la Base de Datos
	 *
	 *						Redirige hacia: "gestor_pacientes_diagnosticos.jsp"
	 *
	 *						Retorna con "return"
	 * 
	 * 					En el caso de que el Paciente ha fallecido no puede almacenar el Diagn�stico:
	 * 					
	 * 						Notifica al usuario con un mensaje que le indica que no puede registrar el 
	 * 						diagn�stico porque el Paciente ha fallecido.
	 * 			
	 * 				En el caso de que ocurre una HibernateException:
	 * 			
	 * 					Notifica al usuario con un mensaje de error
	 * 			
	 *  		En el caso de que los par�metros son inv�lidos:
	 *  		
	 *  			Notifica al usuario con un mensaje de error
	 * 			
	 * 			Finalmente:
	 * 
	 * 			Completa los campos del formulario de edici�n de los datos referidos a un
	 * 			diagn�stico que est� en la p�gina: "do_alta_diagnostico.jsp" mediante la
	 * 			invocaci�n al m�todo: 
	 * 
	 * 			setCamposDeDiagnostico( request, tipoDeDocumento, numeroDeDocumento, anio, mes, dia, descripcion )
	 * 
	 * 			Redirige hacia: "do_alta_diagnostico.jsp"
	 * 
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	private void doGuardar( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException
	{
		//Toma los par�metros del request del formulario de alta de Diagn�stico de un Paciente
		String tipoDeDocumento		= request.getParameter( DiagnosticoServlet.PARAM_TIPO_DOCUMENTO );
		String numeroDeDocumento	= request.getParameter( DiagnosticoServlet.PARAM_NRO_DOCUMENTO );
		String anio					= request.getParameter( DiagnosticoServlet.PARAM_ANIO );
		String mes					= request.getParameter( DiagnosticoServlet.PARAM_MES );
		String dia					= request.getParameter( DiagnosticoServlet.PARAM_DIA );
		String descripcion			= request.getParameter( DiagnosticoServlet.PARAM_DESCRIPCION );
		
		// Para averiguar el Paciente toma Tipo y N�mero de Documento => obtiene el Paciente mediante una Consulta HQL
		// Para la consulta HQL por Tipo y N�mero de Documento. Debe chequear si Paciente est� registrado o n�. Obtiene el Paciente.
		String consultaHQL = "";
		List<Paciente> listaDePacientes = null;
		Paciente paciente;
		
		/* Como registra por primera vez, puede usar new para instanciar un objeto Diagnostico 
		 * ya que proporciona un idDiagnostico incremental diferente  */
		
		Diagnostico diagnostico = new Diagnostico( null, null, null );
		
		boolean validos = paramsValidos( tipoDeDocumento, numeroDeDocumento, anio, mes, dia, descripcion, request );
		
		if( numeroDeDocumento.contains(".") )
		{
			validos = false;
			UserNotification.addMessage(request, "El N�mero de Documento debe introducirlo <b>SIN LOS PUNTOS</b> ..!", UserNotification.Level.ERROR);
		}
		
		// verifica que la fecha del Diagnóstico sea una fecha correcta
		String fechaStr = anio + "-" + mes + "-" + dia;
		Date fecha = FechaUtil.validaFecha( request, fechaStr );
		if( fecha == null )
		{
			validos = false;
			FieldValueError.setFieldError( DiagnosticoServlet.PARAM_DIA, "Debe seleccionar una Fecha que sea v�lida ..!", request);
		}
		
		// verifica que haya un Paciente registrado con ese tipo y N�mero de documento
		if( tipoDeDocumento != null && !tipoDeDocumento.trim().equals("") && numeroDeDocumento != null && !numeroDeDocumento.trim().equals("") )
		{
			try
			{
				consultaHQL = "select p from Paciente as p where p.tpoDoc = '" + tipoDeDocumento + "' and p.nroDoc = '" + numeroDeDocumento + "'";
			
				listaDePacientes = PacienteHome.consultaPacientes( consultaHQL );
			
				if( listaDePacientes == null || listaDePacientes.isEmpty() || listaDePacientes.size() > 1 )
				{
					validos = false;
					FieldValueError.setFieldError( DiagnosticoServlet.PARAM_NRO_DOCUMENTO ,
							"El Tipo y N�mero de Documento que ha ingresado NO CORRESPONDEN con ninguno de los Pacientes registrados en la base de datos.",
							request );
				}
			}
			catch( HibernateException hex )
			{
				UserNotification.addMessage( request, 
						"Ha ocurrido un error al acceder a la base de datos. Por favor comun�quelo al administrador del Sitio.", 
						UserNotification.Level.ERROR );
			}
		}
		
		if( validos )
		{
			try
			{
				if( listaDePacientes != null && listaDePacientes.size() == 1 )
				{
					paciente = listaDePacientes.get(0);
					
					if( paciente.isEstaVivo() == true )
					{
						diagnostico.setPaciente( paciente );
						diagnostico.setFecha( fecha );
						diagnostico.setDescripcion( descripcion );
					
						DiagnosticoHome.modificaDiagnostico( diagnostico );
					
						UserNotification.addMessage( request, "El Diagn�stico ha sido almacenado satisfactoriamente en la Base de Datos.", 
							UserNotification.Level.INFO );
					
						request.getRequestDispatcher( "gestor_pacientes_diagnosticos.jsp" ).forward(request, response);
						
						return;
					}
					else
					{
						UserNotification.addMessage( request, 
								"Error: No puede registrar el Diagn�stico a un Paciente que ha fallecido ..!", 
								UserNotification.Level.ERROR);
					}
				}
			}
			catch( HibernateException hex )
			{
				UserNotification.addMessage( request, 
						"Ha ocurrido un error al acceder a la base de datos. Por favor comun�quelo al administrador del Sitio.", 
						UserNotification.Level.ERROR );
			}
		}
		else
		{
			UserNotification.addMessage( request, "Ha ocurrido un error, por favor verifique los datos ingresados.", UserNotification.Level.ERROR );
		}
		setCamposDeDiagnostico( request, tipoDeDocumento, numeroDeDocumento, anio, mes, dia, descripcion );
		request.getRequestDispatcher( "do_alta_diagnostico.jsp" ).forward( request, response );
	}
	
	/**
	 * M�todo:	doSeleccionarPaciente
	 * 			Responsable de seleccionar el registro de los datos de un Paciente 
	 * 			a partir de una consulta HQL por Tipo y N�mero de Documento
	 * 			en la Base de datos: Clinica, Tabla: PACIENTES.
	 * 
	 * 			Toma del request los par�metros del formulario de selecci�n de un paciente
	 * 			por Tipo y N�mero de Documento que est� en la p�gina: "do_modifica_paciente.jsp"
	 * 			o bi�n en la p�gina: "do_elimina_paciente.jsp", o bi�n en la p�gina: "do_consulta_diagnosticos.jsp".
	 * 
	 * 			Asigna los campos Tipo y N�mero de Documento para el formulario selector de Pacientes
	 * 			mediante la invocaci�n a los m�todos:
	 * 
	 * 				FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO, tipoDeDocumento, request)
	 * 
	 * 				FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_SELECTOR_NUMERO_DE_DOCUMENTO, numeroDeDocumento, request)
	 * 
	 * 			Verifica la validez de los par�metros.
	 * 
	 * 			En el caso de que los par�metros son v�lidos:
	 * 	
	 * 				Realiza una consulta HQL a la Base de datos: Clinica, Tabla: PACIENTES mediante
	 * 				la invocaci�n al m�todo: 
	 * 
	 * 				PacienteHome.consultaPacientes( consultaHQL )
	 * 
	 * 				y obtiene un objeto List<Paciente> que posee la lista de pacientes. Esta lista, siempre 
	 * 				deber� contener un solo paciente.
	 * 		
	 * 				En el caso de que la lista de pacientes contiene un solo paciente:
	 * 
	 * 					Obtiene el paciente de la lista de pacientes
	 * 
	 *  				Realiza otra consulta HQL por "id de Paciente", esta vez a la Base de datos: Clinica,
	 *  				Tabla: DIAGNOSTICOS para obtener un objeto List<Diagnostico> que posee los 
	 *  				diagn�sticos del paciente, mediante la invocaci�n al m�todo:
	 *   
	 *  				DiagnosticoHome.consultaDiagnosticos( consultaHQLDiag )
	 *  
	 *  				Pone en el request al atributo nombrado: DiagnosticoServlet.PACIENTE 
	 *  				con el valor: paciente
	 *  
	 *  				Pone en el request al atributo nombrado: DiagnosticoServlet.LISTA_DE_DIAGNOSTICOS
	 *  				con el valor: listaDeDiagnosticos
	 *  
	 *  			En el caso de que la lista de pacientes no tenga tama�o uno:
	 *  
	 *  				Notifica al usuario con un mensaje de error
	 *  
	 *  			En el caso de que ocurre una HibernateException:
	 *  
	 *  				Notifica al usuario con un mensaje de error
	 *  
	 *  		En el caso de que los par�metros son inv�lidos:
	 *  
	 *  			Notifica al usuario con un mensaje que le indica que debe seleccionar un Tipo de Documento
	 *  			e introducir un N�mero de Documento.
	 *  		
	 *  		Finalmente redirige hacia: "urlDestino"
	 * 
	 * @param request
	 * @param response
	 * @param urlDestino
	 * @throws ServletException
	 * @throws IOException
	 */
	private void doSeleccionarPaciente( HttpServletRequest request, HttpServletResponse response , String urlDestino ) throws ServletException, IOException
	{
		// Toma del request los par�metros del formulario de selecci�n de un paciente por Tipo y N�mero de Documento
		// que est� en la p�gina: "do_modifica_diagnostico.jsp", o bi�n en la p�gina: "do_elimina_diagnostico.jsp"
		String tipoDeDocumento 		= request.getParameter( DiagnosticoServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO );
		String numeroDeDocumento	= request.getParameter(DiagnosticoServlet.PARAM_SELECTOR_NUMERO_DE_DOCUMENTO );
		
		//asigna los campos Tipo y N�mero de Documento para el formulario selector de Pacientes 
		FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO, 	tipoDeDocumento, 	request);
		FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_SELECTOR_NUMERO_DE_DOCUMENTO, 	numeroDeDocumento, 	request);
		
		String consultaHQL = "";
		String consultaHQLDiag = "";
		List<Paciente> listaDePacientes = null;
		List<Diagnostico> listaDeDiagnosticos = null;
		Paciente paciente = null;
		
		boolean validos = true;
		// verifica el Tipo de Documento
		if( tipoDeDocumento == null || tipoDeDocumento.trim().equals("") )
		{
			validos = false;
			FieldValueError.setFieldError( DiagnosticoServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO, 
				"Debe seleccionar un Tipo de Documento: DNI o LC o LE ..!", request);
		}
		//verifica el N�mero de Documento
		if( numeroDeDocumento == null || numeroDeDocumento.trim().equals("") )
		{
			validos = false;
			FieldValueError.setFieldError( DiagnosticoServlet.PARAM_SELECTOR_NUMERO_DE_DOCUMENTO, 
				"Debe ingresar un N�mero de Documento ..!", request);
		}
		if( numeroDeDocumento.contains(".") )
		{
			validos = false;
			FieldValueError.setFieldError(DiagnosticoServlet.PARAM_SELECTOR_NUMERO_DE_DOCUMENTO,
					"El N�mero de Documento debe introducirlo <b>SIN LOS PUNTOS</b> ..!",
					request);
		}
		
		if( validos )
		{
			consultaHQL = "select p from Paciente as p where p.tpoDoc = '" + tipoDeDocumento + "' and p.nroDoc = '" + numeroDeDocumento + "'";
			try
			{
				listaDePacientes = PacienteHome.consultaPacientes( consultaHQL );
				
				if( listaDePacientes != null &&  listaDePacientes.size() == 1 )
				{
					paciente = listaDePacientes.get(0);
					/* Si trato de obtener el set de Diagn�sticos mediante:
					 * 
					 * 	setDeDiagnosticos = paciente.getDiagnosticos();
					 * 
					 *  Obtengo la siguiente Excepci�n:
					 *  
					 *  	org.hibernate.LazyInitializationException: failed to lazily initialize a collection of role: 
					 *  	clinica.Paciente.diagnosticos, no session or session was closed
					 */
					/*
					 * Si trato de obtener el set de Diagn�sticos mediante un m�todo donde previamente abro una sesion de HibernateSession 
					 * tambi�n obtengo la misma excepci�n: 
					 * 
					 * setDeDiagnosticos = PacienteHome.obtenerSetDeDiagnosticos( paciente );
					 * 
					 * Por este motivo ese m�todo, de la clase PacienteHome: "obtenerSetDeDiagnosticos" ha sido comentado
					 */
					
					/* obtiene el set De Diagnosticos del Paciente mediante otra consulta HQL 
					 * porque al usar el m�todo getDiagnosticos() ocurre una excepci�n	*/
					consultaHQLDiag = "select d from Diagnostico as d where d.paciente.idPaciente ='" + 
						String.valueOf( paciente.getIdPaciente() ) + "'";
					listaDeDiagnosticos = DiagnosticoHome.consultaDiagnosticos( consultaHQLDiag );
					
					request.setAttribute( DiagnosticoServlet.PACIENTE, 				paciente );
					request.setAttribute( DiagnosticoServlet.LISTA_DE_DIAGNOSTICOS, listaDeDiagnosticos );
				}
				else
				{
					UserNotification.addMessage( request, 
							"El Tipo y N�mero de Documento que ha introducido no corresponde a un Paciente registrado en la Base de Datos. <BR />" +
							"Por favor verifique los datos ingresados e intente nuevamente. <BR />",
							Level.ERROR);
				}
			}
			catch( HibernateException hex)
			{
				UserNotification.addMessage( request, 
						"Ha ocurrido un error al acceder a la base de datos. Por favor comun�quelo al administrador del Sitio.",
						Level.ERROR);
			}
		}
		else
		{
			UserNotification.addMessage( request, 
					"Debe ingresar un Tipo y N�mero de Documento en el selector de Pacientes ..!",
					Level.ERROR);
		}
		request.getRequestDispatcher( urlDestino ).forward( request, response );
	}
	
	/**
	 * M�todo:	doSeleccionarDiagnostico
	 * 			Responsable de Seleccionar un Diagn�stico a partir de un Id de Diagn�stico, 
	 * 			que obtiene como par�metros del request, y una lista de Diagn�sticos, 
	 * 			que obtiene mediante: DiagnosticoServlet.getListaDeDiagnosticos().
	 * 
	 * 			Toma del request el par�metro del formulario de Selecci�n de un Diagn�stico,
	 * 			el "Id de Diagns�stico", y asigna ese mismo campo mediante la invocaci�n al m�todo:
	 * 			
	 * 			FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_SELECTOR_DIAGNOSTICO, idDiagnostico, request)
	 * 
	 * 			Obtiene la lista de diagn�sticos desde el HttpSession mediante la invocaci�n al m�todo:
	 * 
	 * 			List<Diagnostico> listaDeDiagnosticos = (List<Diagnostico>)request.getSession().getAttribute( DiagnosticoServlet.LISTA_DE_DIAGNOSTICOS );
	 * 
	 * 			que previamente fue seteada en la p�gina: "do_modifica_diagnostico.jsp", o bi�n, "do_elimina_diagnostico.jsp".
	 * 			Ese mismo objeto List<Diagnostico> lo pone en el request como atributo nombrado: 
	 * 			DiagnosticoServlet.LISTA_DE_DIAGNOSTICOS
	 * 			
	 * 			Obtiene el paciente desde el HttpSession mediante la invocaci�n al m�todo:
	 * 
	 * 			Paciente paciente = (Paciente)request.getSession().getAttribute( DiagnosticoServlet.PACIENTE );
	 *  		
	 *  		que previamente fue seteado en la p�gina: "do_modifica_diagnostico.jsp", o bi�n, "do_elimina_diagnostico.jsp".
	 * 			Ese mismo objeto paciente lo pone en el request como atributo nombrado: 
	 * 			DiagnosticoServlet.PACIENTE
	 * 			
	 * 			A partir del paciente obtiene el Tipo y N�mero de documento, necesarios para asignar los
	 * 			campos del formulario de selecci�n de un paciente en las p�ginas: 
	 * 			"do_modifica_diagnostico.jsp", o bi�n, "do_elimina_diagnostico.jsp", o bi�n, "do_consulta_diagnosticos.jsp". 
	 * 			Asigna estos campos mediante la invocaci�n a los m�todos:
	 * 			
	 * 			FieldValueError.setFieldValue(DiagnosticoServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO, tipoDeDocumento, request)
	 * 			
	 * 			FieldValueError.setFieldValue(DiagnosticoServlet.PARAM_SELECTOR_NUMERO_DE_DOCUMENTO, numeroDeDocumento, request)
	 * 
	 * 			Verifica la validez de los par�metros:
	 * 
	 * 			En el caso de que los par�metros son v�lidos:
	 * 			
	 * 				Realiza una b�squeda secuencial del Diagn�stico en la lista de diagn�sticos
	 * 				buscando por "Id de Diagn�stico"
	 * 
	 * 				Pone en el request al atributo nombrado: DiagnosticoServlet.DIAGNOSTICO
	 * 			 	con el valor que arroja la b�squeda: diagnostico
	 * 
	 * 				En el caso de que la cadena String "urlDestino" es "do_modifica_diagnostico.jsp":
	 * 
	 * 					Completa los campos del formulario de edici�n de los datos del Diagn�stico del 
	 * 					Paciente que est� en la p�gina "do_modifica_diagnostico.jsp" mediante la invocaci�n al m�todo:
	 * 
	 * 					setCamposDeDiagnostico(request, diagnostico, paciente)
	 * 		
	 * 			En el caso de que los par�metros son inv�lidos:
	 * 
	 * 				Notifica al usuario con un mensaje de error
	 * 
	 * 			Finalmente redirige hacia: "urlDestino"
	 * 
	 * @param request
	 * @param response
	 * @param urlDestino
	 * @throws ServletException
	 * @throws IOException
	 */
	private void doSeleccionarDiagnostico( HttpServletRequest request, HttpServletResponse response , String urlDestino ) throws ServletException, IOException
	{
		// Toma del request el par�metro del formulario de selecci�n de Diagn�sticos: el id de Diagn�stico
		// que est� en la p�gina: "do_modifica_diagnostico.jsp", o bi�n en la p�gina: "do_elimina_diagnostico.jsp" 
		String idDiagnostico = request.getParameter( DiagnosticoServlet.PARAM_SELECTOR_DIAGNOSTICO );
		
		//asigna el campo para el formulario de selecci�n de Diagn�sticos de un Paciente
		FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_SELECTOR_DIAGNOSTICO, idDiagnostico, request);
		
		//obtiene la lista de Diagn�sticos desde el HttpSession mediante la invocaci�n al m�todo:
		List<Diagnostico> listaDeDiagnosticos = (List<Diagnostico>)request.getSession().getAttribute( DiagnosticoServlet.LISTA_DE_DIAGNOSTICOS ); 
			
		// pasa la lista de Diagn�sticos como atributo del request
		request.setAttribute( DiagnosticoServlet.LISTA_DE_DIAGNOSTICOS, listaDeDiagnosticos );
		
		// obtiene el Paciente desde el HttpSession mediante la invocaci�n al m�todo:
		Paciente paciente = (Paciente)request.getSession().getAttribute( DiagnosticoServlet.PACIENTE ); 
			
		//pasa el paciente como atributo del request 
		request.setAttribute( DiagnosticoServlet.PACIENTE, paciente );
		
		String tipoDeDocumento = paciente.getTpoDoc();
		//asigna el campo tipo de documento para el formulario selector de Paciente
		FieldValueError.setFieldValue(DiagnosticoServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO, tipoDeDocumento, request);
		
		int numeroDeDocumentoNro	= paciente.getNroDoc();
		String numeroDeDocumento	= String.valueOf( numeroDeDocumentoNro );
		// asigna el campo n�mero de documento para el formulario selector de Paciente
		FieldValueError.setFieldValue(DiagnosticoServlet.PARAM_SELECTOR_NUMERO_DE_DOCUMENTO, numeroDeDocumento, request);
		
		if( idDiagnostico != null && !idDiagnostico.trim().equals("") && listaDeDiagnosticos != null )
		{
			//asigna el campo oculto en el formulario de edici�n de los datos del Diagn�stico
			FieldValueError.setFieldValue(DiagnosticoServlet.PARAM_ID_DIAGNOSTICO, idDiagnostico, request);
			
			//Busca en la lista de Diagn�sticos, el Diagn�stico con ese idDiagnostico
			int idDiagnosticoNro = Integer.parseInt( idDiagnostico );
			Iterator<Diagnostico> iteradorDeDiagnosticos = listaDeDiagnosticos.iterator();
			Diagnostico diagnostico = null;
			Diagnostico temp = null;
			while( iteradorDeDiagnosticos.hasNext() )
			{
				temp = iteradorDeDiagnosticos.next();
				if( temp.getIdDiagnostico() == idDiagnosticoNro )
				{
					diagnostico = temp;
				}
			}
			
			// pasa el diagnostico a urlDestino como atributo del request  
			request.setAttribute( DiagnosticoServlet.DIAGNOSTICO , diagnostico );
			
			// asigna los campos del formulario de edici�n de los datos del Diagn�stico de un Paciente
			// necesarios para la p�gina: "do_modifica_diagnostico.jsp"
			if( urlDestino != null && urlDestino.trim().equals( "do_modifica_diagnostico.jsp" ))
			{
				setCamposDeDiagnostico(request, diagnostico, paciente);
			}
		}
		else
		{
			UserNotification.addMessage(request, "Debe seleccionar uno de los Diagn�sticos del Paciente ..!", UserNotification.Level.ERROR );
		}
		request.getRequestDispatcher( urlDestino ).forward(request, response);
	}
	
	/**
	 * M�todo:	doActualizar
	 * 			Responsable de realizar la actualizaci�n del registro de los datos del diagn�stico de un paciente 
	 * 			en la Base de datos: Clinica, Tabla: DIAGNOSTICOS.
	 * 
	 * 			Toma del request los par�metros, incluso el oculto, del formulario de edici�n de los datos del 
	 * 			Diagn�stico de un Paciente que est� en la p�gina: "do_modifica_diagnostico.jsp".
	 * 			
	 * 			Obtiene el diagn�stico desde el HttpSession mediante la invocaci�n al m�todo:
	 * 
	 * 			Diagnostico diagnostico = (Diagnostico)request.getSession().getAttribute( DiagnosticoServlet.DIAGNOSTICO );
	 * 
	 * 			que previamente fue seteado en la p�gina "do_modifica_diagnostico.jsp".
	 * 
	 * 			Obtiene el Paciente desde el HttpSession mediante la invocaci�n al m�todo:
	 * 
	 * 			Paciente paciente = (Paciente) request.getSession().getAttribute( DiagnosticoServlet.PACIENTE );
	 * 
	 * 			que previamente fue seteado en la p�gina "do_modifica_diagnostico.jsp".
	 * 
	 * 			Obtiene la lista de Diagn�sticos desde el HttpSession mediante la invocaci�n al m�todo:
	 * 
	 *  		List<Diagnostico> listaDeDiagnosticos = (List<Diagnostico>)request.getSession().getAttribute( DiagnosticoServlet.LISTA_DE_DIAGNOSTICOS );
	 *  
	 *  		que previamente fue seteado en la p�gina "do_modifica_diagnostico.jsp".
	 * 
	 * 			Verifica la validez de los par�metros.
	 * 			
	 * 			Verifica la validez de la fecha del Diagn�stico.
	 * 
	 * 			Verifica que el campo N�mero de Documento no contenga puntos.
	 * 
	 * 			En el caso de que los par�metros son v�lidos:
	 * 
	 * 				Verifica si el paciente ha fallecido:
	 * 
	 * 				En el caso de que el paciente sigue con vida:
	 * 
	 * 					Actualiza el registro del Diagn�stico en la Base de datos mediante la invocaci�n
	 * 					al m�todo: 
	 * 
	 * 					DiagnosticoHome.modificaDiagnostico( diagnostico )
	 * 
	 * 					Notifica al usuario con un mensaje que le indica la actualizaci�n satisfactoria del
	 * 					registro del Diagn�stico en la Base de datos
	 * 
	 * 					Redirige hacia: "gestor_pacientes_diagnosticos.jsp"
	 * 
	 * 					Retorna con "return"
	 * 			
	 * 				En el caso de que el paciente ha fallecido:
	 * 
	 * 					Notifica al usuario con un mensaje que le indica que no puede actualizar el
	 * 					diagn�stico de un paciente que ha fallecido
	 * 
	 * 				En el caso de que ocurre una HibernateException:
	 * 		
	 * 					Notifica al usuario con un mensaje de error
	 * 
	 * 			En el caso de que los par�metros son inv�lidos:
	 * 
	 * 				Notifica al usuario con un mensaje de error
	 * 
	 * 			Finalmente:
	 * 		
	 * 				Asigna los campos del formulario de edici�n de los datos del Diagn�stico de un paciente
	 * 				mediante la invocaci�n al m�todo:
	 * 
	 * 				setCamposDeDiagnostico( request, tipoDeDocumento, numeroDeDocumento, anio, mes, dia, descripcion )
	 * 
	 * 				Asigna el campo oculto (hidden) del formulario de edici�n de los datos del Diagn�stico de un paciente
	 * 				mediante la invocaci�n al m�todo:
	 * 				
	 * 				FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_ID_DIAGNOSTICO, idDiagnostico, request )
	 * 
	 * 				Pasa como atributo del request al diagn�stico
	 * 			
	 * 			 	Asigna el campo para el formulario de selecci�n de Diagn�sticos de un Paciente
	 * 				mediante la invocaci�n al m�todo:
	 * 				
	 * 				FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_SELECTOR_DIAGNOSTICO, idDiagnostico, request)
	 * 
	 * 				Pasa la lista de Diagn�sticos como atributo del request
	 * 
	 * 				Pasa el paciente como atributo del request
	 * 
	 * 				Asigna el campo tipo de documento para el formulario selector de Paciente
	 * 				mediante la invocaci�n al m�todo:
	 * 				
	 * 				FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO, tipoDeDocumento, request )
	 * 
	 * 				Asigna el campo N�mero de documento para el formulario selector de Paciente
	 * 				mediante la invocaci�n al m�todo:
	 * 				
	 * 				FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_SELECTOR_NUMERO_DE_DOCUMENTO, numeroDeDocumento, request )
	 * 
	 * 				Redirige la respuesta hacia: do_modifica_diagnostico.jsp
	 * 			
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	private void doActualizar( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException
	{	
		//Toma los par�metros del formulario de edici�n de los datos del Diagn�stico
		String tipoDeDocumento 		= request.getParameter( DiagnosticoServlet.PARAM_TIPO_DOCUMENTO );
		String numeroDeDocumento	= request.getParameter( DiagnosticoServlet.PARAM_NRO_DOCUMENTO );
		String anio 				= request.getParameter( DiagnosticoServlet.PARAM_ANIO );
		String mes 					= request.getParameter( DiagnosticoServlet.PARAM_MES );
		String dia 					= request.getParameter( DiagnosticoServlet.PARAM_DIA );
		String descripcion 			= request.getParameter( DiagnosticoServlet.PARAM_DESCRIPCION );
		// toma del request el par�metro oculto del formulario de edici�n de los datos del Diagn�stico
		String idDiagnostico 		= request.getParameter( DiagnosticoServlet.PARAM_ID_DIAGNOSTICO );
		
		// obtiene el diagn�stico desde el HttpSession mediante la invocaci�n al m�todo
		Diagnostico diagnostico = (Diagnostico)request.getSession().getAttribute( DiagnosticoServlet.DIAGNOSTICO );
		
		// obtiene el Paciente desde el HttpSession mediante la invocaci�n al m�todo
		Paciente paciente = (Paciente) request.getSession().getAttribute( DiagnosticoServlet.PACIENTE );

		// obtiene la lista de Diagn�sticos desde el HttpSession mediante la invocaci�n al m�todo
		List<Diagnostico> listaDeDiagnosticos = (List<Diagnostico>)request.getSession().getAttribute( DiagnosticoServlet.LISTA_DE_DIAGNOSTICOS ); 
			
		boolean validos = paramsValidos( tipoDeDocumento, numeroDeDocumento, anio, mes, dia, descripcion, request );
		
		// verifica el campo oculto idDiagnostico
		if( idDiagnostico == null || idDiagnostico.trim().equals("") )
		{
			validos = false;
		}
		//verifica la fecha
		String fechaStr = anio + "-" + mes + "-" + dia;
		Date fecha = FechaUtil.validaFecha( request, fechaStr );
		if( fecha == null )
		{
			validos = false;
			FieldValueError.setFieldError(DiagnosticoServlet.PARAM_DIA, "Debe seleccionar una fecha que sea v�lida ..!", request);
		}
		// verifica que el campo N�mero de Documento no contenga puntos
		if( numeroDeDocumento.contains(".") )
		{
			validos = false;
			FieldValueError.setFieldError(DiagnosticoServlet.PARAM_NRO_DOCUMENTO,
					"El N�mero de Documento debe introducirlo <b>SIN LOS PUNTOS</b> ..!",
					request);
		}
		
		if( validos )
		{
			//actualiza el Diagn�stico si el Paciente sigue vivo
			if( diagnostico != null )
			{
				if( paciente.isEstaVivo() == true )
				{
					try
					{
						diagnostico.setIdDiagnostico( Integer.parseInt( idDiagnostico ) );
						diagnostico.setFecha( fecha );
						diagnostico.setDescripcion( descripcion );
						diagnostico.setPaciente( paciente );
						
						DiagnosticoHome.modificaDiagnostico( diagnostico );
						
						UserNotification.addMessage(request, 
								"El diagn�stico ha sido modificado satisfactoriamente en la base de datos.", UserNotification.Level.INFO );
						
						//redirige la respuesta hacia gestor_pacientes_diagnosticos.jsp
						request.getRequestDispatcher( "gestor_pacientes_diagnosticos.jsp" ).forward(request, response );
						
						return;
					}
					catch( HibernateException hex )
					{
						UserNotification.addMessage( request, 
								"Ha ocurrido un error al acceder a la base de datos.<BR /> Por favor comun�quelo al administrador del sitio.<BR />", 
								UserNotification.Level.ERROR );
					}
				}
				if( paciente.isEstaVivo() == false )
				{
					UserNotification.addMessage( request, 
							"Error: No puede actualizar el Diagn�stico de un Paciente que ha fallecido ..!", 
							UserNotification.Level.ERROR );
				}
			}
		}
		else
		{
			UserNotification.addMessage(request, "Ha ocurrido un error, por favor verifique los datos ingresados ..!", UserNotification.Level.ERROR );
		}
		// asigna los campos del formulario de edici�n de los datos del Diagn�stico de un paciente
		setCamposDeDiagnostico( request, tipoDeDocumento, numeroDeDocumento, anio, mes, dia, descripcion );
		
		// asigna el campo oculto (hidden) del formulario de edici�n de los datos del Diagn�stico de un paciente
		FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_ID_DIAGNOSTICO, idDiagnostico, request );
		
		// pasa como atributo del request a diagnostico
		request.setAttribute( DiagnosticoServlet.DIAGNOSTICO, diagnostico );
		
		// asigna el campo para el formulario de selecci�n de Diagn�sticos de un Paciente
		FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_SELECTOR_DIAGNOSTICO, idDiagnostico, request);
		
		// pasa la lista de Diagn�sticos como atributo del request
		request.setAttribute( DiagnosticoServlet.LISTA_DE_DIAGNOSTICOS, listaDeDiagnosticos );
		
		// pasa el paciente como atributo del request 
		request.setAttribute( DiagnosticoServlet.PACIENTE, paciente );
		
		// asigna el campo tipo de documento para el formulario selector de Paciente
		FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO, tipoDeDocumento, request );
		
		// asigna el campo N�mero de documento para el formulario selector de Paciente
		FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_SELECTOR_NUMERO_DE_DOCUMENTO, numeroDeDocumento, request );
		
		// redirige la respuesta hacia do_modifica_diagnostico.jsp
		request.getRequestDispatcher( "do_modifica_diagnostico.jsp" ).forward(request, response);
	}
	
	/**
	 * M�todo:	doEliminar
	 * 			Responsable de borrar el registro del Diagn�stico de un Paciente en la Base de datos: Clinica, Tabla: DIAGNOSTICOS.
	 * 
	 * 			Toma del request el par�metro del formulario de confirmaci�n de eliminaci�n del Diagn�stico de un Paciente
	 * 			que est� en la p�gina: "do_elimina_diagnostico.jsp".
	 * 
	 * 			Asigna el campo del formulario de confirmaci�n de eliminaci�n del Diagn�stico de un Paciente mediante la invocaci�n
	 *	 		al m�todo:
	 *			
	 *			FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_ELECCION_ELIMINAR_DIAGNOSTICO, eleccionEliminarDiagnostico, request)
	 *
	 *			Obtiene el diagn�stico desde el HttpSession mediante la invocaci�n al m�todo: 
	 *
	 *			Diagnostico diagnostico = (Diagnostico)request.getSession().getAttribute( DiagnosticoServlet.DIAGNOSTICO );
	 *  
	 *			que previamente fue seteado en la p�gina "do_elimina_diagnostico.jsp".
	 *
	 *			Obtiene el paciente desde el HttpSession mediante la invocaci�n al m�todo:
	 *
	 *			Paciente paciente = (Paciente)request.getSession().getAttribute( DiagnosticoServlet.PACIENTE );
	 *
	 *			que previamente fue seteado en la p�gina "do_elimina_diagnostico.jsp".
	 *	
	 *			Obtiene la lista de diagn�sticos desde el HttpSession mediante la invocaci�n al m�todo:
	 *
	 * 			List<Diagnostico> listaDeDiagnosticos = (List<Diagnostico>)request.getSession().getAttribute( DiagnosticoServlet.LISTA_DE_DIAGNOSTICOS );
	 * 
	 *			que previamente fue seteado en la p�gina "do_elimina_diagnostico.jsp".
	 *	
	 *			Verifica la validez del par�metro del formulario de confirmaci�n de eliminaci�n del Diagn�stico del Paciente.
	 *
	 *			En el caso de que el par�metro es v�lido:
	 *
	 *				Elimina el registro del Diagn�stico del Paciente de la Base de Datos: Clinica, Tabla: DIAGNOSTICOS.
	 *				mediante la invocaci�n al m�todo:
	 *				
	 *				DiagnosticoHome.eliminaDiagnostico( diagnostico )
	 *
	 *				Notifica al usuario con un mensaje que le indica la eliminaci�n satisfactoria 
	 *				del registro del diagn�stico del Paciente en la Base de Datos.
	 *				
	 *				Redirige hacia: "gestor_pacientes_diagnosticos.jsp"
	 *					
	 *				Retorna con "return"
	 *
	 *				En el caso de que ocurre una HibernateException:
	 *
	 *					Notifica al usuario con un mensaje de error
	 *
	 *			En el caso de que los par�metros son inv�lidos:
	 *
	 *				Notifica al usuario con un mensaje de error
	 *
	 * 			Finalmente:
	 * 
	 * 				Pasa como atributo del request al diagn�stico
	 * 			
	 * 			 	Asigna el campo para el formulario de selecci�n de Diagn�sticos de un Paciente
	 * 				mediante la invocaci�n al m�todo:
	 * 				
	 * 				FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_SELECTOR_DIAGNOSTICO, idDiagnostico, request)
	 * 
	 * 				Pasa la lista de Diagn�sticos como atributo del request
	 * 
	 * 				Pasa el paciente como atributo del request
	 * 
	 * 				Asigna el campo tipo de documento para el formulario selector de Paciente
	 * 				mediante la invocaci�n al m�todo:
	 * 				
	 *				FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO, tipoDeDocumento, request )
	 * 
	 * 				Asigna el campo N�mero de documento para el formulario selector de Paciente
	 * 				mediante la invocaci�n al m�todo:
	 * 				
	 * 				FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_SELECTOR_NUMERO_DE_DOCUMENTO, numeroDeDocumento, request )
	 * 
	 * 				Redirige la respuesta hacia: do_elimina_diagnostico.jsp
	 * 		
	 * @param 	request
	 * @param 	response
	 * @throws 	ServletException
	 * @throws 	IOException
	 */
	private void doEliminar(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// Toma del request el par�metro del formulario de confirmaci�n de eliminaci�n del Diagn�stico de un Paciente
		// que est� en la p�gina: "do_elimina_diagnostico.jsp"
		String eleccionEliminarDiagnostico = request.getParameter( DiagnosticoServlet.PARAM_ELECCION_ELIMINAR_DIAGNOSTICO );
		
		//asigna el campo del formulario de confirmaci�n de eliminaci�n del Diagnsotico de un Paciente mediante la invocaci�n al m�todo:
		FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_ELECCION_ELIMINAR_DIAGNOSTICO, eleccionEliminarDiagnostico, request);
		
		// obtiene el diagn�stico desde el HttpSession mediante la invocaci�n al m�todo
		Diagnostico diagnostico = (Diagnostico)request.getSession().getAttribute( DiagnosticoServlet.DIAGNOSTICO );
			
		// obtiene el Paciente desde el HttpSession mediante la invocaci�n al m�todo
		Paciente paciente = (Paciente)request.getSession().getAttribute( DiagnosticoServlet.PACIENTE );

		// obtiene la lista de Diagn�sticos desde el HttpSession mediante la invocaci�n al m�todo
		List<Diagnostico> listaDeDiagnosticos = (List<Diagnostico>)request.getSession().getAttribute( DiagnosticoServlet.LISTA_DE_DIAGNOSTICOS );
		
		//Verifica la validez del par�metro obtenido del request
		boolean valido = true;
		if( eleccionEliminarDiagnostico == null || eleccionEliminarDiagnostico.trim().equals("") )
		{
			valido = false;
			FieldValueError.setFieldError(DiagnosticoServlet.PARAM_ELECCION_ELIMINAR_DIAGNOSTICO, "Debe optar por \"SI\" o por \"NO\" ..!", request);
		}
		
		if( valido )
		{
			if( eleccionEliminarDiagnostico != null && eleccionEliminarDiagnostico.trim().equals( DiagnosticoServlet.PARAM_NO ) )
			{
				UserNotification.addMessage(request, "Usted ha elegido NO ELIMINAR el Diagn�stico del Paciente.", UserNotification.Level.INFO );
			}
			else if( eleccionEliminarDiagnostico != null && eleccionEliminarDiagnostico.trim().equals( DiagnosticoServlet.PARAM_SI ) )
			{
				try
				{
					//Elimina el registro del Diagn�stico del Paciente de la Base de Datos: Clinica, Tabla: DIAGNOSTICOS.
					DiagnosticoHome.eliminaDiagnostico( diagnostico );
					
					// notifica al usuario con un mensaje que le indica la eliminaci�n satisfactoria del registro del diagn�stico del Paciente.
					UserNotification.addMessage(request, "El Diagn�stico ha sido eliminado satisfactoriamente de la Base de Datos.", 
						UserNotification.Level.INFO);
					
					//redirige hacia: "gestor_pacientes_diagnosticos.jsp"
					request.getRequestDispatcher( "gestor_pacientes_diagnosticos.jsp" ).forward(request, response);
					
					// retorna con "return"
					return;
				}
				catch( HibernateException hex )
				{
					UserNotification.addMessage(request, 
						"Ha ocurrido un error al acceder a la Base de datos, por favor comun�quelo al Administrador del sitio.",
						UserNotification.Level.ERROR );
				}
			}
		}
		else
		{
			UserNotification.addMessage(request, "Error: Debe confirmar si quiere eliminar el Diagn�stico del Paciente.", UserNotification.Level.ERROR );
		}
		
		// pasa como atributo del request al diagn�stico
		request.setAttribute( DiagnosticoServlet.DIAGNOSTICO, diagnostico );
		
		int idDiagnosticoNro = diagnostico.getIdDiagnostico();
		String idDiagnostico = String.valueOf( idDiagnosticoNro );
		// asigna el campo para el formulario de selecci�n de Diagn�sticos de un Paciente
		FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_SELECTOR_DIAGNOSTICO, idDiagnostico, request);
		
		// pasa la lista de Diagn�sticos como atributo del request
		request.setAttribute( DiagnosticoServlet.LISTA_DE_DIAGNOSTICOS, listaDeDiagnosticos );
		
		// pasa el paciente como atributo del request 
		request.setAttribute( DiagnosticoServlet.PACIENTE, paciente );
		
		String tipoDeDocumento = paciente.getTpoDoc();
		// asigna el campo tipo de documento para el formulario selector de Paciente
		FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_SELECTOR_TIPO_DE_DOCUMENTO, tipoDeDocumento, request );
		
		int numeroDeDocumentoNro = paciente.getNroDoc();
		String numeroDeDocumento = String.valueOf( numeroDeDocumentoNro );
		// asigna el campo N�mero de documento para el formulario selector de Paciente
		FieldValueError.setFieldValue( DiagnosticoServlet.PARAM_SELECTOR_NUMERO_DE_DOCUMENTO, numeroDeDocumento, request );
		
		// redirige la respuesta hacia do_elimina_diagnostico.jsp
		request.getRequestDispatcher( "do_elimina_diagnostico.jsp" ).forward(request, response);
	}
}