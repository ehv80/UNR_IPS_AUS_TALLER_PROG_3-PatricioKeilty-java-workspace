package dbServlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import utility.UserNotification;
import utility.UserNotification.Level;

/**
 * Servlet implementation class for Servlet: LogoutServlet
 *
 */
 public class LogoutServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
 {
	 public static final String PARAM_ELECCION_LOGOUT = "eleccionLogout";
	 public static final String PARAM_SI = "SI";
	 public static final String PARAM_NO = "NO";
	 
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public LogoutServlet() 
	{
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}  	
	
	/**
	 * Método:	doPost
	 * 			Responsable de realizar el cierre de sesi�n de un Usuario en el Portal.
	 * 
	 * 			Toma los par�metros del formulario de Salida del Portal.
	 * 
	 * 			En caso que la opci�n elegida es salir del portal:
	 * 			
	 * 				Pone en null el atributo del HttpSession denominado: LoginServlet.USUARIO
	 * 			
	 * 				Invalida la HttpSession
	 * 				
	 * 				Redirige hacia "index.jsp"
	 * 
	 * 			En caso de que la opci�n elegida es no salir del portal:
	 * 
	 * 				Notifica al Usuario con un mensaje
	 * 
	 * 				Redirige hacia "logout.jsp"
	 * 
	 * 			En cualquier otro caso:
	 * 
	 * 				Notifica al Usuario con un mensaje que le indica que debe seleccionar por SI o por NO
	 * 
	 * 				Redirige hacia "logout.jsp"
	 * 
	 * @param	request
	 * @param	response
	 * @throws	ServletException
	 * @throws	IOExcepction
	 */
	protected void doPost( HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// para la codificaci�n de caracteres
		request.setCharacterEncoding("UTF-8");
		
		String eleccionLogout;
		if( request.getParameter( PARAM_ELECCION_LOGOUT ) != null && !request.getParameter( PARAM_ELECCION_LOGOUT ).equals("") )
		{
			eleccionLogout = request.getParameter( PARAM_ELECCION_LOGOUT );
			if( eleccionLogout != null && eleccionLogout.equals( PARAM_SI ) )
			{
				request.getSession().setAttribute( LoginServlet.USUARIO , null);
				request.getSession().invalidate();
				request.getRequestDispatcher("index.jsp").forward(request, response);
				return;
			}
			if( eleccionLogout != null && eleccionLogout.equals( PARAM_NO ) )
			{
				UserNotification.addMessage(request, "Usted ha elegido continuar usando el Portal ..!", Level.INFO);
				request.getRequestDispatcher("logout.jsp").forward(request, response);
				return;
			}
		}
		else
		{
			UserNotification.addMessage(request, "Debe elegir por \"SI\" o por \"NO\" ..! ", Level.INFO);
			request.getRequestDispatcher("logout.jsp").forward(request, response);
			return;
		}
	}   	  	    
}