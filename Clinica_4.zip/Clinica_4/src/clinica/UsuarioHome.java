package clinica;
// default package
// Generated 08/12/2007 18:01:02 by Hibernate Tools 3.2.0.beta8

import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Transaction;

import dbServlets.LoginServlet;

/**
 * Home object for domain model class Usuario.
 * @see .Usuario
 * @author Hibernate Tools
 */
public class UsuarioHome {
	
	private static String mensaje;
	
	public static void setMensaje( String mensaje){ UsuarioHome.mensaje = mensaje; }
	
	public static String getMensaje(){ return UsuarioHome.mensaje; }

	//private static final Log log = LogFactory.getLog(UsuarioHome.class);

	//private final SessionFactory sessionFactory = getSessionFactory();

	/**
	 * @author ehv80
	 * Método:	consultaUsuarios
	 * 		Realiza una consulta HQL en la base de datos Clinica, Tabla USUARIOS.
	 * @param	String consultaHQL
	 * @return	List<Usuario>
	 */
	public static List<Usuario> consultaUsuarios(String consultaHQL)
	{
		Transaction transaccion;
		List<Usuario> listaDeUsuarios;
		try
		{
			if( consultaHQL != null && !consultaHQL.equals("") )
			{
				if(LoginServlet.getHibernateSessionFactory() == null)
				{
					LoginServlet.createHibernateSessionFactory();
				}
				if( LoginServlet.getHibernateSession() == null )
				{
					LoginServlet.createHibernateSession();
				}
				transaccion = LoginServlet.getHibernateSession().beginTransaction();
				listaDeUsuarios= (List<Usuario>)(LoginServlet.getHibernateSession().createQuery(consultaHQL).list());
				transaccion.commit();
				return listaDeUsuarios;
			}
			else
			{	
				UsuarioHome.setMensaje("Error en UsuarioHome.consultaUsuarios(consulatHQL): La consulta HQL no puede estar vacía ..!" );
				return (List<Usuario>)null;
			}
		}
		catch(HibernateException ex)
		{
			UsuarioHome.setMensaje("Ha ocurrido una Excepción en UsuarioHome.consultaUsuarios(consulatHQL) " + ex);
			return (List<Usuario>)null;
		}
		finally
		{
			//TODO
		}
	}
	
	/**
	 * @author ehv80
	 * Método:	almacenaUsuario
	 * 			En caso de almacenar usuario con éxito retorna Boolean.TRUE
	 * 			En caso contrario retorna Boolean.FALSE
	 * @param Usuario usuario
	 * @return Boolean isSuccesfullSaved
	 */
	public static Boolean almacenaUsuario(Usuario usuario)
	{
		Boolean isSuccesfullSaved = Boolean.FALSE; //por defecto
		Transaction transaccion;
		try
		{
			if( usuario != null && 
					!usuario.getNombreReal().equals("") &&
					!usuario.getApellido().equals("") &&
					!usuario.getNombreAcceso().equals("") &&
					!usuario.getClaveAcceso().equals("")
				)
			{
				if(LoginServlet.getHibernateSessionFactory() == null)
				{
					LoginServlet.createHibernateSessionFactory();
				}
				if( LoginServlet.getHibernateSession() == null )
				{
					LoginServlet.createHibernateSession();
				}
				transaccion = LoginServlet.getHibernateSession().beginTransaction();
				LoginServlet.getHibernateSession().save(usuario);
				transaccion.commit();
				isSuccesfullSaved = Boolean.TRUE;
				return isSuccesfullSaved;
			}
			else
			{
				UsuarioHome.setMensaje("Debe completar todos los campos del formulario ..!");
				return isSuccesfullSaved;
			}
		}
		catch(HibernateException ex)
		{
			UsuarioHome.setMensaje("Ha ocurrido una Excepción en UsuarioHome.almacenaUsuario( usuario ) " + ex);
			return isSuccesfullSaved;
		}
		finally
		{
			//TODO
		}
	}
	
	/**
	 * @author ehv80
	 * Método:	modificaUsuario
	 * 			En caso de modificar usuario con éxito retorna Boolean.TRUE
	 * 			En caso contrario retorna Boolean.FALSE
	 * @param Usuario usuario
	 * @return Boolean isSuccesfullModified
	 */
	public static Boolean modificaUsuario(Usuario usuario)
	{
		Boolean isSuccesfullModified = Boolean.FALSE; //por defecto
		Transaction transaccion;
		try
		{
			if( usuario != null && 
					!usuario.getNombreReal().equals("") &&
					!usuario.getApellido().equals("") &&
					!usuario.getNombreAcceso().equals("") &&
					!usuario.getClaveAcceso().equals("")
				)
			{
				if(LoginServlet.getHibernateSessionFactory() == null)
				{
					LoginServlet.createHibernateSessionFactory();
				}
				if( LoginServlet.getHibernateSession() == null )
				{
					LoginServlet.createHibernateSession();
				}
				transaccion = LoginServlet.getHibernateSession().beginTransaction();
				LoginServlet.getHibernateSession().saveOrUpdate(usuario);
				transaccion.commit();
				isSuccesfullModified = Boolean.TRUE;
				return isSuccesfullModified;
			}
			else
			{
				UsuarioHome.setMensaje("Debe completar todos los campos del formulario ..!");
				return isSuccesfullModified;
			}
		}
		catch(HibernateException ex)
		{
			UsuarioHome.setMensaje("Ha ocurrido una Excepción en UsuarioHome.modificaUsuario( usuario ) " + ex);
			return isSuccesfullModified;
		}
		finally
		{
			//TODO
		}
	}
	
	/**
	 * @author ehv80
	 * Método:	eliminaUsuario
	 * 			En caso de eliminar usuario con éxito retorna Boolean.TRUE
	 * 			En caso contrario retorna Boolean.FALSE
	 * @param Usuario usuario
	 * @return Boolean isSuccesfullDeleted
	 */
	public static Boolean eliminaUsuario(Usuario usuario)
	{
		Boolean isSuccesfullDeleted = Boolean.FALSE; //por defecto
		Transaction transaccion;
		try
		{
			if( usuario != null && 
					!usuario.getNombreReal().equals("") &&
					!usuario.getApellido().equals("") &&
					!usuario.getNombreAcceso().equals("") &&
					!usuario.getClaveAcceso().equals("")
				)
			{
				if(LoginServlet.getHibernateSessionFactory() == null)
				{
					LoginServlet.createHibernateSessionFactory();
				}
				if( LoginServlet.getHibernateSession() == null )
				{
					LoginServlet.createHibernateSession();
				}
				transaccion = LoginServlet.getHibernateSession().beginTransaction();
				LoginServlet.getHibernateSession().delete(usuario);
				transaccion.commit();
				isSuccesfullDeleted = Boolean.TRUE;
				return isSuccesfullDeleted;
			}
			else
			{
				UsuarioHome.setMensaje("Debe completar todos los campos del formulario ..!");
				return isSuccesfullDeleted;
			}
		}
		catch(HibernateException ex)
		{
			UsuarioHome.setMensaje("Ha ocurrido una Excepción en UsuarioHome.eliminaUsuario( usuario ) " + ex);
			return isSuccesfullDeleted;
		}
		finally
		{
			//TODO
		}
	}
	
	
	/*
	*protected SessionFactory getSessionFactory() {
	*	try {
	*		return (SessionFactory) new InitialContext()
	*				.lookup("SessionFactory");
	*	} catch (Exception e) {
	*		log.error("Could not locate SessionFactory in JNDI", e);
	*		throw new IllegalStateException(
	*				"Could not locate SessionFactory in JNDI");
	*	}
	*}
	*/
	
	/*
	*public void persist(Usuario transientInstance) {
	*	log.debug("persisting Usuario instance");
	*	try {
	*		sessionFactory.getCurrentSession().persist(transientInstance);
	*		log.debug("persist successful");
	*	} catch (RuntimeException re) {
	*		log.error("persist failed", re);
	*		throw re;
	*	}
	*}
	*/
	
	/*
	*public void attachDirty(Usuario instance) {
	*	log.debug("attaching dirty Usuario instance");
	*	try {
	*		sessionFactory.getCurrentSession().saveOrUpdate(instance);
	*		log.debug("attach successful");
	*	} catch (RuntimeException re) {
	*		log.error("attach failed", re);
	*		throw re;
	*	}
	*}
	*/
	
	/*
	*public void attachClean(Usuario instance) {
	*	log.debug("attaching clean Usuario instance");
	*	try {
	*		sessionFactory.getCurrentSession().lock(instance, LockMode.NONE);
	*		log.debug("attach successful");
	*	} catch (RuntimeException re) {
	*		log.error("attach failed", re);
	*		throw re;
	*	}
	*}
	*/
	
	/*
	*public void delete(Usuario persistentInstance) {
	*	log.debug("deleting Usuario instance");
	*	try {
	*		sessionFactory.getCurrentSession().delete(persistentInstance);
	*		log.debug("delete successful");
	*	} catch (RuntimeException re) {
	*		log.error("delete failed", re);
	*		throw re;
	*	}
	*}
	*/
	
	/*
	*public Usuario merge(Usuario detachedInstance) {
	*	log.debug("merging Usuario instance");
	*	try {
	*		Usuario result = (Usuario) sessionFactory.getCurrentSession()
	*				.merge(detachedInstance);
	*		log.debug("merge successful");
	*		return result;
	*	} catch (RuntimeException re) {
	*		log.error("merge failed", re);
	*		throw re;
	*	}
	*}
	*/
	
	/*
	*public Usuario findById(int id) {
	*	log.debug("getting Usuario instance with id: " + id);
	*	try {
	*		Usuario instance = (Usuario) sessionFactory.getCurrentSession()
	*				.get("Usuario", id);
	*		if (instance == null) {
	*			log.debug("get successful, no instance found");
	*		} else {
	*			log.debug("get successful, instance found");
	*		}
	*		return instance;
	*	} catch (RuntimeException re) {
	*		log.error("get failed", re);
	*		throw re;
	*	}
	*}
	*/
	
	/*
	*public List<Usuario> findByExample(Usuario instance) {
	*	log.debug("finding Usuario instance by example");
	*	try {
	*		List<Usuario> results = (List<Usuario>) sessionFactory
	*				.getCurrentSession().createCriteria("Usuario").add(
	*						create(instance)).list();
	*		log.debug("find by example successful, result size: "
	*				+ results.size());
	*		return results;
	*	} catch (RuntimeException re) {
	*		log.error("find by example failed", re);
	*		throw re;
	*	}
	*}
	*/
}
