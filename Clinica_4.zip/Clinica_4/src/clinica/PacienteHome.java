package clinica;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Transaction;

import dbServlets.LoginServlet;
// default package
// Generated 08/12/2007 18:01:02 by Hibernate Tools 3.2.0.beta8

/**
 * Home object for domain model class Paciente.
 * @see .Paciente
 * @author Hibernate Tools
 */
public class PacienteHome {

	private static String mensaje;
	
	public static void setMensaje(String mensaje){ PacienteHome.mensaje = mensaje; }
	
	public static String getMensaje(){ return PacienteHome.mensaje; }
	
	/**
	 * @author ehv80
	 * Método:	consultaPacientes
	 * 		Realiza una consulta HQL en la base de datos Clinica, Tabla PACIENTES.
	 * @param	String consultaHQL
	 * @return	List<Paciente>
	 */
	public static List<Paciente> consultaPacientes(String consultaHQL)
	{
		Transaction transaccion;
		List<Paciente> listaDePacientes;
		try
		{
			if( consultaHQL != null && !consultaHQL.equals("") )
			{
				if(LoginServlet.getHibernateSessionFactory() == null)
				{
					LoginServlet.createHibernateSessionFactory();
				}
				if( LoginServlet.getHibernateSession() == null )
				{
					LoginServlet.createHibernateSession();
				}
				transaccion = LoginServlet.getHibernateSession().beginTransaction();
				listaDePacientes= (List<Paciente>)(LoginServlet.getHibernateSession().createQuery(consultaHQL).list());
				transaccion.commit();
				return listaDePacientes;
			}
			else
			{	
				PacienteHome.setMensaje("Error en PacienteHome.consultaPacientes(consulatHQL): La consulta HQL no puede estar vacía ..!" );
				return (List<Paciente>)null;
			}
		}
		catch(HibernateException ex)
		{
			PacienteHome.setMensaje("Ha ocurrido una Excepción en PacienteHome.consultaPacientes(consulatHQL) " + ex);
			return (List<Paciente>)null;
		}
		finally
		{
			//TODO
		}
	}
	
	
	/**
	 * @author ehv80
	 * Método:	almacenaPaciente
	 * 			En caso de almacenar paciente con éxito retorna Boolean.TRUE
	 * 			En caso contrario retorna Boolean.FALSE
	 * @param Paciente paciente
	 * @return Boolean isSuccesfullSaved
	 */
	public static Boolean almacenaPaciente(Paciente paciente)
	{
		Boolean isSuccesfullSaved = Boolean.FALSE; //por defecto
		Transaction transaccion;
		try
		{
			if( paciente != null &&
					!String.valueOf( paciente.getIdPaciente() ).equals("") &&
					!paciente.getNombre().equals("") &&
					!paciente.getApellido().equals("") &&
					!paciente.getFechaNac().toString().equals("") &&
					!paciente.getTpoDoc().equals("") &&
					!String.valueOf( paciente.getNroDoc() ).equals("") &&
					!paciente.getObraSocial().equals("") &&
					!paciente.getSexo().equals("") &&
					!String.valueOf( paciente.isEstaVivo() ).equals("") 
				)
			{
				if(LoginServlet.getHibernateSessionFactory() == null)
				{
					LoginServlet.createHibernateSessionFactory();
				}
				if( LoginServlet.getHibernateSession() == null )
				{
					LoginServlet.createHibernateSession();
				}
				transaccion = LoginServlet.getHibernateSession().beginTransaction();
				LoginServlet.getHibernateSession().save(paciente);
				transaccion.commit();
				isSuccesfullSaved = Boolean.TRUE;
				return isSuccesfullSaved;
			}
			else
			{
				PacienteHome.setMensaje("Debe completar todos los campos del formulario ..!");
				return isSuccesfullSaved;
			}
		}
		catch(HibernateException hex)
		{
			PacienteHome.setMensaje("Ha ocurrido una Excepción en PacienteHome.almacenaPaciente( paciente ) " + hex);
			return isSuccesfullSaved;
		}
		finally
		{
			//TODO
		}
	}
	
	/**
	 * @author ehv80
	 * Método:	actualizaPaciente
	 * 			En caso de actualizar paciente con éxito retorna Boolean.TRUE
	 * 			En caso contrario retorna Boolean.FALSE
	 * @param Paciente paciente
	 * @return Boolean isSuccesfullUpdated
	 */
	public static Boolean actualizaPaciente(Paciente paciente)
	{
		Boolean isSuccesfullUpdated = Boolean.FALSE; //por defecto
		Transaction transaccion;
		try
		{
			if( paciente != null &&
					!String.valueOf( paciente.getIdPaciente() ).equals("") &&
					!paciente.getNombre().equals("") &&
					!paciente.getApellido().equals("") &&
					!paciente.getFechaNac().toString().equals("") &&
					!paciente.getTpoDoc().equals("") &&
					!String.valueOf( paciente.getNroDoc() ).equals("") &&
					!paciente.getObraSocial().equals("") &&
					!paciente.getSexo().equals("") &&
					!String.valueOf( paciente.isEstaVivo() ).equals("") 
				)
			{
				if(LoginServlet.getHibernateSessionFactory() == null)
				{
					LoginServlet.createHibernateSessionFactory();
				}
				if( LoginServlet.getHibernateSession() == null )
				{
					LoginServlet.createHibernateSession();
				}
				transaccion = LoginServlet.getHibernateSession().beginTransaction();
				LoginServlet.getHibernateSession().saveOrUpdate(paciente);
				transaccion.commit();
				isSuccesfullUpdated = Boolean.TRUE;
				return isSuccesfullUpdated;
			}
			else
			{
				PacienteHome.setMensaje("Debe completar todos los campos del formulario ..!");
				return isSuccesfullUpdated;
			}
		}
		catch(HibernateException hex)
		{
			PacienteHome.setMensaje("Ha ocurrido una Excepción en PacienteHome.actualizaPaciente( paciente ) " + hex);
			return isSuccesfullUpdated;
		}
		finally
		{
			//TODO
		}
	}
		
	/**
	 * @author ehv80
	 * Método:	eliminaPaciente
	 * 			En caso de eliminar paciente con éxito retorna Boolean.TRUE
	 * 			En caso contrario retorna Boolean.FALSE
	 * @param Paciente paciente
	 * @return Boolean isSuccesfullDeleted
	 */
	public static Boolean eliminaPaciente(Paciente paciente)
	{
		Boolean isSuccesfullDeleted = Boolean.FALSE; //por defecto
		Transaction transaccion;
		try
		{
			if( paciente != null &&
					!String.valueOf( paciente.getIdPaciente() ).equals("") &&
					!paciente.getNombre().equals("") &&
					!paciente.getApellido().equals("") &&
					!paciente.getFechaNac().toString().equals("") &&
					!paciente.getTpoDoc().equals("") &&
					!String.valueOf( paciente.getNroDoc() ).equals("") &&
					!paciente.getObraSocial().equals("") &&
					!paciente.getSexo().equals("") &&
					!String.valueOf( paciente.isEstaVivo() ).equals("") 
				)
			{
				if(LoginServlet.getHibernateSessionFactory() == null)
				{
					LoginServlet.createHibernateSessionFactory();
				}
				if( LoginServlet.getHibernateSession() == null )
				{
					LoginServlet.createHibernateSession();
				}
				transaccion = LoginServlet.getHibernateSession().beginTransaction();
				LoginServlet.getHibernateSession().delete(paciente);
				transaccion.commit();
				isSuccesfullDeleted = Boolean.TRUE;
				return isSuccesfullDeleted;
			}
			else
			{
				PacienteHome.setMensaje("Debe completar todos los campos del formulario ..!");
				return isSuccesfullDeleted;
			}
		}
		catch(HibernateException hex)
		{
			PacienteHome.setMensaje("Ha ocurrido una Excepción en PacienteHome.eliminaPaciente( paciente ) " + hex);
			return isSuccesfullDeleted;
		}
		finally
		{
			//TODO
		}
	}
		
	//private static final Log log = LogFactory.getLog(PacienteHome.class);

	//private final SessionFactory sessionFactory = getSessionFactory();

	/*
	*protected SessionFactory getSessionFactory() {
	*	try {
	*		return (SessionFactory) new InitialContext()
	*				.lookup("SessionFactory");
	*	} catch (Exception e) {
	*		log.error("Could not locate SessionFactory in JNDI", e);
	*		throw new IllegalStateException(
	*				"Could not locate SessionFactory in JNDI");
	*	}
	*}
	*/
	
	/*
	*public void persist(Paciente transientInstance) {
	*	log.debug("persisting Paciente instance");
	*	try {
	*		sessionFactory.getCurrentSession().persist(transientInstance);
	*		log.debug("persist successful");
	*	} catch (RuntimeException re) {
	*		log.error("persist failed", re);
	*		throw re;
	*	}
	*}
	*/

	/*
	*public void attachDirty(Paciente instance) {
	*	log.debug("attaching dirty Paciente instance");
	*	try {
	*		sessionFactory.getCurrentSession().saveOrUpdate(instance);
	*		log.debug("attach successful");
	*	} catch (RuntimeException re) {
	*		log.error("attach failed", re);
	*		throw re;
	*	}
	*}
	*/

	/*
	*public void attachClean(Paciente instance) {
	*	log.debug("attaching clean Paciente instance");
	*	try {
	*		sessionFactory.getCurrentSession().lock(instance, LockMode.NONE);
	*		log.debug("attach successful");
	*	} catch (RuntimeException re) {
	*		log.error("attach failed", re);
	*		throw re;
	*	}
	*}
	*/
	
	/*
	*public void delete(Paciente persistentInstance) {
	*	log.debug("deleting Paciente instance");
	*	try {
	*		sessionFactory.getCurrentSession().delete(persistentInstance);
	*		log.debug("delete successful");
	*	} catch (RuntimeException re) {
	*		log.error("delete failed", re);
	*		throw re;
	*	}
	*}
	*/
	
	/*
	*public Paciente merge(Paciente detachedInstance) {
	*	log.debug("merging Paciente instance");
	*	try {
	*		Paciente result = (Paciente) sessionFactory.getCurrentSession()
	*				.merge(detachedInstance);
	*		log.debug("merge successful");
	*		return result;
	*	} catch (RuntimeException re) {
	*		log.error("merge failed", re);
	*		throw re;
	*	}
	*}
	*/
	
	/*
	*public Paciente findById(int id) {
	*	log.debug("getting Paciente instance with id: " + id);
	*	try {
	*		Paciente instance = (Paciente) sessionFactory.getCurrentSession()
	*				.get("Paciente", id);
	*		if (instance == null) {
	*			log.debug("get successful, no instance found");
	*		} else {
	*			log.debug("get successful, instance found");
	*		}
	*		return instance;
	*	} catch (RuntimeException re) {
	*		log.error("get failed", re);
	*		throw re;
	*	}
	*}
	*/
	
	/*
	*public List<Paciente> findByExample(Paciente instance) {
	*	log.debug("finding Paciente instance by example");
	*	try {
	*		List<Paciente> results = (List<Paciente>) sessionFactory
	*				.getCurrentSession().createCriteria("Paciente").add(
	*						create(instance)).list();
	*		log.debug("find by example successful, result size: "
	*				+ results.size());
	*		return results;
	*	} catch (RuntimeException re) {
	*		log.error("find by example failed", re);
	*		throw re;
	*	}
	*}
	*/
}
