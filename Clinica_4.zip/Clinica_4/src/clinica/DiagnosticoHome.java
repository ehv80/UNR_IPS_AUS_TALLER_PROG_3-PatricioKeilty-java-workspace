package clinica;
// default package
// Generated 08/12/2007 18:01:02 by Hibernate Tools 3.2.0.beta8

import java.util.List;
import javax.naming.InitialContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.LockMode;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import dbServlets.LoginServlet;

import static org.hibernate.criterion.Example.create;

/**
 * Home object for domain model class Diagnostico.
 * @see .Diagnostico
 * @author Hibernate Tools
 */
public class DiagnosticoHome 
{
	public static String mensaje;
	
	public static void setMensaje(String mensaje){ DiagnosticoHome.mensaje = mensaje; }
	
	public static String getMensaje(){ return DiagnosticoHome.mensaje; }

	/**
	 * @author ehv80
	 * Método:	consultaDiagnosticos
	 * 		Realiza una consulta HQL en la base de datos Clinica, Tabla DIAGNOSTICOS.
	 * @param	String consultaHQL
	 * @return	List<Diagnostico>
	 */
	public static List<Diagnostico> consultaDiagnosticos(String consultaHQL)
	{
		Transaction transaccion;
		List<Diagnostico> listaDeDiagnosticos;
		try
		{
			if( consultaHQL != null && !consultaHQL.equals("") )
			{
				if(LoginServlet.getHibernateSessionFactory() == null)
				{
					LoginServlet.createHibernateSessionFactory();
				}
				if( LoginServlet.getHibernateSession() == null )
				{
					LoginServlet.createHibernateSession();
				}
				transaccion = LoginServlet.getHibernateSession().beginTransaction();
				listaDeDiagnosticos= (List<Diagnostico>)(LoginServlet.getHibernateSession().createQuery(consultaHQL).list());
				transaccion.commit();
				return listaDeDiagnosticos;
			}
			else
			{	
				DiagnosticoHome.setMensaje("Error en DiagnosticoHome.consultaDiagnosticos(consulatHQL): La consulta HQL no puede estar vacía ..!" );
				return (List<Diagnostico>)null;
			}
		}
		catch(HibernateException ex)
		{
			DiagnosticoHome.setMensaje("Ha ocurrido una Excepción en DiagnosticoHome.consultaDiagnosticos(consulatHQL) " + ex);
			return (List<Diagnostico>)null;
		}
		finally
		{
			//TODO
		}
	}
	
	/**
	 * @author ehv80
	 * Método:	almacenaDiagnostico
	 * 			En caso de almacenar Diagnostico con éxito retorna Boolean.TRUE
	 * 			En caso contrario retorna Boolean.FALSE
	 * @param Diagnostico diagnostico
	 * @return Boolean isSuccesfullSaved
	 */
	public static Boolean almacenaDiagnostico(Diagnostico diagnostico)
	{
		Boolean isSuccesfullSaved = Boolean.FALSE; //por defecto
		Transaction transaccion;
		try
		{
			if( diagnostico != null &&
					!String.valueOf( diagnostico.getIdDiagnostico() ).equals("") &&
					!String.valueOf( diagnostico.getPaciente().getIdPaciente() ).equals("") &&
					!diagnostico.getDescripcion().equals("") &&
					!diagnostico.getFecha().toString().equals("")
				)
			{
				if(LoginServlet.getHibernateSessionFactory() == null)
				{
					LoginServlet.createHibernateSessionFactory();
				}
				if( LoginServlet.getHibernateSession() == null )
				{
					LoginServlet.createHibernateSession();
				}
				transaccion = LoginServlet.getHibernateSession().beginTransaction();
				LoginServlet.getHibernateSession().save(diagnostico);
				transaccion.commit();
				isSuccesfullSaved = Boolean.TRUE;
				return isSuccesfullSaved;
			}
			else
			{
				DiagnosticoHome.setMensaje("Debe completar todos los campos del formulario ..!");
				return isSuccesfullSaved;
			}
		}
		catch(HibernateException hex)
		{
			PacienteHome.setMensaje("Ha ocurrido una Excepción en DiagnosticoHome.almacenaDiagnostico( diagnostico ) " + hex);
			return isSuccesfullSaved;
		}
		finally
		{
			//TODO
		}
	}
	
	/**
	 * @author ehv80
	 * Método:	actualizaDiagnostico
	 * 			En caso de actualizar diagnostico con éxito retorna Boolean.TRUE
	 * 			En caso contrario retorna Boolean.FALSE
	 * @param Diagnostico diagnostico
	 * @return Boolean isSuccesfullUpdated
	 */
	public static Boolean actualizaDiagnostico(Diagnostico diagnostico)
	{
		Boolean isSuccesfullUpdated = Boolean.FALSE; //por defecto
		Transaction transaccion;
		try
		{
			if( diagnostico != null &&
					!String.valueOf( diagnostico.getIdDiagnostico() ).equals("") &&
					!String.valueOf( diagnostico.getPaciente().getIdPaciente() ).equals("") &&
					!diagnostico.getDescripcion().equals("") &&
					!diagnostico.getFecha().toString().equals("")
				)
			{
				if(LoginServlet.getHibernateSessionFactory() == null)
				{
					LoginServlet.createHibernateSessionFactory();
				}
				if( LoginServlet.getHibernateSession() == null )
				{
					LoginServlet.createHibernateSession();
				}
				transaccion = LoginServlet.getHibernateSession().beginTransaction();
				LoginServlet.getHibernateSession().saveOrUpdate(diagnostico);
				transaccion.commit();
				isSuccesfullUpdated = Boolean.TRUE;
				return isSuccesfullUpdated;
			}
			else
			{
				DiagnosticoHome.setMensaje("Debe completar todos los campos del formulario ..!");
				return isSuccesfullUpdated;
			}
		}
		catch(HibernateException hex)
		{
			DiagnosticoHome.setMensaje("Ha ocurrido una Excepción en DiagnosticoHome.actualizaDiagnostico( diagnostico ) " + hex);
			return isSuccesfullUpdated;
		}
		finally
		{
			//TODO
		}
	}
		
	/**
	 * @author ehv80
	 * Método:	eliminaDiagnostico
	 * 			En caso de eliminar diagnostico con éxito retorna Boolean.TRUE
	 * 			En caso contrario retorna Boolean.FALSE
	 * @param Diagnostico diagnostico
	 * @return Boolean isSuccesfullDeleted
	 */
	public static Boolean eliminaDiagnostico(Diagnostico diagnostico)
	{
		Boolean isSuccesfullDeleted = Boolean.FALSE; //por defecto
		Transaction transaccion;
		try
		{
			if( diagnostico != null &&
					!String.valueOf( diagnostico.getIdDiagnostico() ).equals("") &&
					!String.valueOf( diagnostico.getPaciente().getIdPaciente() ).equals("") &&
					!diagnostico.getDescripcion().equals("") &&
					!diagnostico.getFecha().toString().equals("")
				)
			{
				if(LoginServlet.getHibernateSessionFactory() == null)
				{
					LoginServlet.createHibernateSessionFactory();
				}
				if( LoginServlet.getHibernateSession() == null )
				{
					LoginServlet.createHibernateSession();
				}
				transaccion = LoginServlet.getHibernateSession().beginTransaction();
				LoginServlet.getHibernateSession().delete(diagnostico);
				transaccion.commit();
				isSuccesfullDeleted = Boolean.TRUE;
				return isSuccesfullDeleted;
			}
			else
			{
				DiagnosticoHome.setMensaje("Debe completar todos los campos del formulario ..!");
				return isSuccesfullDeleted;
			}
		}
		catch(HibernateException hex)
		{
			DiagnosticoHome.setMensaje("Ha ocurrido una Excepción en DiagnosticoHome.eliminaDiagnostico( diagnostico ) " + hex);
			return isSuccesfullDeleted;
		}
		finally
		{
			//TODO
		}
	}
	
	
	//private static final Log log = LogFactory.getLog(DiagnosticoHome.class);

	//private final SessionFactory sessionFactory = getSessionFactory();

	/*protected SessionFactory getSessionFactory() {
	*	try {
	*		return (SessionFactory) new InitialContext()
	*				.lookup("SessionFactory");
	*	} catch (Exception e) {
	*		log.error("Could not locate SessionFactory in JNDI", e);
	*		throw new IllegalStateException(
	*				"Could not locate SessionFactory in JNDI");
	*	}
	*}
	*/
	
	/*
	*public void persist(Diagnostico transientInstance) {
	*	log.debug("persisting Diagnostico instance");
	*	try {
	*		sessionFactory.getCurrentSession().persist(transientInstance);
	*		log.debug("persist successful");
	*	} catch (RuntimeException re) {
	*		log.error("persist failed", re);
	*		throw re;
	*	}
	*}
	*/
	
	/*
	*public void attachDirty(Diagnostico instance) {
	*	log.debug("attaching dirty Diagnostico instance");
	*	try {
	*		sessionFactory.getCurrentSession().saveOrUpdate(instance);
	*		log.debug("attach successful");
	*	} catch (RuntimeException re) {
	*		log.error("attach failed", re);
	*		throw re;
	*	}
	*}
	*/
	
	/*
	*public void attachClean(Diagnostico instance) {
	*	log.debug("attaching clean Diagnostico instance");
	*	try {
	*		sessionFactory.getCurrentSession().lock(instance, LockMode.NONE);
	*		log.debug("attach successful");
	*	} catch (RuntimeException re) {
	*		log.error("attach failed", re);
	*		throw re;
	*	}
	*}
	*/
	
	/*
	*public void delete(Diagnostico persistentInstance) {
	*	log.debug("deleting Diagnostico instance");
	*	try {
	*		sessionFactory.getCurrentSession().delete(persistentInstance);
	*		log.debug("delete successful");
	*	} catch (RuntimeException re) {
	*		log.error("delete failed", re);
	*		throw re;
	*	}
	*}
	*/
	
	/*
	*public Diagnostico merge(Diagnostico detachedInstance) {
	*	log.debug("merging Diagnostico instance");
	*	try {
	*		Diagnostico result = (Diagnostico) sessionFactory
	*				.getCurrentSession().merge(detachedInstance);
	*		log.debug("merge successful");
	*		return result;
	*	} catch (RuntimeException re) {
	*		log.error("merge failed", re);
	*		throw re;
	*	}
	*}
	*/
	
	/*
	*public Diagnostico findById(int id) {
	*	log.debug("getting Diagnostico instance with id: " + id);
	*	try {
	*		Diagnostico instance = (Diagnostico) sessionFactory
	*				.getCurrentSession().get("Diagnostico", id);
	*		if (instance == null) {
	*			log.debug("get successful, no instance found");
	*		} else {
	*			log.debug("get successful, instance found");
	*		}
	*		return instance;
	*	} catch (RuntimeException re) {
	*		log.error("get failed", re);
	*		throw re;
	*	}
	*}
	*/
	
	/*
	*public List<Diagnostico> findByExample(Diagnostico instance) {
	*	log.debug("finding Diagnostico instance by example");
	*	try {
	*		List<Diagnostico> results = (List<Diagnostico>) sessionFactory
	*				.getCurrentSession().createCriteria("Diagnostico").add(
	*						create(instance)).list();
	*		log.debug("find by example successful, result size: "
	*				+ results.size());
	*		return results;
	*	} catch (RuntimeException re) {
	*		log.error("find by example failed", re);
	*		throw re;
	*	}
	*}
	*/
}