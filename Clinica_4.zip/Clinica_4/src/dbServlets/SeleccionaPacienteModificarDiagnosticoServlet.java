package dbServlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import clinica.Paciente;
import clinica.PacienteHome;

/**
 * Servlet implementation class for Servlet: SeleccionaPacienteModificarDiagnosticoServlet
 *
 */
 public class SeleccionaPacienteModificarDiagnosticoServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
 {
	 private static String mensaje;
	 
	 public static void setMensaje(String mensaje){ SeleccionaPacienteModificarDiagnosticoServlet.mensaje = mensaje; }
	 
	 public static String getMensaje(){ return SeleccionaPacienteModificarDiagnosticoServlet.mensaje; }
	 
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public SeleccionaPacienteModificarDiagnosticoServlet() 
	{
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String selectorPacienteModificarDiagnostico;
		String consultaHQL;
		List<Paciente> listaDePacientes;
		Paciente pacienteSeleccionadoModificarDiagnostico;
		try
		{
			if( request.getParameter("selectorPacienteModificarDiagnostico") != null && 
					!request.getParameter("selectorPacienteModificarDiagnostico").equals("") 
				)
			{
				selectorPacienteModificarDiagnostico = request.getParameter("selectorPacienteModificarDiagnostico");
				consultaHQL = "select p from Paciente as p where 1=1 and p.idPaciente = '" + selectorPacienteModificarDiagnostico + "'";
				listaDePacientes = PacienteHome.consultaPacientes(consultaHQL);
				if( listaDePacientes == null )
				{
					if( PacienteHome.getMensaje() == null )
					{
						SeleccionaPacienteModificarDiagnosticoServlet.setMensaje(
								"EL Paciente seleccionado no puede ser nulo ..! Vuelva a intentarlo ..!" );
						request.getSession().setAttribute("mensajeSeleccionaPacienteModificarDiagnostico" , 
								SeleccionaPacienteModificarDiagnosticoServlet.getMensaje() );
						response.sendRedirect("do_modifica_diagnostico.jsp");
					}
					else if( PacienteHome.getMensaje() != null && !PacienteHome.getMensaje().equals("") )
					{
						SeleccionaPacienteModificarDiagnosticoServlet.setMensaje( PacienteHome.getMensaje() );
						request.getSession().setAttribute("mensajeSeleccionaPacienteModificarDiagnostico" ,
								SeleccionaPacienteModificarDiagnosticoServlet.getMensaje() );
						response.sendRedirect("do_modifica_diagnostico.jsp");
					}
				}
				else if( listaDePacientes != null )
				{
					if( listaDePacientes.isEmpty() )
					{
						SeleccionaPacienteModificarDiagnosticoServlet.setMensaje( 
								"EL Paciente que ha seleccionado para modificar un Diagnóstico no está registrado en la Base de Datos ..!" +
								"Vuelva a intentarlo ..!" );
						request.getSession().setAttribute("mensajeSeleccionaPacienteModificarDiagnostico" ,
								SeleccionaPacienteModificarDiagnosticoServlet.getMensaje() );
						response.sendRedirect("do_modifica_diagnostico.jsp");
					}
					else if( !listaDePacientes.isEmpty() )
					{
						if( listaDePacientes.size() == 1 )
						{
							pacienteSeleccionadoModificarDiagnostico = listaDePacientes.get(0); //índice comienza en cero
							if( String.valueOf( pacienteSeleccionadoModificarDiagnostico.getIdPaciente() ).equals( selectorPacienteModificarDiagnostico ) )
							{
								request.getSession().setAttribute("pacienteSeleccionadoModificarDiagnostico", pacienteSeleccionadoModificarDiagnostico);
								response.sendRedirect("do_modifica_diagnostico.jsp");
							}
						}
						else
						{
							SeleccionaPacienteModificarDiagnosticoServlet.setMensaje(
									"EL Paciente que ha seleccionado para modificar un Diagnóstico no está registrado en la Base de Datos ..!" +
									"Vuelva a intentarlo ..!" );
							request.getSession().setAttribute("mensajeSeleccionaPacienteModificarDiagnostico" , 
									SeleccionaPacienteModificarDiagnosticoServlet.getMensaje() );
							response.sendRedirect("do_modifica_diagnostico.jsp");
						}
					}
				}
			}	
			else
			{
				SeleccionaPacienteModificarDiagnosticoServlet.setMensaje("Debe seleccionar uno de los Pacientes en el selector ..!");
				request.getSession().setAttribute("mensajeSeleccionaPacienteModificarDiagnostico", 
						SeleccionaPacienteModificarDiagnosticoServlet.getMensaje() );
				response.sendRedirect("do_modifica_diagnostico.jsp");
			}
		}
		catch(HibernateException hex)
		{
			SeleccionaPacienteModificarDiagnosticoServlet.setMensaje(
					"Ha ocurrido una Excepción en SeleccionaPacienteModificarDiagnosticoServlet.doPost(request, response) : " + hex);
			request.getSession().setAttribute("mensajeSeleccionaPacienteModificarDiagnostico",
					SeleccionaPacienteModificarDiagnosticoServlet.getMensaje() );
			response.sendRedirect("do_modifica_diagnostico.jsp");
		}
		catch(Exception ex)
		{
			SeleccionaPacienteModificarDiagnosticoServlet.setMensaje(
					"Ha ocurrido una Excepción en SeleccionaPacienteModificarDiagnosticoServlet.doPost(request, response) : " + ex);
			request.getSession().setAttribute("mensajeSeleccionaPacienteModificarDiagnostico",
					SeleccionaPacienteModificarDiagnosticoServlet.getMensaje() );
			response.sendRedirect("do_modifica_diagnostico.jsp");
		}
	}   	  	    
}