package dbServlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import clinica.Usuario;
import clinica.UsuarioHome;

/**
 * Servlet implementation class for Servlet: RegistraUsuarioServlet
 *
 */
 public class RegistraUsuarioServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
 {
	 private static String mensaje;
	 
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public RegistraUsuarioServlet() {
		super();
	}   	
	
	public static void setMensaje(String mensaje){ RegistraUsuarioServlet.mensaje = mensaje; }
	
	public static String getMensaje(){ return RegistraUsuarioServlet.mensaje; }
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String nombreReal;
		String apellido;
		String nombreAcceso;
		String claveAcceso;
		Boolean isUsernameRepeated = Boolean.FALSE; //por defecto;
		String consultaHQL;
		List<Usuario> listaDeUsuarios;
		Usuario usuario;
		Boolean isUsuarioSuccesfullSaved = Boolean.FALSE; //por defecto
		
		if( !request.getParameter("nombreReal").equals("") && 
			!request.getParameter("apellido").equals("") &&
			!request.getParameter("username").equals("") &&
			!request.getParameter("password").equals("")
			)
		{
			try
			{
				nombreReal = request.getParameter("nombreReal");
				apellido = request.getParameter("apellido");
				nombreAcceso = request.getParameter("username");
				claveAcceso = request.getParameter("password");
				
				request.getSession().setAttribute("nombreReal", nombreReal);
				request.getSession().setAttribute("apellido", apellido);
				request.getSession().setAttribute("username", nombreAcceso);
				request.getSession().setAttribute("password", claveAcceso);
				
				if( LoginServlet.getHibernateSessionFactory() == null )
				{
					LoginServlet.createHibernateSessionFactory();
				}
				if( LoginServlet.getHibernateSession() == null )
				{
					LoginServlet.createHibernateSession();
				}
				//Verifica si el username ya existe, entonces no puede
				// registrarlo y vuelve al formulario pidiéndole que 
				// elija otro username
				consultaHQL = "select u from Usuario as u where 1=1 and u.nombreAcceso = '" + nombreAcceso +"'";
				listaDeUsuarios = UsuarioHome.consultaUsuarios(consultaHQL);
				if( listaDeUsuarios == null )
				{
					if( UsuarioHome.getMensaje() != null && !UsuarioHome.getMensaje().equals("") )
					{
						RegistraUsuarioServlet.setMensaje( UsuarioHome.getMensaje() );
						request.getSession().setAttribute("mensaje", RegistraUsuarioServlet.getMensaje() );
						response.sendRedirect("do_registra_usuario.jsp");
					}
				}
				if( listaDeUsuarios != null && listaDeUsuarios.isEmpty() )
				{
					//No hay en la base de datos alguien registrado con ese username => puede registrarlo!
					usuario = new Usuario(nombreReal, apellido, nombreAcceso , claveAcceso);
					isUsuarioSuccesfullSaved = UsuarioHome.almacenaUsuario(usuario);
					if( isUsuarioSuccesfullSaved.booleanValue() == true )
					{
						RegistraUsuarioServlet.setMensaje("" +
								"Ahora puede obtener acceso a los recursos del Portal autenticándose mediante el enlace llamado \"Login\" ..!"
							);
						request.getSession().setAttribute("mensaje", RegistraUsuarioServlet.getMensaje() );
						//response.sendRedirect("do_registra_usuario.jsp")
						response.sendRedirect("index.jsp");
					}
					if(isUsuarioSuccesfullSaved.booleanValue() == false )
					{
						RegistraUsuarioServlet.setMensaje( UsuarioHome.getMensaje() );
						request.getSession().setAttribute("mensaje", RegistraUsuarioServlet.getMensaje() );
						response.sendRedirect("do_registra_usuario.jsp");
					}
				}
				if( listaDeUsuarios != null && !listaDeUsuarios.isEmpty() )
				{
					//Hay alguien registrado en la base de datos con ese username => redirige y avisa
					isUsernameRepeated = Boolean.TRUE;
					request.getSession().setAttribute("isUsernameRepeated", isUsernameRepeated);
					response.sendRedirect("do_registra_usuario.jsp");
				}
			}
			catch(HibernateException hex)
			{
				setMensaje("Ha ocurrido una Excepción en RegistraUsuarioServlet.doPost(request, response) " + hex);
				request.getSession().setAttribute("mensaje", getMensaje() );
				response.sendRedirect("do_registra_usuario.jsp");
			}
			catch(Exception ex)
			{
				setMensaje("Ha ocurrido una Excepción en RegistraUsuarioServlet.doPost(request, response) " + ex);
				request.getSession().setAttribute("mensaje", getMensaje() );
				response.sendRedirect("do_registra_usuario.jsp");
			}
		}
		else
		{
			try
			{
				nombreReal = request.getParameter("nombreReal");
				apellido = request.getParameter("apellido");
				nombreAcceso = request.getParameter("username");
				claveAcceso = request.getParameter("password");
			
				request.getSession().setAttribute("nombreReal", nombreReal);
				request.getSession().setAttribute("apellido", apellido);
				request.getSession().setAttribute("username", nombreAcceso);
				request.getSession().setAttribute("password", claveAcceso);
						
				setMensaje("Debe completar todos los campos del formulario ..!");
				request.getSession().setAttribute("mensaje", RegistraUsuarioServlet.getMensaje() );
				response.sendRedirect("do_registra_usuario.jsp");
			}
			catch(Exception ex)
			{
				setMensaje("Ha ocurrido una Excepción en RegistraUsuarioServlet.doPost(request, response) " + ex);
				request.getSession().setAttribute("mensaje", getMensaje() );
				response.sendRedirect("do_registra_usuario.jsp");
			}
		}
	}   	  	    
}