package dbServlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import clinica.Paciente;
import clinica.PacienteHome;

/**
 * Servlet implementation class for Servlet: SeleccionaPacienteEliminarDiagnosticoServlet
 *
 */
 public class SeleccionaPacienteEliminarDiagnosticoServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
 {
	 private static String mensaje;
	 
	 public static void setMensaje( String mensaje){ SeleccionaPacienteEliminarDiagnosticoServlet.mensaje = mensaje; }
	 
	 public static String getMensaje(){ return SeleccionaPacienteEliminarDiagnosticoServlet.mensaje; }
	 
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public SeleccionaPacienteEliminarDiagnosticoServlet() {
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String selectorPacienteEliminarDiagnostico;
		String consultaHQL;
		List<Paciente> listaDePacientes;
		Paciente pacienteSeleccionadoEliminarDiagnostico;
		try
		{
			if( request.getParameter("selectorPacienteEliminarDiagnostico") != null && 
					!request.getParameter("selectorPacienteEliminarDiagnostico").equals("") 
				)
			{
				selectorPacienteEliminarDiagnostico = request.getParameter("selectorPacienteEliminarDiagnostico");
				consultaHQL = "select p from Paciente as p where 1=1 and p.idPaciente = '" + selectorPacienteEliminarDiagnostico + "'";
				listaDePacientes = PacienteHome.consultaPacientes(consultaHQL);
				if( listaDePacientes == null )
				{
					if( PacienteHome.getMensaje() == null )
					{
						SeleccionaPacienteEliminarDiagnosticoServlet.setMensaje(
								"EL Paciente seleccionado no puede ser nulo ..! Vuelva a intentarlo ..!" );
						request.getSession().setAttribute("mensajeSeleccionaPacienteEliminarDiagnostico" , 
								SeleccionaPacienteEliminarDiagnosticoServlet.getMensaje() );
						response.sendRedirect("do_elimina_diagnostico.jsp");
					}
					else if( PacienteHome.getMensaje() != null && !PacienteHome.getMensaje().equals("") )
					{
						SeleccionaPacienteEliminarDiagnosticoServlet.setMensaje( PacienteHome.getMensaje() );
						request.getSession().setAttribute("mensajeSeleccionaPacienteEliminarDiagnostico" ,
								SeleccionaPacienteEliminarDiagnosticoServlet.getMensaje() );
						response.sendRedirect("do_elimina_diagnostico.jsp");
					}
				}
				else if( listaDePacientes != null )
				{
					if( listaDePacientes.isEmpty() )
					{
						SeleccionaPacienteEliminarDiagnosticoServlet.setMensaje( 
								"EL Paciente que ha seleccionado para modificar un Diagnóstico no está registrado en la Base de Datos ..!" +
								"Vuelva a intentarlo ..!" );
						request.getSession().setAttribute("mensajeSeleccionaPacienteEliminarDiagnostico" ,
								SeleccionaPacienteEliminarDiagnosticoServlet.getMensaje() );
						response.sendRedirect("do_elimina_diagnostico.jsp");
					}
					else if( !listaDePacientes.isEmpty() )
					{
						if( listaDePacientes.size() == 1 )
						{
							pacienteSeleccionadoEliminarDiagnostico = listaDePacientes.get(0); //índice comienza en cero
							if( String.valueOf( pacienteSeleccionadoEliminarDiagnostico.getIdPaciente() ).equals( selectorPacienteEliminarDiagnostico ) )
							{
								request.getSession().setAttribute("pacienteSeleccionadoEliminarDiagnostico", pacienteSeleccionadoEliminarDiagnostico);
								response.sendRedirect("do_elimina_diagnostico.jsp");
							}
						}
						else
						{
							SeleccionaPacienteEliminarDiagnosticoServlet.setMensaje(
									"EL Paciente que ha seleccionado para modificar un Diagnóstico no está registrado en la Base de Datos ..!" +
									"Vuelva a intentarlo ..!" );
							request.getSession().setAttribute("mensajeSeleccionaPacienteEliminarDiagnostico" , 
									SeleccionaPacienteEliminarDiagnosticoServlet.getMensaje() );
							response.sendRedirect("do_elimina_diagnostico.jsp");
						}
					}
				}
			}	
			else
			{
				SeleccionaPacienteEliminarDiagnosticoServlet.setMensaje("Debe seleccionar uno de los Pacientes en el selector ..!");
				request.getSession().setAttribute("mensajeSeleccionaPacienteEliminarDiagnostico", 
						SeleccionaPacienteEliminarDiagnosticoServlet.getMensaje() );
				response.sendRedirect("do_elimina_diagnostico.jsp");
			}
		}
		catch(HibernateException hex)
		{
			SeleccionaPacienteEliminarDiagnosticoServlet.setMensaje(
					"Ha ocurrido una Excepción en SeleccionaPacienteEliminarDiagnosticoServlet.doPost(request, response) : " + hex);
			request.getSession().setAttribute("mensajeSeleccionaPacienteEliminarDiagnostico",
					SeleccionaPacienteEliminarDiagnosticoServlet.getMensaje() );
			response.sendRedirect("do_elimina_diagnostico.jsp");
		}
		catch(Exception ex)
		{
			SeleccionaPacienteEliminarDiagnosticoServlet.setMensaje(
					"Ha ocurrido una Excepción en SeleccionaPacienteEliminarDiagnosticoServlet.doPost(request, response) : " + ex);
			request.getSession().setAttribute("mensajeSeleccionaPacienteEliminarDiagnostico",
					SeleccionaPacienteEliminarDiagnosticoServlet.getMensaje() );
			response.sendRedirect("do_elimina_diagnostico.jsp");
		}
	}   	  	    
}