package dbServlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import clinica.Diagnostico;
import clinica.DiagnosticoHome;

/**
 * Servlet implementation class for Servlet: EliminaDiagnosticoServlet
 *
 */
 public class EliminaDiagnosticoServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
 {
	 private static String mensaje;
	 
	 public static void setMensaje( String mensaje){ EliminaDiagnosticoServlet.mensaje = mensaje; }
	 
	 public static String getMensaje(){ return EliminaDiagnosticoServlet.mensaje; }
	 	 
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public EliminaDiagnosticoServlet() 
	{
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String eleccionEliminarDiagnostico;
		Diagnostico diagnosticoEliminar;
		Boolean isSuccessfullDeleted = Boolean.FALSE; //por defecto
		
		try
		{
			if( request.getParameter("eleccionEliminarDiagnostico") != null && !request.getParameter("eleccionEliminarDiagnostico").equals("") )
			{
				eleccionEliminarDiagnostico = request.getParameter("eleccionEliminarDiagnostico");
				
				request.getSession().setAttribute("eleccionEliminarDiagnostico", eleccionEliminarDiagnostico);
				
				if( eleccionEliminarDiagnostico.equals("SI") )
				{
					diagnosticoEliminar = (Diagnostico)request.getSession().getAttribute("diagnosticoEliminar");
					if( diagnosticoEliminar == null )
					{
						EliminaDiagnosticoServlet.setMensaje(
							"El Diagnóstico a eliminar no puede ser nulo ..! Intente nuevamente ..! ");
						request.getSession().setAttribute("mensaje", EliminaDiagnosticoServlet.getMensaje() );
						response.sendRedirect("do_elimina_diagnostico.jsp");
					}
					else if( diagnosticoEliminar != null )
					{
						isSuccessfullDeleted = DiagnosticoHome.eliminaDiagnostico(diagnosticoEliminar);
						if( isSuccessfullDeleted )
						{
							EliminaDiagnosticoServlet.setMensaje("El Diagnóstico ha sido eliminado satisfactoriamente de la Base de Datos  ..! ");
							request.getSession().setAttribute("mensaje", EliminaDiagnosticoServlet.getMensaje() );
							request.getSession().setAttribute("diagnosticoEliminar", null);
							request.getSession().setAttribute("pacienteSeleccionadoEliminarDiagnostico", null);
							response.sendRedirect("do_elimina_diagnostico.jsp");
						}
						else if( isSuccessfullDeleted.booleanValue() == false )
						{
							EliminaDiagnosticoServlet.setMensaje(
								"El Diagnóstico NO HA SIDO ELIMINADO satisfactoriamente de la Base de Datos  ..! Intente nuevamente ..! ");
							request.getSession().setAttribute("mensaje", EliminaDiagnosticoServlet.getMensaje() );
							response.sendRedirect("do_elimina_diagnostico.jsp");
						}
					}
				}
				else if( eleccionEliminarDiagnostico.equals("NO") )
				{
					EliminaDiagnosticoServlet.setMensaje("Usted ha elegido no eliminar el Diagnóstico ..! ");
					request.getSession().setAttribute("mensaje", EliminaDiagnosticoServlet.getMensaje() );
					response.sendRedirect("do_elimina_diagnostico.jsp");
				}
			}
			else
			{
				EliminaDiagnosticoServlet.setMensaje("Debe elegir por \"SI\" o por \"NO\" ..! ");
				request.getSession().setAttribute("mensaje", EliminaDiagnosticoServlet.getMensaje() );
				response.sendRedirect("do_elimina_diagnostico.jsp");
			}
		}
		catch(HibernateException hex)
		{
			EliminaDiagnosticoServlet.setMensaje("Ha ocurrido una Excepción en EliminaDiagnosticoServlet.doPost( request , response ) : " + hex);
			request.getSession().setAttribute("mensaje", EliminaDiagnosticoServlet.getMensaje() );
			
			request.getSession().setAttribute("idDiagnosticoEliminar", null); //ver
			
			response.sendRedirect("do_elimina_diagnostico.jsp");
		}
		catch(Exception ex)
		{
			EliminaDiagnosticoServlet.setMensaje("Ha ocurrido una Excepción en EliminaDiagnosticoServlet.doPost( request , response ) : " + ex);
			request.getSession().setAttribute("mensaje", EliminaDiagnosticoServlet.getMensaje() );
			
			request.getSession().setAttribute("idDiagnosticoEliminar", null); //ver
			
			response.sendRedirect("do_elimina_diagnostico.jsp");
		}
	}   	  	    
}