package dbServlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import clinica.Paciente;
import clinica.PacienteHome;

/**
 * Servlet implementation class for Servlet: SeleccionaPacienteDiagnosticarServlet
 *
 */
 public class SeleccionaPacienteDiagnosticarServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
 {
	 private static String mensaje;
	 
	 public static void setMensaje(String mensaje){ SeleccionaPacienteDiagnosticarServlet.mensaje = mensaje; }
	 
	 public static String getMensaje(){ return SeleccionaPacienteDiagnosticarServlet.mensaje; }
	 
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public SeleccionaPacienteDiagnosticarServlet() 
	{
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String selectorPacienteDiagnosticar;
		String consultaHQL;
		List<Paciente> listaDePacientes;
		Paciente pacienteSeleccionadoDiagnosticar;
		try
		{
			if( request.getParameter("selectorPacienteDiagnosticar") != null && 
					!request.getParameter("selectorPacienteDiagnosticar").equals("") 
				)
			{
				selectorPacienteDiagnosticar = request.getParameter("selectorPacienteDiagnosticar");
				consultaHQL = "select p from Paciente as p where 1=1 and p.idPaciente = '" + selectorPacienteDiagnosticar + "'";
				listaDePacientes = PacienteHome.consultaPacientes(consultaHQL);
				if( listaDePacientes == null )
				{
					if( PacienteHome.getMensaje() == null )
					{
						SeleccionaPacienteDiagnosticarServlet.setMensaje( "EL Paciente seleccionado no puede ser nulo ..! Vuelva a intentarlo ..!" );
						request.getSession().setAttribute("mensajeSeleccionaPacienteDiagnosticar" , SeleccionaPacienteDiagnosticarServlet.getMensaje() );
						response.sendRedirect("do_alta_diagnostico.jsp");
					}
					else if( PacienteHome.getMensaje() != null && !PacienteHome.getMensaje().equals("") )
					{
						SeleccionaPacienteDiagnosticarServlet.setMensaje( PacienteHome.getMensaje() );
						request.getSession().setAttribute("mensajeSeleccionaPacienteDiagnosticar" , SeleccionaPacienteDiagnosticarServlet.getMensaje() );
						response.sendRedirect("do_alta_diagnostico.jsp");
					}
				}
				else if( listaDePacientes != null )
				{
					if( listaDePacientes.isEmpty() )
					{
						SeleccionaPacienteDiagnosticarServlet.setMensaje( 
								"EL Paciente que ha seleccionado para ingresar un Diagnóstico no está registrado en la Base de Datos ..!" +
								"Vuelva a intentarlo ..!" );
						request.getSession().setAttribute("mensajeSeleccionaPacienteDiagnosticar" ,
								SeleccionaPacienteDiagnosticarServlet.getMensaje() );
						response.sendRedirect("do_alta_diagnostico.jsp");
					}
					else if( !listaDePacientes.isEmpty() )
					{
						if( listaDePacientes.size() == 1 )
						{
							pacienteSeleccionadoDiagnosticar = listaDePacientes.get(0); //índice comienza en cero
							if( String.valueOf( pacienteSeleccionadoDiagnosticar.getIdPaciente() ).equals( selectorPacienteDiagnosticar ) )
							{
								request.getSession().setAttribute("pacienteSeleccionadoDiagnosticar", pacienteSeleccionadoDiagnosticar);
								response.sendRedirect("do_alta_diagnostico.jsp");
							}
						}
						else
						{
							SeleccionaPacienteDiagnosticarServlet.setMensaje(
									"EL Paciente que ha seleccionado para ingresar un Diagnóstico no está registrado en la Base de Datos ..!" +
									"Vuelva a intentarlo ..!" );
							request.getSession().setAttribute("mensajeSeleccionaPacienteDiagnosticar" , 
									SeleccionaPacienteDiagnosticarServlet.getMensaje() );
							response.sendRedirect("do_alta_diagnostico.jsp");
						}
					}
				}
			}	
			else
			{
				SeleccionaPacienteDiagnosticarServlet.setMensaje("Debe seleccionar uno de los Pacientes en el selector ..!");
				request.getSession().setAttribute("mensajeSeleccionaPacienteDiagnosticar", SeleccionaPacienteDiagnosticarServlet.getMensaje() );
				response.sendRedirect("do_alta_diagnostico.jsp");
			}
		}
		catch(HibernateException hex)
		{
			SeleccionaPacienteDiagnosticarServlet.setMensaje(
					"Ha ocurrido una Excepción en SeleccionaPacienteDiagnosticarServlet.doPost(request, response) : " + hex);
			request.getSession().setAttribute("mensajeSeleccionaPacienteDiagnosticar", SeleccionaPacienteDiagnosticarServlet.getMensaje() );
			response.sendRedirect("do_alta_diagnostico.jsp");
		}
		catch(Exception ex)
		{
			SeleccionaPacienteDiagnosticarServlet.setMensaje(
					"Ha ocurrido una Excepción en SeleccionaPacienteDiagnosticarServlet.doPost(request, response) : " + ex);
			request.getSession().setAttribute("mensajeSeleccionaPacienteDiagnosticar", SeleccionaPacienteDiagnosticarServlet.getMensaje() );
			response.sendRedirect("do_alta_diagnostico.jsp");
		}
	}   	  	    
}