package dbServlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import clinica.Usuario;
import clinica.UsuarioHome;

/**
 * Servlet implementation class for Servlet: EliminaUsuarioServlet
 *
 */
 public class EliminaUsuarioServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
 {
	 private static String mensaje;
	 
	 public static void setMensaje(String mensaje){ EliminaUsuarioServlet.mensaje = mensaje; }
	 
	 public static String getMensaje(){ return EliminaUsuarioServlet.mensaje; }
	 
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public EliminaUsuarioServlet() {
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String eleccionEliminaUsuario;
		Usuario usuario;
		Boolean isSuccesfullDeleted = Boolean.FALSE; //por defecto
		try
		{
			if( request.getParameter("eleccionEliminaUsuario") != null && !request.getParameter("eleccionEliminaUsuario").equals("") )
			{
				eleccionEliminaUsuario = request.getParameter("eleccionEliminaUsuario");
				if( eleccionEliminaUsuario != null && eleccionEliminaUsuario.equals("SI") )
				{
					//Obtiene el usuario del HttpSession
					usuario = (Usuario)request.getSession().getAttribute("usuario");
					if( usuario != null )
					{
						isSuccesfullDeleted = UsuarioHome.eliminaUsuario(usuario);
						
						if( isSuccesfullDeleted.booleanValue() == true )
						{
							/* Primero debe cerrar el Session de Hibernate */ 	
							if( LoginServlet.getHibernateSession() != null )
							{
								//try
								//{
									LoginServlet.closeHibernateSession();
								//}
								//catch(HibernateException hex)
								//{
								//	LogoutServlet.setMensaje(
								//			"Ha ocurrido una Excepción en LogoutServlet.doPost(request, response) al ejecutar LoginServlet.closeHibernateSession() " + hex 
								//		);
								//	request.getSession().setAttribute("mensaje", LogoutServlet.getMensaje() );
								//	response.sendRedirect("logout.jsp");
								//}
							}
							//Segundo debe cerrar el SessionFactory de Hibernate
							if( LoginServlet.getHibernateSessionFactory() != null )
							{
								//try
								//{
									LoginServlet.closeHibernateSessionFactory();
								//}
								//catch(HibernateException hex)
								//{
									//System.err.println("Ha ocurrido una Excepción al ejecutar HibernateUtil.closeSessionFactory() desde \"logout.jsp\" :" + hex);
								//	LogoutServlet.setMensaje(
								//			"Ha ocurrido una Excepción en LogoutServlet.doPost(request, response) al ejecutar LoginServlet.closeHibernateSessionFactory() "
								//			+ hex
								//		);
								//	request.getSession().setAttribute("mensaje", LogoutServlet.getMensaje() );
								//	response.sendRedirect("logout.jsp");
								//}
							}
							/*  Por último invalida la session de HttpSession y redirecciona.   */
							request.getSession().setAttribute("mensajeBienvenida", null);
							request.getSession().setAttribute("usuario", null);
							request.getSession().invalidate();
						  	response.sendRedirect("index.jsp");
							
						}
						if( isSuccesfullDeleted.booleanValue() == false )
						{
							if( UsuarioHome.getMensaje() != null && !UsuarioHome.getMensaje().equals("") )
							{
								EliminaUsuarioServlet.setMensaje( UsuarioHome.getMensaje() );
								request.getSession().setAttribute("mensaje", EliminaUsuarioServlet.getMensaje() );
								response.sendRedirect("do_elimina_usuario.jsp");
							}
							else
							{
								EliminaUsuarioServlet.setMensaje("Ha ocurrido un error en EliminaUsuarioServlet.doPost(request, response) :" +
										" El Usuario no puede eliminarse de la Base de Datos ..!");
								request.getSession().setAttribute("mensaje", EliminaUsuarioServlet.getMensaje() );
								response.sendRedirect("do_elimina_usuario.jsp");
							}
						}
					}
					if( usuario == null)
					{
						EliminaUsuarioServlet.setMensaje("Ha ocurrido un error en EliminaUsuarioServlet.doPost(request, response) :" +
								" El Usuario obtenido de la HttpSession no puede ser nulo ..! ");
						request.getSession().setAttribute("mensaje", EliminaUsuarioServlet.getMensaje() );
						response.sendRedirect("do_elimina_usuario.jsp");
					}
				}
				if( eleccionEliminaUsuario != null && eleccionEliminaUsuario.equals("NO") )
				{
					EliminaUsuarioServlet.setMensaje(
						"Usted ha elegido NO eliminar su Perfil como Usuario del Portal, puede continuar usando sus recursos disponibles " );
					request.getSession().setAttribute("mensaje", EliminaUsuarioServlet.getMensaje() );
					response.sendRedirect("do_elimina_usuario.jsp");
				}
				if( eleccionEliminaUsuario != null && eleccionEliminaUsuario.equals("") )
				{
					EliminaUsuarioServlet.setMensaje("Debe elegir por \"SI\" o por \"NO\" ..!");
					request.getSession().setAttribute("mensaje", EliminaUsuarioServlet.getMensaje() );
					response.sendRedirect("do_elimina_usuario.jsp");
				}
				if( eleccionEliminaUsuario == null )
				{
					EliminaUsuarioServlet.setMensaje("Debe elegir por \"SI\" o por \"NO\" ..!");
					request.getSession().setAttribute("mensaje", EliminaUsuarioServlet.getMensaje() );
					response.sendRedirect("do_elimina_usuario.jsp");
				}
 			}
			else
			{
				EliminaUsuarioServlet.setMensaje("Debe elegir por \"SI\" o por \"NO\" ..!");
				request.getSession().setAttribute("mensaje", EliminaUsuarioServlet.getMensaje() );
				response.sendRedirect("do_elimina_usuario.jsp");
			}
		}
		catch(HibernateException hex )
		{
			EliminaUsuarioServlet.setMensaje("Ha ocurrido una Excepción en EliminaUsuarioServlet.doPost(request, response) :" + hex);
			request.getSession().setAttribute("mensaje", EliminaUsuarioServlet.getMensaje() );
			response.sendRedirect("do_elimina_usuario.jsp");
		}
		catch(Exception ex )
		{
			EliminaUsuarioServlet.setMensaje("Ha ocurrido una Excepción en EliminaUsuarioServlet.doPost(request, response) :" + ex);
			request.getSession().setAttribute("mensaje", EliminaUsuarioServlet.getMensaje() );
			response.sendRedirect("do_elimina_usuario.jsp");
		}

	}   	  	    
}