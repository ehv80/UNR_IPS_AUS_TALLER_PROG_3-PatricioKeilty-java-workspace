package dbServlets;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import utility.FechaUtil;

import clinica.Diagnostico;
import clinica.DiagnosticoHome;
import clinica.Paciente;
import clinica.PacienteHome;

/**
 * Servlet implementation class for Servlet: AltaDiagnosticoServlet
 *
 */
 public class AltaDiagnosticoServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
 {
	 private static String mensaje;
	 
	 public static void setMensaje(String mensaje){ AltaDiagnosticoServlet.mensaje = mensaje; }
	 
	 public static String getMensaje(){ return AltaDiagnosticoServlet.mensaje; }
	 
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public AltaDiagnosticoServlet() 
	{
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		List<Paciente> listaDePacientes;
		Paciente pacienteDiagnosticar;
		String consultaPacienteHQL;
		String descripcionDiagnosticoAlta;
		Date fechaDiagnostico;
			String cadenaFechaDiagnostico;
			String anioDiagnosticoAlta;
			String mesDiagnosticoAlta;
			String diaDiagnosticoAlta;
		String idPacienteDiagnosticar;
		Diagnostico diagnostico;
		Boolean isSuccesfullSaved;
		try
		{
			if( request.getParameter("descripcionDiagnosticoAlta") != null && !request.getParameter("descripcionDiagnosticoAlta").equals("") &&
					request.getParameter("anioDiagnosticoAlta") != null && !request.getParameter("anioDiagnosticoAlta").equals("") &&
					request.getParameter("mesDiagnosticoAlta") != null && !request.getParameter("mesDiagnosticoAlta").equals("") &&
					request.getParameter("diaDiagnosticoAlta") != null && !request.getParameter("diaDiagnosticoAlta").equals("") &&
					request.getParameter("idPacienteDiagnosticar") != null && !request.getParameter("idPacienteDiagnosticar").equals("")
				)
			{
				/*
				*pacienteDiagnosticar = (Paciente)request.getSession().getAttribute("pacienteSeleccionadoDiagnosticar");
				*if( pacienteDiagnosticar == null )
				*{
				*	AltaDiagnosticoServlet.setMensaje("El Paciente seleccionado para registrar un Diagnóstico no puede ser nulo ..! Intente nuevamente ..!");
				*	request.getSession().setAttribute("mensaje", AltaDiagnosticoServlet.getMensaje() );
				*	response.sendRedirect("do_alta_diagnostico.jsp");
				*}
				*/
				
				descripcionDiagnosticoAlta = request.getParameter("descripcionDiagnosticoAlta");
				anioDiagnosticoAlta = request.getParameter("anioDiagnosticoAlta");
				mesDiagnosticoAlta = request.getParameter("mesDiagnosticoAlta");
				diaDiagnosticoAlta = request.getParameter("diaDiagnosticoAlta");
				idPacienteDiagnosticar = request.getParameter("idPacienteDiagnosticar");
				
				request.getSession().setAttribute("descripcionDiagnosticoAlta", descripcionDiagnosticoAlta);
				request.getSession().setAttribute("anioDiagnosticoAlta", anioDiagnosticoAlta);
				request.getSession().setAttribute("mesDiagnosticoAlta", mesDiagnosticoAlta);
				request.getSession().setAttribute("diaDiagnosticoAlta", diaDiagnosticoAlta);
				request.getSession().setAttribute("idPacienteDiagnosticar", idPacienteDiagnosticar);
				
				//Para mayor consistencia de los datos, extrae el Paciente desde una Consulta HQL
				consultaPacienteHQL = "select p from Paciente as p where 1=1 and p.idPaciente = '" + idPacienteDiagnosticar + "'";
				listaDePacientes = PacienteHome.consultaPacientes(consultaPacienteHQL);
				if( listaDePacientes == null )
				{
					if( PacienteHome.getMensaje() != null && !PacienteHome.getMensaje().equals("") )
					{
						AltaDiagnosticoServlet.setMensaje( PacienteHome.getMensaje() );
						request.getSession().setAttribute("mensaje", AltaDiagnosticoServlet.getMensaje() );
						response.sendRedirect("do_alta_diagnostico.jsp");
					}
					else
					{
						AltaDiagnosticoServlet.setMensaje("La lista de Pacientes que arroja la consulta HQL no puede ser nula ..!");
						request.getSession().setAttribute("mensaje", AltaDiagnosticoServlet.getMensaje() );
						response.sendRedirect("do_alta_diagnostico.jsp");
					}
				}
				else if( listaDePacientes != null )
				{
					if( listaDePacientes.isEmpty() )
					{
						AltaDiagnosticoServlet.setMensaje(
								"El Paciente al que desea registrar un Diagnóstico no está almacenado en la Base de Datos ..!");
						request.getSession().setAttribute("mensaje", AltaDiagnosticoServlet.getMensaje() );
						response.sendRedirect("do_alta_diagnostico.jsp");
					}
					else if( !listaDePacientes.isEmpty() )
					{
						if( listaDePacientes.size() == 1 )
						{
							if( String.valueOf( listaDePacientes.get(0).getIdPaciente() ).equals( idPacienteDiagnosticar ) )
							{
								//El Paciente a Diagnósticar está registrado en la Base de Datos
								pacienteDiagnosticar = listaDePacientes.get(0);//índice comienza en cero
								//1º Verifica: si el Paciente está muerto => no puede registrar Diagnóstico
								if( pacienteDiagnosticar.isEstaVivo() )
								{
									//2º Valida la Fecha del Diagnóstico
									cadenaFechaDiagnostico = anioDiagnosticoAlta + "-" + mesDiagnosticoAlta + "-" + diaDiagnosticoAlta;
									fechaDiagnostico = FechaUtil.validaFecha(cadenaFechaDiagnostico);
									if( fechaDiagnostico == null )
									{
										if( FechaUtil.getMensaje() != null && !FechaUtil.getMensaje().equals("") )
										{
											AltaDiagnosticoServlet.setMensaje( FechaUtil.getMensaje() );
											request.getSession().setAttribute("mensaje", AltaDiagnosticoServlet.getMensaje() );
											response.sendRedirect("do_alta_diagnostico.jsp");
										}
										else
										{
											AltaDiagnosticoServlet.setMensaje("Debe seleccionar una Fecha que sea válida ..!");
											request.getSession().setAttribute("mensaje", AltaDiagnosticoServlet.getMensaje() );
											response.sendRedirect("do_alta_diagnostico.jsp");
										}
									}
									else if( fechaDiagnostico != null )
									{
										//Tiene Paciente que no es nulo ni está muerto y Fecha de Diagnóstico es válida => puede registrar Diagnóstico
									
										diagnostico = new Diagnostico( pacienteDiagnosticar , descripcionDiagnosticoAlta, fechaDiagnostico);
										
										if( diagnostico == null )
										{
											AltaDiagnosticoServlet.setMensaje(
													"El Diagnóstico a registrar no puede ser nulo ..! Intente nuevamente ..!");
											request.getSession().setAttribute("mensaje", AltaDiagnosticoServlet.getMensaje() );
											response.sendRedirect("do_alta_diagnostico.jsp");
										}
										else if( diagnostico != null )
										{
											//almacena Diagnóstico
											isSuccesfullSaved = DiagnosticoHome.almacenaDiagnostico(diagnostico);
											
											if( isSuccesfullSaved.booleanValue() == false )
											{
												if( DiagnosticoHome.getMensaje() != null && !DiagnosticoHome.getMensaje().equals("") )
												{
													AltaDiagnosticoServlet.setMensaje( DiagnosticoHome.getMensaje() );
													request.getSession().setAttribute("mensaje", AltaDiagnosticoServlet.getMensaje() );
													response.sendRedirect("do_alta_diagnostico.jsp");
												}
												else
												{
													AltaDiagnosticoServlet.setMensaje("El Diagnóstico NO HA SIDO ALMACENADO en la Base de Datos ..! Intente nuevamente ..!");
													request.getSession().setAttribute("mensaje", AltaDiagnosticoServlet.getMensaje() );
													response.sendRedirect("do_alta_diagnostico.jsp");
												}
											}
											else if( isSuccesfullSaved.booleanValue() == true )
											{
												request.getSession().setAttribute("pacienteSeleccionadoDiagnosticar", null);
												
												AltaDiagnosticoServlet.setMensaje("El Diagnóstico ha sido almacenado satisfactoriamente en la Base de Datos ..! ");
												request.getSession().setAttribute("mensaje", AltaDiagnosticoServlet.getMensaje() );
												response.sendRedirect("do_alta_diagnostico.jsp");
											}
										}
										
									}
								}
								else
								{
									AltaDiagnosticoServlet.setMensaje("No puede registrar un Diagnóstico a un Paciente que ha fallecido ..!");
									request.getSession().setAttribute("mensaje", AltaDiagnosticoServlet.getMensaje() );
									response.sendRedirect("do_alta_diagnostico.jsp");
								}
							}	
						}
						else
						{
							AltaDiagnosticoServlet.setMensaje(
									"Error en la consulta HQL ..! NO puede registrar el Diagnóstico ..! Intente nuevamente ..!" );
							request.getSession().setAttribute("mensaje", AltaDiagnosticoServlet.getMensaje() );
							response.sendRedirect("do_alta_diagnostico.jsp");
						}
					}
				}
			}
			else
			{
				AltaDiagnosticoServlet.setMensaje("Debe completar todos los campos del formulario ..!");
				request.getSession().setAttribute("mensaje", AltaDiagnosticoServlet.getMensaje() );
				response.sendRedirect("do_alta_diagnostico.jsp");
			}
		}
		catch(HibernateException hex)
		{
			AltaDiagnosticoServlet.setMensaje("Ha ocurrido una Excepción en AltaDiagnosticoServlet.doPost(request, reponse) " +
					"Detalles:  " + hex);
			request.getSession().setAttribute("mensaje", AltaDiagnosticoServlet.getMensaje() );
			response.sendRedirect("do_alta_diagnostico.jsp");
		}
		catch(Exception ex)
		{
			AltaDiagnosticoServlet.setMensaje("Ha ocurrido una Excepción en AltaDiagnosticoServlet.doPost(request, reponse) " +
					"Detalles:  " + ex);
			request.getSession().setAttribute("mensaje", AltaDiagnosticoServlet.getMensaje() );
			response.sendRedirect("do_alta_diagnostico.jsp");
		}
	}   	  	    
}