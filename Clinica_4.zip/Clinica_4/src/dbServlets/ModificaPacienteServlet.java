package dbServlets;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import utility.FechaUtil;

import clinica.Paciente;
import clinica.PacienteHome;

/**
 * Servlet implementation class for Servlet: ModificaPacienteServlet
 *
 */
 public class ModificaPacienteServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
 {
	 private static String mensaje;
	 
	 public static void setMensaje( String mensaje ){ ModificaPacienteServlet.mensaje = mensaje; }
	 
	 public static String getMensaje() { return ModificaPacienteServlet.mensaje; }
	 
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public ModificaPacienteServlet() 
	{
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String consultaHQL;
		List<Paciente> listaDePacientes;
		Paciente pacienteModificar;
		Boolean isTipoYNroDeDocumentoRepeated = Boolean.FALSE; //por defecto
		Boolean isSuccesfullUpdated = Boolean.FALSE; //por defecto
		
		//int idPacienteModificar;
		String nombreModificar;
		String apellidoModificar;
		Date fechaNacModificar;
			String cadenaFechaNacModificar;
			String anioNacimientoPacienteModificar;
			String mesNacimientoPacienteModificar;
			String diaNacimientoPacienteModificar;
		String tpoDocModificar;
		int nroDocModificar;
		String obraSocialModificar;
		String sexoModificar;
		boolean estaVivoModificar;

		try
		{
			if( request.getParameter("nombrePacienteModificar") != null && !request.getParameter("nombrePacienteModificar").equals("") &&
					request.getParameter("apellidoPacienteModificar") != null && !request.getParameter("apellidoPacienteModificar").equals("") &&
					request.getParameter("anioNacimientoPacienteModificar") != null && !request.getParameter("anioNacimientoPacienteModificar").equals("") &&
					request.getParameter("mesNacimientoPacienteModificar") != null && !request.getParameter("mesNacimientoPacienteModificar").equals("") &&
					request.getParameter("diaNacimientoPacienteModificar") != null && !request.getParameter("diaNacimientoPacienteModificar").equals("") &&
					request.getParameter("tipoDeDocumentoPacienteModificar") != null && !request.getParameter("tipoDeDocumentoPacienteModificar").equals("") &&
					request.getParameter("numeroDeDocumentoPacienteModificar") != null && !request.getParameter("numeroDeDocumentoPacienteModificar").equals("") &&
					request.getParameter("obraSocialPacienteModificar") != null && !request.getParameter("obraSocialPacienteModificar").equals("") &&
					request.getParameter("sexoPacienteModificar") != null && !request.getParameter("sexoPacienteModificar").equals("") &&
					request.getParameter("estaVivoPacienteModificar") != null && !request.getParameter("estaVivoPacienteModificar").equals("")
					)
			{
				nombreModificar = request.getParameter("nombrePacienteModificar");
				apellidoModificar = request.getParameter("apellidoPacienteModificar");
				anioNacimientoPacienteModificar = request.getParameter("anioNacimientoPacienteModificar");
				mesNacimientoPacienteModificar = request.getParameter("mesNacimientoPacienteModificar");
				diaNacimientoPacienteModificar = request.getParameter("diaNacimientoPacienteModificar");
				tpoDocModificar = request.getParameter("tipoDeDocumentoPacienteModificar");
					nroDocModificar = Integer.parseInt( request.getParameter("numeroDeDocumentoPacienteModificar") );
				obraSocialModificar = request.getParameter("obraSocialPacienteModificar");
				sexoModificar = request.getParameter("sexoPacienteModificar");
					estaVivoModificar = Boolean.parseBoolean( request.getParameter("estaVivoPacienteModificar") );
				
				request.getSession().setAttribute("nombrePacienteModificar", nombreModificar);
				request.getSession().setAttribute("apellidoPacienteModificar", apellidoModificar);
				request.getSession().setAttribute("anioNacimientoPacienteModificar", anioNacimientoPacienteModificar);
				request.getSession().setAttribute("mesNacimientoPacienteModificar", mesNacimientoPacienteModificar);
				request.getSession().setAttribute("diaNacimientoPacienteModificar", diaNacimientoPacienteModificar);
				request.getSession().setAttribute("tipoDeDocumentoPacienteModificar", tpoDocModificar);
					request.getSession().setAttribute("numeroDeDocumentoPacienteModificar", String.valueOf( nroDocModificar ) );
				request.getSession().setAttribute("obraSocialPacienteModificar", obraSocialModificar);
				request.getSession().setAttribute("sexoPacienteModificar", sexoModificar);
					request.getSession().setAttribute("estaVivoPacienteModificar", String.valueOf( estaVivoModificar ) );

				
				//Obtiene el paciente a Modificar del HttpSession 
				pacienteModificar = (Paciente)request.getSession().getAttribute("pacienteModificar");
				if( pacienteModificar == null )
				{
					ModificaPacienteServlet.setMensaje("El Paciente seleccionado no puede ser nulo ..! Vuelva a intentarlo ..!");
					request.getSession().setAttribute("mensaje", ModificaPacienteServlet.getMensaje() );
					response.sendRedirect("do_modifica_paciente.jsp");
				}
					
				//No pueden haber Pacientes con igual "Id de Paciente" => controlado por la Base de Datos e Hibernate "increment"
				//"     "     "       "      "    "   "Tipo de Documento" y "Número de Documento" => hay que Controlar
				//	Pueden haber Pacientes que tengan mismo "Mombre" , "Apellido", "Fecha de Nacimiento", "Obra Social" , "Sexo" , "Estado de Vida"
				
				//Verifica si los nuevos Tipo y Número de Documento están siendo usados por otro Paciente => no puede actualizar Paciente
				consultaHQL = "select p from Paciente as p where 1=1 and p.tpoDoc='" + tpoDocModificar + "' and p.nroDoc='" + nroDocModificar + "'";
				
				listaDePacientes = PacienteHome.consultaPacientes(consultaHQL);
				if( listaDePacientes == null )
				{
					if( PacienteHome.getMensaje() != null && !PacienteHome.getMensaje().equals("") )
					{
						ModificaPacienteServlet.setMensaje( PacienteHome.getMensaje() );
						request.getSession().setAttribute("mensaje", ModificaPacienteServlet.getMensaje() );
						response.sendRedirect("do_modifica_paciente.jsp");
					}
					else
					{
						ModificaPacienteServlet.setMensaje("La lista de Pacientes no puede ser nula ..! Vuelva a Intentarlo ..!");
						request.getSession().setAttribute("mensaje", ModificaPacienteServlet.getMensaje() );
						response.sendRedirect("do_modifica_paciente.jsp");
					}
				}
				else if( listaDePacientes != null )
				{
					if( !listaDePacientes.isEmpty() )
					{
						if( listaDePacientes.size() > 1 )
						{
							isTipoYNroDeDocumentoRepeated = Boolean.TRUE;
							//Hay más de un Usuario con ese Tipo y Nro de Documento => no puede actualizar							
						}
						else if( listaDePacientes.size() == 1 )
						{
							//Debe verificar que el Paciente sea otro (otro Id de Paciente), pues si es el mismo => puede actualizar
							Paciente pacienteTemp = (Paciente)listaDePacientes.get(0); //índice comienza en cero
							if( pacienteModificar.getIdPaciente() == pacienteTemp.getIdPaciente() )
							{
								//Si se trata del mismo Paciente si lo puede actualizar
								isTipoYNroDeDocumentoRepeated = Boolean.FALSE;
							}
							else if( pacienteModificar.getIdPaciente() != pacienteTemp.getIdPaciente() )
							{
								//Tipo y Nro de Documento de otro Usuario
								isTipoYNroDeDocumentoRepeated = Boolean.TRUE;
							}
						}
					}
					else if(  listaDePacientes.isEmpty() )
					{
						//No hay otro Paciente con ese Tipo y Nro de Documetos => puede actualizar el Paciente con los nuevos Datos
						isTipoYNroDeDocumentoRepeated = Boolean.FALSE;
					}
				}
				
				if( isTipoYNroDeDocumentoRepeated.booleanValue() == true )
				{
					ModificaPacienteServlet.setMensaje("El Paciente seleccionado no se ha podido actualizar en la Base de Datos " +
							" porque hay otro Paciente registrado que tiene el mismo Tipo y Número de Documento ..!");
					request.getSession().setAttribute("mensaje", ModificaPacienteServlet.getMensaje() );
					response.sendRedirect("do_modifica_paciente.jsp");
				}
				else if( isTipoYNroDeDocumentoRepeated.booleanValue() == false )
				{
					//Debe validar la fecha
					cadenaFechaNacModificar = anioNacimientoPacienteModificar + "-" + mesNacimientoPacienteModificar + "-" + diaNacimientoPacienteModificar;
					
					fechaNacModificar = FechaUtil.validaFecha(cadenaFechaNacModificar);
					
					if( fechaNacModificar == null )
					{
						if( FechaUtil.getMensaje() != null && !FechaUtil.getMensaje().equals("") )
						{
							ModificaPacienteServlet.setMensaje( FechaUtil.getMensaje() );
							request.getSession().setAttribute("mensaje", ModificaPacienteServlet.getMensaje() );
							response.sendRedirect("do_modifica_paciente.jsp");
						}
						else
						{
							ModificaPacienteServlet.setMensaje(" Debe seleccionar una Fecha que sea válida ..!");
							request.getSession().setAttribute("mensaje", ModificaPacienteServlet.getMensaje() );
							response.sendRedirect("do_modifica_paciente.jsp");

						}
					}
					else if( fechaNacModificar != null )
					{
						//La fecha es correcta => puede modificar el Paciente
						pacienteModificar.setNombre(nombreModificar);
						pacienteModificar.setApellido(apellidoModificar);
						pacienteModificar.setFechaNac(fechaNacModificar);
						pacienteModificar.setTpoDoc(tpoDocModificar);
						pacienteModificar.setNroDoc(nroDocModificar);
						pacienteModificar.setObraSocial(obraSocialModificar);
						pacienteModificar.setSexo(sexoModificar);
						pacienteModificar.setEstaVivo(estaVivoModificar);
						
						//Actualiza el Paciente en la Base de Datos
						isSuccesfullUpdated = PacienteHome.actualizaPaciente(pacienteModificar);
						if( isSuccesfullUpdated.booleanValue() == true )
						{
							ModificaPacienteServlet.setMensaje("El Paciente seleccionado ha sido actualizado satisfactoriamente en la Base de Datos ..!");
							request.getSession().setAttribute("mensaje", ModificaPacienteServlet.getMensaje() );
							response.sendRedirect("do_modifica_paciente.jsp");							
						}
						else if( isSuccesfullUpdated.booleanValue() == false )
						{
							ModificaPacienteServlet.setMensaje("El Paciente seleccionado no se ha podido actualizar en la Base de Datos ..!");
							request.getSession().setAttribute("mensaje", ModificaPacienteServlet.getMensaje() );
							response.sendRedirect("do_modifica_paciente.jsp");							
						}
					}
				}
			}
			else
			{
				ModificaPacienteServlet.setMensaje("Debe completar todos los campos del formulario ..!");
				request.getSession().setAttribute("mensaje", ModificaPacienteServlet.getMensaje() );
				response.sendRedirect("do_modifica_paciente.jsp");
			}
			
		}
		catch(HibernateException hex)
		{
			ModificaPacienteServlet.setMensaje("Ha ocurrido una Excepción en ModificaPacienteServlet.doPost(request, response) : " + hex);
			request.getSession().setAttribute("mensaje", ModificaPacienteServlet.getMensaje() );
			response.sendRedirect("do_modifica_paciente.jsp");
		}
		catch(Exception ex)
		{
			ModificaPacienteServlet.setMensaje("Ha ocurrido una Excepción en ModificaPacienteServlet.doPost(request, response) : " + ex);
			request.getSession().setAttribute("mensaje", ModificaPacienteServlet.getMensaje() );
			response.sendRedirect("do_modifica_paciente.jsp");
		}
	}   	  	    
}