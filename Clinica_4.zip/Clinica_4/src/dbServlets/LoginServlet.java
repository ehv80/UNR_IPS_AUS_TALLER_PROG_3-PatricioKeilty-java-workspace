package dbServlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import clinica.Usuario;
import clinica.UsuarioHome;


/**
 * Servlet implementation class for Servlet: LoginServlet
 *
 */
 public class LoginServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
 {
	 private static SessionFactory hibernateSessionFactory;
	 private static Session hibernateSession;
	 private static String mensaje;
	 private static int contadorIntentosDeAcceso = 0;
	 
	 public static void setMensaje(String mensaje) { LoginServlet.mensaje = mensaje; }
	 
	 public static String getMensaje() { return LoginServlet.mensaje;  }
	 
	 /**	Inicializa el único SessionFactory para toda la aplicación.
	 * 	@param void
	 * 	@return void
	 */
	public static void createHibernateSessionFactory()
	{
		try
		{
			hibernateSessionFactory = new Configuration().configure().buildSessionFactory();
		}
		catch(HibernateException ex)
		{
			setMensaje("En LoginServlet.createHibernateSessionFactory() ha ocurrido una Excepción al inicializar el SessionFactory: " + ex);
		}
	}
	
	/**
	 * Finaliza el único SessionFactory para toda la aplicación.
	 * @param void
	 * @return void"iteradorPacientes"
	 */
	public static void closeHibernateSessionFactory()
	{
		try
		{
			hibernateSessionFactory.close();
			hibernateSessionFactory = null;
		}
		catch(HibernateException ex)
		{
			setMensaje("En LoginServlet.closeHibernateSessionFactory() Ha ocurrido una Excepción al cerrar el SessionFactory: " + ex);
		}
	}
	 
	/**
	 * @param void
	 * @return SessionFactory
	 */
	public static SessionFactory getHibernateSessionFactory()
	{
		return hibernateSessionFactory;
	}
	
	/**
	 * Inicializa estáticamente la Session.
	 * @param void
	 * @return void
	 */
	public static void createHibernateSession()
	{
		try
		{
			if(hibernateSessionFactory != null )
			{
				hibernateSession = hibernateSessionFactory.openSession();
			}
		}
		catch(HibernateException ex)
		{
			setMensaje("En LoginServlet.createHibernateSession() Ha ocurrido una Excepción al inicializar estáticamente la Session: " + ex);
		}
	}
	
	/**
	 * Cierra estáticamente la Session.
	 * @param void
	 * @return void
	 */
	public static void closeHibernateSession()
	{
		try
		{
			hibernateSession.close();
			hibernateSession = null;
		}
		catch(HibernateException ex)
		{
			setMensaje("En LoginServlet.closeHibernateSession() Ha ocurrido una Excepción al cerrar estáticamente la Session: " + ex);
		}
	}
	
	/**
	 * Retorna la Session.
	 * @return Session.
	 */
	public static Session getHibernateSession()
	{
		return hibernateSession;
	}
	
	/**
	 * Conecta mediante createSessionFactory y createSession.
	 */
	public static void conectarHibernate()
	{
		createHibernateSessionFactory();
		createHibernateSession();
	}
	
	/**
	 * Desconecta mediante  closeSession y closeSessionFactory.
	 */
	public static void desconectarHibernate()
	{
		closeHibernateSession();
		closeHibernateSessionFactory();
	}
	
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String username;
		String password;
		String consultaHQL;
		List<Usuario> listaDeUsuarios;
		Usuario usuario;
		Boolean isUsernameError = Boolean.FALSE; //por defecto
		Boolean isPasswordError = Boolean.FALSE; // "     "
		String mensajeBienvenida;
		if( getHibernateSessionFactory() == null )
		{
			try
			{
				createHibernateSessionFactory();
			}
			catch( HibernateException hex)
			{
				LoginServlet.setMensaje("Ha ocurrido una Excepción en LoginServlet.doPost(request, response) al ejecutar createHibernateSessionFactory() " + hex);
				request.getSession().setAttribute("mensaje", LoginServlet.getMensaje() );
				response.sendRedirect("login.jsp");
			}
		}
		if( getHibernateSession() == null )
		{
			try
			{
				createHibernateSession();
			}
			catch( HibernateException hex)
			{
				LoginServlet.setMensaje("Ha ocurrido una Excepción en LoginServlet.doPost(request, response) al ejecutar createHibernateSession() " + hex);
				request.getSession().setAttribute("mesaje", mensaje);
				response.sendRedirect("login.jsp");
			}
		}
		try
		{	
			if( !request.getParameter("username").equals("") &&
				!request.getParameter("password").equals("") 
				)
			{
				//obtiene username y password del form mediante el request
				username = request.getParameter("username");
				password = request.getParameter("password");
				
				request.getSession().setAttribute("username", username);
				request.getSession().setAttribute("password", password);
				//Primero consulta por separado para saber cuál es el campo que falla
				if( username != null && !username.equals("") )
				{
					consultaHQL = "select u from Usuario as u where 1=1 and u.nombreAcceso = '" + username + "'";
					listaDeUsuarios = UsuarioHome.consultaUsuarios(consultaHQL);
					if( listaDeUsuarios == null )
					{
						if( UsuarioHome.getMensaje() != null && !UsuarioHome.getMensaje().equals("") )
						{
							LoginServlet.setMensaje( UsuarioHome.getMensaje() );
							request.getSession().setAttribute("mensaje", LoginServlet.getMensaje() );
							response.sendRedirect("login.jsp");
						}
					}
					if( listaDeUsuarios != null && listaDeUsuarios.isEmpty() )
					{
						isUsernameError = Boolean.TRUE;
					}
					else
					{
						isUsernameError = Boolean.FALSE;
					}
					request.getSession().setAttribute("isUsernameError", isUsernameError);
				}
				if( password != null && !password.equals("") )
				{
					consultaHQL = "select u from Usuario as u where 1=1 and u.claveAcceso = '" + password + "'";
					listaDeUsuarios = UsuarioHome.consultaUsuarios(consultaHQL);
					if( listaDeUsuarios == null )
					{
						if( UsuarioHome.getMensaje() != null && !UsuarioHome.getMensaje().equals("") )
						{
							LoginServlet.setMensaje( UsuarioHome.getMensaje() );
							request.getSession().setAttribute("mensaje", LoginServlet.getMensaje() );
							response.sendRedirect("login.jsp");
						}
					}
					if( listaDeUsuarios != null && listaDeUsuarios.isEmpty() )
					{
						isPasswordError = Boolean.TRUE;
					}
					else
					{
						isPasswordError = Boolean.FALSE;
					}
					request.getSession().setAttribute("isPasswordError", isPasswordError);
				}
				if( isUsernameError.booleanValue() == true || isPasswordError.booleanValue() == true )
				{
					response.sendRedirect("login.jsp");
				}
				else
				{
					if( username != null && !username.equals("") && password != null && !password.equals("") )
					{
						//Consulta en Base de Datos si existe el usuario
						consultaHQL = "select u from Usuario as u where 1=1 and u.nombreAcceso = '" + username + "' and u.claveAcceso = '" + password + "'";
						listaDeUsuarios = UsuarioHome.consultaUsuarios(consultaHQL);
						if( listaDeUsuarios == null )
						{
							if( UsuarioHome.getMensaje() != null && !UsuarioHome.getMensaje().equals("") )
							{
								LoginServlet.setMensaje( UsuarioHome.getMensaje() );
								request.getSession().setAttribute("mensaje", LoginServlet.getMensaje() );
								response.sendRedirect("login.jsp");
							}
						}
						else if( listaDeUsuarios != null )
						{	
							if( !listaDeUsuarios.isEmpty() )
							{
								if( listaDeUsuarios.size() == 1 )
								{
									// username y password corresponden a un usuario en la base de datos
									usuario = (Usuario)listaDeUsuarios.get(0);//índice comienza en cero
									//if( usuario.getNombreAcceso().equals(username) && usuario.getClaveAcceso().equals(password) )
									if( usuario.getNombreAcceso().compareTo( username ) == 0 && usuario.getClaveAcceso().compareTo( password ) == 0 )
									{
										//para poder usar include/common.jsp
										request.getSession().setAttribute("user", "authenticated!");
										
										request.getSession().setAttribute("usuario", usuario);
										mensajeBienvenida = "Bienvenido al Portal " + usuario.getNombreReal() + " " + usuario.getApellido();
										request.getSession().setAttribute("mensajeBienvenida", mensajeBienvenida);
										response.sendRedirect("index.jsp");
									}
									else  if( usuario.getNombreAcceso().compareTo( username ) != 0 || usuario.getClaveAcceso().compareTo( password ) != 0 )
									{
										request.getSession().setAttribute("username", username);
										request.getSession().setAttribute("password", password);
														
										isUsernameError = Boolean.TRUE;
										isPasswordError = Boolean.TRUE;
											
										request.getSession().setAttribute("isUsernameError", isUsernameError);
										request.getSession().setAttribute("isPasswordError", isPasswordError);
										
										LoginServlet.setMensaje( "Username o Password incorrectos..! Intente nuevamente ..!" );
										request.getSession().setAttribute("mensaje", LoginServlet.getMensaje() );
										response.sendRedirect("login.jsp");
									}
								}
								else
								{
									LoginServlet.setMensaje( "Error en la consulta HQL al buscar el username y password ..! Intente nuevamente ..!" );
									request.getSession().setAttribute("mensaje", LoginServlet.getMensaje() );
									response.sendRedirect("login.jsp");
								}
							}
							else if( listaDeUsuarios.isEmpty() )
							{
								LoginServlet.setMensaje("El usuario no existe en la Base de Datos ..! ");
								contadorIntentosDeAcceso++;
								if( contadorIntentosDeAcceso == 5)
								{
									LoginServlet.setMensaje( LoginServlet.getMensaje() + " Lo invitamos a registrarse como Usuario de nuestro Portal ..! ");
									contadorIntentosDeAcceso = 0;
								}
								response.sendRedirect("login.jsp");
							}
						}
					}
				}
			}
			else
			{
				username = request.getParameter("username");
				password = request.getParameter("password");
				
				request.getSession().setAttribute("username", username);
				request.getSession().setAttribute("password", password);
								
				isUsernameError = Boolean.TRUE;
				isPasswordError = Boolean.TRUE;
					
				request.getSession().setAttribute("isUsernameError", isUsernameError);
				request.getSession().setAttribute("isPasswordError", isPasswordError);
					
				LoginServlet.setMensaje("Debe completar todos los campos del formulario ..! ");
				request.getSession().setAttribute("mensaje", LoginServlet.getMensaje() );
				response.sendRedirect("login.jsp");	
			}
		}
		catch(HibernateException hex)
		{
			LoginServlet.setMensaje("Ha ocurrido una Excepción en LoginServlet.doPost( request, response) " + hex);
			request.getSession().setAttribute("mensaje", LoginServlet.getMensaje() );
			response.sendRedirect("login.jsp");
		}
		catch(Exception ex)
		{
			LoginServlet.setMensaje("Ha ocurrido una Excepción en LoginServlet.doPost(request, response) " + ex );
			request.getSession().setAttribute("mensaje", LoginServlet.getMensaje() );
			response.sendRedirect("login.jsp");
		}
	}   	  	    
}