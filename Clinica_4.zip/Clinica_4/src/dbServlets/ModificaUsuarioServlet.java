package dbServlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import clinica.Usuario;
import clinica.UsuarioHome;

/**
 * Servlet implementation class for Servlet: ModificaUsuarioServlet
 *
 */
 public class ModificaUsuarioServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
 {
	 private static String mensaje;
	 
	 public static void setMensaje(String mensaje){ ModificaUsuarioServlet.mensaje = mensaje; }
	 
	 public static String getMensaje(){ return ModificaUsuarioServlet.mensaje; }
	 
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public ModificaUsuarioServlet() 
	{
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String nombreRealNuevo;
		String apellidoNuevo;
		String nombreAccesoNuevo;
		String claveAccesoNuevo;
			
		Boolean isNewUsernameRepeated = Boolean.FALSE; //por defecto;
		Boolean isUsuarioSuccesfullModified = Boolean.FALSE; //por defecto
		String consultaHQL;
		List<Usuario> listaDeUsuarios;
		Usuario usuario;
		
		try
		{
			if( !request.getParameter("nombreRealNuevo").equals("") && 
				!request.getParameter("apellidoNuevo").equals("") &&
				!request.getParameter("usernameNuevo").equals("") &&
				!request.getParameter("passwordNuevo").equals("")
				)
			{
				nombreRealNuevo = request.getParameter("nombreRealNuevo");
				apellidoNuevo = request.getParameter("apellidoNuevo");
				nombreAccesoNuevo = request.getParameter("usernameNuevo");
				claveAccesoNuevo = request.getParameter("passwordNuevo");
				
				request.getSession().setAttribute("nombreRealNuevo", nombreRealNuevo);
				request.getSession().setAttribute("apellidoNuevo", apellidoNuevo);
				request.getSession().setAttribute("usernameNuevo", nombreAccesoNuevo);
				request.getSession().setAttribute("passwordNuevo", claveAccesoNuevo);
				
				if( LoginServlet.getHibernateSessionFactory() == null )
				{
					LoginServlet.createHibernateSessionFactory();
				}
				if( LoginServlet.getHibernateSession() == null )
				{
					LoginServlet.createHibernateSession();
				}
				//Obtiene el Usuario actual desde la HttpSession
				usuario = (Usuario)request.getSession().getAttribute("usuario"); //no debería ser null hasta el logout
				if( usuario != null )
				{
					//ver si nuevo username    existe en base de dato y es igual al actual => modifica (set)
					//     "   "      "           "   "    "   "   "  " es  distinto de actual => es de otro usuario => no modifica => avisa
					//    si nuevo username no existe en base de dato                      => modifica (set)
					
					//Verifica si el nuevo username ya existe, entonces no puede
					// registrarlo y vuelve al formulario pidiéndole que 
					// elija otro username
					consultaHQL = "select u from Usuario as u where 1=1 and u.nombreAcceso = '" + nombreAccesoNuevo +"'";
					listaDeUsuarios = UsuarioHome.consultaUsuarios(consultaHQL);
					if( listaDeUsuarios == null )
					{
						if( UsuarioHome.getMensaje() != null && !UsuarioHome.getMensaje().equals("") )
						{
							ModificaUsuarioServlet.setMensaje( UsuarioHome.getMensaje() );
							request.getSession().setAttribute("mensaje", ModificaUsuarioServlet.getMensaje() );
							response.sendRedirect("do_modifica_usuario.jsp");
						}
						else
						{
							ModificaUsuarioServlet.setMensaje("Ha ocurrido un error en ModificaUsuarioServlet.doPost(request, response) :" +
									"La lista de Usuarios no puede ser nula ..!");
							request.getSession().setAttribute("mensaje", ModificaUsuarioServlet.getMensaje() );
							response.sendRedirect("do_modifica_usuario.jsp");
						}
					}
					if( listaDeUsuarios != null )
					{
						if( listaDeUsuarios.isEmpty() )
						{
							//Si no hay en la base de datos alguien registrado con ese nuevo username => puede guardarlo con ese nuevo username!
							
							isNewUsernameRepeated = Boolean.FALSE;
							request.getSession().setAttribute("isNewUsernameRepeated", isNewUsernameRepeated);
						
							usuario.setNombreReal(nombreRealNuevo);
							usuario.setApellido(apellidoNuevo);
							usuario.setNombreAcceso(nombreAccesoNuevo);
							usuario.setClaveAcceso(claveAccesoNuevo);
						
							isUsuarioSuccesfullModified = UsuarioHome.modificaUsuario(usuario);
						
							if( isUsuarioSuccesfullModified.booleanValue() == true )
							{
								//Actualiza el usuario en la HttpSession
								request.getSession().setAttribute("usuario", usuario);
								ModificaUsuarioServlet.setMensaje("El Perfil de Usuario ha sido modificado satisfactoriamente ..!");
								request.getSession().setAttribute("mensaje", ModificaUsuarioServlet.getMensaje() );
								response.sendRedirect("do_modifica_usuario.jsp");
							}
							
							if( isUsuarioSuccesfullModified.booleanValue() == false )
							{
								ModificaUsuarioServlet.setMensaje( UsuarioHome.getMensaje() );
								request.getSession().setAttribute("mensaje", ModificaUsuarioServlet.getMensaje() );
								response.sendRedirect("do_modifica_usuario.jsp");
							}
						}
						if( !listaDeUsuarios.isEmpty() )
						{
							// Si hay un usuario en la base de datos que tiene ese mismo username
							if( listaDeUsuarios.size() == 1 )
							{
								Usuario usuarioTemp = (Usuario)listaDeUsuarios.get(0);
								if( usuarioTemp != null )
								{
									// Si ese Usuario que tiene el mismo Username también tiene el mismo Id => puede guardarlo con ese Username
									if(  usuarioTemp.getIdUsuario() == usuario.getIdUsuario() )
									{
										isNewUsernameRepeated = Boolean.FALSE;
										request.getSession().setAttribute("isNewUsernameRepeated", isNewUsernameRepeated);
										
										usuario.setNombreReal(nombreRealNuevo);
										usuario.setApellido(apellidoNuevo);
										usuario.setNombreAcceso(nombreAccesoNuevo);
										usuario.setClaveAcceso(claveAccesoNuevo);
								
										isUsuarioSuccesfullModified = UsuarioHome.modificaUsuario(usuario);
								
										if( isUsuarioSuccesfullModified.booleanValue() == true )
										{
											//Actualiza el usuario en la HttpSession
											request.getSession().setAttribute("usuario", usuario);
											ModificaUsuarioServlet.setMensaje("El Perfil de Usuario ha sido modificado satisfactoriamente ..!");
											request.getSession().setAttribute("mensaje", ModificaUsuarioServlet.getMensaje() );
											response.sendRedirect("do_modifica_usuario.jsp");
										}
										if(isUsuarioSuccesfullModified.booleanValue() == false )
										{
											ModificaUsuarioServlet.setMensaje( UsuarioHome.getMensaje() );
											request.getSession().setAttribute("mensaje", ModificaUsuarioServlet.getMensaje() );
											response.sendRedirect("do_modifica_usuario.jsp");
										}
									}
									if( usuarioTemp.getIdUsuario() != usuario.getIdUsuario() )
									{
										//si hay otro usuario distinto (con otro Id) que tiene mismo username => no lo puede guardar con ese username
										isNewUsernameRepeated = Boolean.TRUE;
										request.getSession().setAttribute("isNewUsernameRepeated", isNewUsernameRepeated);
								
										ModificaUsuarioServlet.setMensaje("Hay otro Usuario del Portal registrado con ese Username, Por favor elija un Username diferente ..!");
										request.getSession().setAttribute("mensaje", ModificaUsuarioServlet.getMensaje() );
										response.sendRedirect("do_modifica_usuario.jsp");
									}
								}
								if( usuarioTemp == null )
								{
									ModificaUsuarioServlet.setMensaje("Error en ModificaUsuarioServlet.doPost(request, response) : El Usuario obtenido de la consulta HQL no puede ser nulo ..!");
									request.getSession().setAttribute("mensaje", ModificaUsuarioServlet.getMensaje() );
									response.sendRedirect("do_modifica_usuario.jsp");
								}
							}
							if( listaDeUsuarios.size() > 1 )
							{
								//Si hay mas de un usuario con ese nuevo username => no lo guarda con ese nuevo username
								isNewUsernameRepeated = Boolean.TRUE;
								request.getSession().setAttribute("isNewUsernameRepeated", isNewUsernameRepeated);
								
								ModificaUsuarioServlet.setMensaje("El nuevo Username elegido ya está siendo usado por otro Usuario del Portal");
								request.getSession().setAttribute("mensaje", ModificaUsuarioServlet.getMensaje() );
								response.sendRedirect("do_modifica_usuario.jsp");
							}
						}
					}
				}
				if( usuario == null )
				{
						ModificaUsuarioServlet.setMensaje("Error: El Usuario obtenido de la HttpSession no puede ser nulo!");
						request.getSession().setAttribute("mensaje", ModificaUsuarioServlet.getMensaje() );
						response.sendRedirect("do_modifica_usuario.jsp");
				}
			}
			else
			{
				nombreRealNuevo = request.getParameter("nombreRealNuevo");
				apellidoNuevo = request.getParameter("apellidoNuevo");
				nombreAccesoNuevo = request.getParameter("usernameNuevo");
				claveAccesoNuevo = request.getParameter("passwordNuevo");
				
				request.getSession().setAttribute("nombreRealNuevo", nombreRealNuevo);
				request.getSession().setAttribute("apellidoNuevo", apellidoNuevo);
				request.getSession().setAttribute("usernameNuevo", nombreAccesoNuevo);
				request.getSession().setAttribute("passwordNuevo", claveAccesoNuevo);

				request.getSession().setAttribute("isNewUsernameRepeated", isNewUsernameRepeated);
				
				ModificaUsuarioServlet.setMensaje("Debe completar todos los campos del formulario ..!");
				request.getSession().setAttribute("mensaje", ModificaUsuarioServlet.getMensaje() );
				response.sendRedirect("do_modifica_usuario.jsp");
			}
		}
		catch(HibernateException hex)
		{
			ModificaUsuarioServlet.setMensaje("Ha ocurrido una Excepción en ModificaUsuarioServlet.doPost(request, response) " + hex);
			request.getSession().setAttribute("mensaje", ModificaUsuarioServlet.getMensaje() );
			response.sendRedirect("do_modifica_usuario.jsp");
		}
		catch(Exception ex)
		{
			ModificaUsuarioServlet.setMensaje("Ha ocurrido una Excepción en ModificaUsuarioServlet.doPost(request, response) " + ex);
			request.getSession().setAttribute("mensaje", ModificaUsuarioServlet.getMensaje() );
			response.sendRedirect("do_modifica_usuario.jsp");
		}
	}   	  	    
}