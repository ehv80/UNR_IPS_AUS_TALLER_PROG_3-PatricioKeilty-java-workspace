package dbServlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import clinica.Paciente;
import clinica.PacienteHome;

/**
 * Servlet implementation class for Servlet: ConsultaPacientesServlet
 *
 */
 public class ConsultaPacientesServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
 {
	 private static String mensaje;
	 
	 public static void setMensaje(String mensaje){ ConsultaPacientesServlet.mensaje = mensaje; }
	 
	 public static String getMensaje(){ return ConsultaPacientesServlet.mensaje; }
	 
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public ConsultaPacientesServlet() {
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String selectorCriterioConsulta;
		String valorBuscar;
		String consultaHQL = ""; //por defecto
		List<Paciente> listaDePacientesAltaConsulta;
		
		try
		{
			if( request.getParameter("selectorCriterioConsulta") != null && !request.getParameter("selectorCriterioConsulta").equals("") &&
					request.getParameter("valorBuscar") != null && !request.getParameter("valorBuscar").equals("") 
				)
			{
				selectorCriterioConsulta = request.getParameter("selectorCriterioConsulta");
				valorBuscar = request.getParameter("valorBuscar");
				
				if( selectorCriterioConsulta.equals("Id del Paciente") )
				{
					consultaHQL = "select p from Paciente as p where 1=1 and p.idPaciente = '" + valorBuscar + "'";
					
				}
				else if( selectorCriterioConsulta.equals("Nombre") )
				{
					consultaHQL = "select p from Paciente as p where 1=1 and p.nombre = '" + valorBuscar + "'";
				}
				else if( selectorCriterioConsulta.equals("Apellido") )
				{
					consultaHQL = "select p from Paciente as p where 1=1 and p.apellido = '" + valorBuscar + "'";
				}
				else if( selectorCriterioConsulta.equals("Fecha de Nacimiento") )
				{
					consultaHQL = "select p from Paciente as p where 1=1 and p.fechaNac = '" + valorBuscar + "'";
				}
				else if( selectorCriterioConsulta.equals("Tipo de Documento") )
				{
					consultaHQL = "select p from Paciente as p where 1=1 and p.tpoDoc = '" + valorBuscar + "'";
					
				}
				else if( selectorCriterioConsulta.equals("Nro. de Documento") )
				{
					consultaHQL = "select p from Paciente as p where 1=1 and p.nroDoc = '" + valorBuscar + "'";
				}
				else if( selectorCriterioConsulta.equals("Obra Social") )
				{
					consultaHQL = "select p from Paciente as p where 1=1 and p.obraSocial = '" + valorBuscar + "'";
				}
				else if( selectorCriterioConsulta.equals("Sexo") )
				{
					consultaHQL = "select p from Paciente as p where 1=1 and p.sexo = '" + valorBuscar + "'";
				}
				else if( selectorCriterioConsulta.equals("Esta con Vida") )
				{
					consultaHQL = "select p from Paciente as p where 1=1 and p.estaVivo = '"+ valorBuscar +"'";
				}
				else
				{
					ConsultaPacientesServlet.setMensaje("Debe elegir uno de los criterios de Búsqueda disponibles ..! ");
					request.getSession().setAttribute("mensajeAltaPacienteConsulta", ConsultaPacientesServlet.getMensaje() );
					response.sendRedirect("do_alta_paciente.jsp");//?
				}
				if( consultaHQL.equals("") )
				{
					ConsultaPacientesServlet.setMensaje("Debe elegir uno de los criterios de Búsqueda disponibles ..! ");
					request.getSession().setAttribute("mensajeAltaPacienteConsulta", ConsultaPacientesServlet.getMensaje() );
					response.sendRedirect("do_alta_paciente.jsp");//?
				}
				else
				{
					listaDePacientesAltaConsulta = PacienteHome.consultaPacientes(consultaHQL);
					request.getSession().setAttribute("listaDePacientesAltaConsulta", listaDePacientesAltaConsulta);
					if( listaDePacientesAltaConsulta == null )
					{
						if( PacienteHome.getMensaje() != null && !PacienteHome.getMensaje().equals("") )
						{
							request.getSession().setAttribute("mensajeAltaPacienteConsulta", PacienteHome.getMensaje() );
							response.sendRedirect("do_alta_paciente.jsp");
						}
						else
						{
							ConsultaPacientesServlet.setMensaje(
									"Ha ocurrido un error en ConsultaPacientesServlet.doPost(request, response) " +
									" al ejecutar PacienteHome.consultaPacientes(consultaHQL)");
							request.getSession().setAttribute("mensajeAltaPacienteConsulta", ConsultaPacientesServlet.getMensaje() );
							response.sendRedirect("do_alta_paciente.jsp");
						}
					}
					if( listaDePacientesAltaConsulta != null && listaDePacientesAltaConsulta.isEmpty() )
					{
						ConsultaPacientesServlet.setMensaje("No hay Pacientes registrados que cumplan con su criterio de búsqueda ..!");
						request.getSession().setAttribute("mensajeAltaPacienteConsulta", ConsultaPacientesServlet.getMensaje() );
						response.sendRedirect("do_alta_paciente.jsp");
					}	
					if( listaDePacientesAltaConsulta != null && !listaDePacientesAltaConsulta.isEmpty() )
					{
						response.sendRedirect("do_alta_paciente.jsp");
					}	
				}
			}
			else
			{
				ConsultaPacientesServlet.setMensaje("Debe seleccionar uno de los Criterios de Búsqueda y completar con un valor a Buscar ..!");
				request.getSession().setAttribute("mensajeAltaPacienteConsulta", ConsultaPacientesServlet.getMensaje() );
				response.sendRedirect("do_alta_paciente.jsp");
			}
		}
		catch(HibernateException hex)
		{
			ConsultaPacientesServlet.setMensaje("Ha ocurrido una Excepción en ConsultaPacientesServlet.doPost( request, response) : " + hex);
			request.getSession().setAttribute("mensajeAltaPacienteConsulta", ConsultaPacientesServlet.getMensaje() );
			response.sendRedirect("do_alta_paciente.jsp");
		}
		catch(Exception ex)
		{
			ConsultaPacientesServlet.setMensaje("Ha ocurrido una Excepción en ConsultaPacientesServlet.doPost( request, response) : " + ex);
			request.getSession().setAttribute("mensajeAltaPacienteConsulta", ConsultaPacientesServlet.getMensaje() );
			response.sendRedirect("do_alta_paciente.jsp");
		}
	}   	  	    
}