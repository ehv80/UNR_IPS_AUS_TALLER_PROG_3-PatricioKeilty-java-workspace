package dbServlets;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import utility.FechaUtil;
import clinica.Diagnostico;
import clinica.DiagnosticoHome;
import clinica.Paciente;
import clinica.PacienteHome;

/**
 * Servlet implementation class for Servlet: ModificaDiagnosticoServlet
 *
 */
 public class ModificaDiagnosticoServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
 {
	 private static String mensaje;
	 
	 public static void setMensaje(String mensaje){ ModificaDiagnosticoServlet.mensaje = mensaje; }
	 
	 public static String getMensaje(){ return ModificaDiagnosticoServlet.mensaje; }
	 
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public ModificaDiagnosticoServlet() 
	{
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		List<Paciente> listaDePacientes;
		List<Diagnostico> listaDeDiagnosticos;
		Paciente paciente;
		String consultaPacienteHQL;
		String consultaDiagnosticoHQL;
		String descripcionDiagnosticoModificar;
		Date fechaDiagnosticoModificar;
			String cadenaFechaDiagnosticoModificar;
			String anioDiagnosticoModificar;
			String mesDiagnosticoModificar;
			String diaDiagnosticoModificar;
		String idPacienteDiagnosticoModificar;
		String idDiagnosticoModificar;
		Diagnostico diagnosticoModificar;
		Boolean isSuccesfullUpdated;
		try
		{
			if( request.getParameter("descripcionDiagnosticoModificar") != null && !request.getParameter("descripcionDiagnosticoModificar").equals("") &&
					request.getParameter("anioDiagnosticoModificar") != null && !request.getParameter("anioDiagnosticoModificar").equals("") &&
					request.getParameter("mesDiagnosticoModificar") != null && !request.getParameter("mesDiagnosticoModificar").equals("") &&
					request.getParameter("diaDiagnosticoModificar") != null && !request.getParameter("diaDiagnosticoModificar").equals("") &&
					request.getParameter("idPacienteDiagnosticoModificar") != null && !request.getParameter("idPacienteDiagnosticoModificar").equals("")
				)
			{
				
				descripcionDiagnosticoModificar = request.getParameter("descripcionDiagnosticoModificar");
				anioDiagnosticoModificar = request.getParameter("anioDiagnosticoModificar");
				mesDiagnosticoModificar = request.getParameter("mesDiagnosticoModificar");
				diaDiagnosticoModificar = request.getParameter("diaDiagnosticoModificar");
				idPacienteDiagnosticoModificar = request.getParameter("idPacienteDiagnosticoModificar");
				
				request.getSession().setAttribute("descripcionDiagnosticoModificar", descripcionDiagnosticoModificar);
				request.getSession().setAttribute("anioDiagnosticoModificar", anioDiagnosticoModificar);
				request.getSession().setAttribute("mesDiagnosticoModificar", mesDiagnosticoModificar);
				request.getSession().setAttribute("diaDiagnosticoModificar", diaDiagnosticoModificar);
				request.getSession().setAttribute("idPacienteDiagnosticoModificar", idPacienteDiagnosticoModificar);
				
				//Para mayor consistencia de los datos, extrae el Paciente desde una Consulta HQL
				consultaPacienteHQL = "select p from Paciente as p where 1=1 and p.idPaciente = '" + idPacienteDiagnosticoModificar + "'";
				listaDePacientes = PacienteHome.consultaPacientes(consultaPacienteHQL);
				if( listaDePacientes == null )
				{
					if( PacienteHome.getMensaje() != null && !PacienteHome.getMensaje().equals("") )
					{
						ModificaDiagnosticoServlet.setMensaje( PacienteHome.getMensaje() );
						request.getSession().setAttribute("mensaje", ModificaDiagnosticoServlet.getMensaje() );
						response.sendRedirect("do_modifica_diagnostico.jsp");
					}
					else
					{
						ModificaDiagnosticoServlet.setMensaje("La lista de Pacientes que arroja la consulta HQL no puede ser nula ..!");
						request.getSession().setAttribute("mensaje", ModificaDiagnosticoServlet.getMensaje() );
						response.sendRedirect("do_modifica_diagnostico.jsp");
					}
				}
				else if( listaDePacientes != null )
				{
					if( listaDePacientes.isEmpty() )
					{
						ModificaDiagnosticoServlet.setMensaje(
								"El Paciente al que desea modificar un Diagnóstico no está almacenado en la Base de Datos ..!");
						request.getSession().setAttribute("mensaje", ModificaDiagnosticoServlet.getMensaje() );
						response.sendRedirect("do_modifica_diagnostico.jsp");
					}
					else if( !listaDePacientes.isEmpty() )
					{
						if( listaDePacientes.size() == 1 )
						{
							if( String.valueOf( listaDePacientes.get(0).getIdPaciente() ).equals( idPacienteDiagnosticoModificar ) )
							{
								//El Paciente a Diagnósticar está registrado en la Base de Datos
								paciente = listaDePacientes.get(0);//índice comienza en cero
								//1º Verifica: si el Paciente está muerto => no puede registrar Diagnóstico
								if( paciente.isEstaVivo() )
								{
									//2º Valida la Fecha del Diagnóstico
									cadenaFechaDiagnosticoModificar = anioDiagnosticoModificar + "-" + mesDiagnosticoModificar + "-" + diaDiagnosticoModificar;
									fechaDiagnosticoModificar = FechaUtil.validaFecha(cadenaFechaDiagnosticoModificar);
									if( fechaDiagnosticoModificar == null )
									{
										if( FechaUtil.getMensaje() != null && !FechaUtil.getMensaje().equals("") )
										{
											ModificaDiagnosticoServlet.setMensaje( FechaUtil.getMensaje() );
											request.getSession().setAttribute("mensaje", ModificaDiagnosticoServlet.getMensaje() );
											response.sendRedirect("do_modifica_diagnostico.jsp");
										}
										else
										{
											ModificaDiagnosticoServlet.setMensaje("Debe seleccionar una Fecha que sea válida ..!");
											request.getSession().setAttribute("mensaje", ModificaDiagnosticoServlet.getMensaje() );
											response.sendRedirect("do_Modifica_diagnostico.jsp");
										}
									}
									else if( fechaDiagnosticoModificar != null )
									{
										//Tiene Paciente que no es nulo ni está muerto y Fecha de Diagnóstico es válida => puede actualizar Diagnóstico

										//diagnosticoModificar = new Diagnostico( paciente , descripcionDiagnosticoModificar, fechaDiagnosticoModificar);
										//DEBE SACAR DE CONSULTA
										idDiagnosticoModificar = (String)request.getSession().getAttribute("idDiagnosticoModificar");
										consultaDiagnosticoHQL = "select d from Diagnostico as d where 1=1 and d.idDiagnostico = '" + idDiagnosticoModificar + "'";
										listaDeDiagnosticos =  DiagnosticoHome.consultaDiagnosticos(consultaDiagnosticoHQL);
										if( listaDeDiagnosticos == null )
										{
											if( DiagnosticoHome.getMensaje() != null && !DiagnosticoHome.getMensaje().equals("") )
											{
												ModificaDiagnosticoServlet.setMensaje( DiagnosticoHome.getMensaje() );
												request.getSession().setAttribute("mensaje", ModificaDiagnosticoServlet.getMensaje() );
												response.sendRedirect("do_modifica_diagnostico.jsp");
											}
											else
											{
												ModificaDiagnosticoServlet.setMensaje( "Error en consulta HQL al buscar Diagnósticos ..!" );
												request.getSession().setAttribute("mensaje", ModificaDiagnosticoServlet.getMensaje() );
												response.sendRedirect("do_modifica_diagnostico.jsp");
											}
										}
										else if( listaDeDiagnosticos != null)
										{
											if( listaDeDiagnosticos.isEmpty() )
											{
												ModificaDiagnosticoServlet.setMensaje( "El Diagnóstico seleccionado para modificar ya no existe en la Base de Datos ..!" );
												request.getSession().setAttribute("mensaje", ModificaDiagnosticoServlet.getMensaje() );
												response.sendRedirect("do_modifica_diagnostico.jsp");
											}
											else if( !listaDeDiagnosticos.isEmpty() )
											{
												if( listaDeDiagnosticos.size() == 1 )
												{
													if( String.valueOf( listaDeDiagnosticos.get(0).getIdDiagnostico() ).equals( idDiagnosticoModificar ) )
													{
														diagnosticoModificar = listaDeDiagnosticos.get(0); //índice comienza en cero
														
														if( diagnosticoModificar == null )
														{
															ModificaDiagnosticoServlet.setMensaje(
																	"El Diagnóstico a Modificar no puede ser nulo ..! Intente nuevamente ..!");
															request.getSession().setAttribute("mensaje", ModificaDiagnosticoServlet.getMensaje() );
															response.sendRedirect("do_Modifica_diagnostico.jsp");
														}
														else if( diagnosticoModificar != null )
														{
															//Modifica el Diagnóstico
															diagnosticoModificar.setDescripcion(descripcionDiagnosticoModificar);
															diagnosticoModificar.setFecha(fechaDiagnosticoModificar);
															//almacena Diagnóstico
															isSuccesfullUpdated = DiagnosticoHome.actualizaDiagnostico(diagnosticoModificar);
															
															if( isSuccesfullUpdated.booleanValue() == false )
															{
																if( DiagnosticoHome.getMensaje() != null && !DiagnosticoHome.getMensaje().equals("") )
																{
																	ModificaDiagnosticoServlet.setMensaje( DiagnosticoHome.getMensaje() );
																	request.getSession().setAttribute("mensaje", ModificaDiagnosticoServlet.getMensaje() );
																	response.sendRedirect("do_modifica_diagnostico.jsp");
																}
																else
																{
																	ModificaDiagnosticoServlet.setMensaje(
																			"El Diagnóstico NO HA SIDO MODIFICADO en la Base de Datos ..! Intente nuevamente ..!");
																	request.getSession().setAttribute("mensaje", ModificaDiagnosticoServlet.getMensaje() );
																	response.sendRedirect("do_modifica_diagnostico.jsp");
																}
															}
															else if( isSuccesfullUpdated.booleanValue() == true )
															{
																request.getSession().setAttribute("pacienteSeleccionadoModificarDiagnostico", null);
																//request.getSession().setAttribute("diagnosticoModificar", null);
																request.getSession().setAttribute("idDiagnosticoModificar", null);
																
																ModificaDiagnosticoServlet.setMensaje("El Diagnóstico ha sido modificado satisfactoriamente en la Base de Datos ..! ");
																request.getSession().setAttribute("mensaje", ModificaDiagnosticoServlet.getMensaje() );
																response.sendRedirect("do_modifica_diagnostico.jsp");
															}
														}
													}
												}
												else
												{
													ModificaDiagnosticoServlet.setMensaje( "Error en consulta HQL al buscar Diagnósticos ..!" );
													request.getSession().setAttribute("mensaje", ModificaDiagnosticoServlet.getMensaje() );
													response.sendRedirect("do_modifica_diagnostico.jsp");
												}
											}
										}
										
										
										
										
									}
								}
								else
								{
									ModificaDiagnosticoServlet.setMensaje("No puede Modificar un Diagnóstico a un Paciente que ha fallecido ..!");
									request.getSession().setAttribute("mensaje", ModificaDiagnosticoServlet.getMensaje() );
									response.sendRedirect("do_modifica_diagnostico.jsp");
								}
							}	
						}
						else
						{
							ModificaDiagnosticoServlet.setMensaje(
									"Error en la consulta HQL ..! NO puede Modificar el Diagnóstico ..! Intente nuevamente ..!" );
							request.getSession().setAttribute("mensaje", ModificaDiagnosticoServlet.getMensaje() );
							response.sendRedirect("do_modifica_diagnostico.jsp");
						}
					}
				}
			}
			else
			{
				ModificaDiagnosticoServlet.setMensaje("Debe completar todos los campos del formulario ..!");
				request.getSession().setAttribute("mensaje", ModificaDiagnosticoServlet.getMensaje() );
				response.sendRedirect("do_modifica_diagnostico.jsp");
			}
		}
		catch(HibernateException hex)
		{
			ModificaDiagnosticoServlet.setMensaje("Ha ocurrido una Excepción en ModificaDiagnosticoServlet.doPost(request, reponse) " +
					"Detalles:  " + hex);
			request.getSession().setAttribute("mensaje", ModificaDiagnosticoServlet.getMensaje() );
			response.sendRedirect("do_modifica_diagnostico.jsp");
		}
		catch(Exception ex)
		{
			ModificaDiagnosticoServlet.setMensaje("Ha ocurrido una Excepción en ModificaDiagnosticoServlet.doPost(request, reponse) " +
					"Detalles:  " + ex);
			request.getSession().setAttribute("mensaje", ModificaDiagnosticoServlet.getMensaje() );
			response.sendRedirect("do_modifica_diagnostico.jsp");
		}
	}   	  	    
}