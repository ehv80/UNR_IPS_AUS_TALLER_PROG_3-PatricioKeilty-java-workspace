package dbServlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import clinica.Paciente;
import clinica.PacienteHome;

/**
 * Servlet implementation class for Servlet: SeleccionaPacienteEliminarServlet
 *
 */
 public class SeleccionaPacienteEliminarServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
 {
	 private static String mensaje;
	 
	 public static void setMensaje( String mensaje ){ SeleccionaPacienteEliminarServlet.mensaje = mensaje; }
	 
	 public static String getMensaje(){ return SeleccionaPacienteEliminarServlet.mensaje; }
	 
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public SeleccionaPacienteEliminarServlet() 
	{
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String selectorPacienteEliminar;
		String consultaHQL;
		List<Paciente> listaDePacientes;
		Paciente pacienteSeleccionadoEliminar;
		try
		{
			if( request.getParameter("selectorPacienteEliminar") != null && 
					!request.getParameter("selectorPacienteEliminar").equals("") 
				)
			{
				selectorPacienteEliminar = request.getParameter("selectorPacienteEliminar");
				consultaHQL = "select p from Paciente as p where 1=1 and p.idPaciente = '" + selectorPacienteEliminar + "'";
				listaDePacientes = PacienteHome.consultaPacientes(consultaHQL);
				if( listaDePacientes == null )
				{
					if( PacienteHome.getMensaje() == null )
					{
						SeleccionaPacienteEliminarServlet.setMensaje( "EL Paciente seleccionado no puede ser nulo ..! Vuelva a intentarlo ..!" );
						request.getSession().setAttribute("mensajeSeleccionaPacienteEliminar" , SeleccionaPacienteEliminarServlet.getMensaje() );
						response.sendRedirect("do_elimina_paciente.jsp");
					}
					else if( PacienteHome.getMensaje() != null && !PacienteHome.getMensaje().equals("") )
					{
						SeleccionaPacienteEliminarServlet.setMensaje( PacienteHome.getMensaje() );
						request.getSession().setAttribute("mensajeSeleccionaPacienteEliminar" , SeleccionaPacienteEliminarServlet.getMensaje() );
						response.sendRedirect("do_elimina_paciente.jsp");
					}
				}
				else if( listaDePacientes != null )
				{
					if( listaDePacientes.isEmpty() )
					{
						SeleccionaPacienteEliminarServlet.setMensaje( "EL Paciente que ha seleccionado para modificar no está registrado en la Base de Datos ..! Vuelva a intentarlo ..!" );
						request.getSession().setAttribute("mensajeSeleccionaPacienteEliminar" , SeleccionaPacienteEliminarServlet.getMensaje() );
						response.sendRedirect("do_elimina_paciente.jsp");
					}
					else if( !listaDePacientes.isEmpty() )
					{
						if( listaDePacientes.size() == 1 )
						{
							pacienteSeleccionadoEliminar = listaDePacientes.get(0); //índice comienza en cero
							if( String.valueOf( pacienteSeleccionadoEliminar.getIdPaciente() ).equals( selectorPacienteEliminar ) )
							{
								request.getSession().setAttribute("pacienteSeleccionadoEliminar", pacienteSeleccionadoEliminar);
								response.sendRedirect("do_elimina_paciente.jsp");
							}
						}
						else
						{
							SeleccionaPacienteEliminarServlet.setMensaje( "EL Paciente que ha seleccionado para modificar no está registrado en la Base de Datos ..! Vuelva a intentarlo ..!" );
							request.getSession().setAttribute("mensajeSeleccionaPacienteEliminar" , SeleccionaPacienteEliminarServlet.getMensaje() );
							response.sendRedirect("do_elimina_paciente.jsp");
						}
					}
				}
			}	
			else
			{
				SeleccionaPacienteEliminarServlet.setMensaje("Debe seleccionar uno de los Pacientes en el selector ..!");
				request.getSession().setAttribute("mensajeSeleccionaPacienteEliminar", SeleccionaPacienteEliminarServlet.getMensaje() );
				response.sendRedirect("do_elimina_paciente.jsp");
			}
		}
		catch(HibernateException hex)
		{
			SeleccionaPacienteEliminarServlet.setMensaje("Ha ocurrido una Excepción en SeleccionaPacienteEliminarServlet.doPost(request, response) : " + hex);
			request.getSession().setAttribute("mensajeSeleccionaPacienteEliminar", SeleccionaPacienteEliminarServlet.getMensaje() );
			response.sendRedirect("do_elimina_paciente.jsp");
		}
		catch(Exception ex)
		{
			SeleccionaPacienteEliminarServlet.setMensaje("Ha ocurrido una Excepción en SeleccionaPacienteEliminarServlet.doPost(request, response) : " + ex);
			request.getSession().setAttribute("mensajeSeleccionaPacienteEliminar", SeleccionaPacienteEliminarServlet.getMensaje() );
			response.sendRedirect("do_limina_paciente.jsp");
		}
	}   	  	    
}