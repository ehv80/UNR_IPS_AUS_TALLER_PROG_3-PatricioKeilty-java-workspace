package clinica;

// Generated 24/12/2007 10:36:36 by Hibernate Tools 3.2.0.beta8

import java.util.List;
import javax.naming.InitialContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.LockMode;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import dbServlets.LoginServlet;

import static org.hibernate.criterion.Example.create;

/**
 * Home object for domain model class Paciente.
 * @see clinica.Paciente
 * @author Hibernate Tools
 */
public class PacienteHome 
{

private static String mensaje;
	
	public static void setMensaje(String mensaje){ PacienteHome.mensaje = mensaje; }
	
	public static String getMensaje(){ return PacienteHome.mensaje; }
	
	/**
	 * @author ehv80
	 * Método:	consultaPacientes
	 * 		Realiza una consulta HQL en la base de datos Clinica, Tabla PACIENTES.
	 * @param	String consultaHQL
	 * @return	List<Paciente>
	 */
	public static List<Paciente> consultaPacientes(String consultaHQL)
	{
		Transaction transaccion;
		List<Paciente> listaDePacientes;
		try
		{
			if( consultaHQL != null && !consultaHQL.equals("") )
			{
				if(LoginServlet.getHibernateSessionFactory() == null)
				{
					LoginServlet.createHibernateSessionFactory();
				}
				if( LoginServlet.getHibernateSession() == null )
				{
					LoginServlet.createHibernateSession();
				}
				transaccion = LoginServlet.getHibernateSession().beginTransaction();
				listaDePacientes= (List<Paciente>)(LoginServlet.getHibernateSession().createQuery(consultaHQL).list());
				transaccion.commit();
				return listaDePacientes;
			}
			else
			{	
				PacienteHome.setMensaje("Error en PacienteHome.consultaPacientes(consulatHQL): La consulta HQL no puede estar vacía ..!" );
				return (List<Paciente>)null;
			}
		}
		catch(HibernateException ex)
		{
			PacienteHome.setMensaje("Ha ocurrido una Excepción en PacienteHome.consultaPacientes(consulatHQL) " + ex);
			return (List<Paciente>)null;
		}
	}
	
	
	/**
	 * @author ehv80
	 * Método:	almacenaPaciente
	 * 			En caso de almacenar paciente con éxito retorna Boolean.TRUE
	 * 			En caso contrario retorna Boolean.FALSE
	 * @param Paciente paciente
	 * @return Boolean isSuccesfullSaved
	 */
	public static Boolean almacenaPaciente(Paciente paciente)
	{
		Boolean isSuccesfullSaved = Boolean.FALSE; //por defecto
		Transaction transaccion;
		try
		{
			if( paciente != null &&
					!String.valueOf( paciente.getIdPaciente() ).equals("") &&
					!paciente.getNombre().equals("") &&
					!paciente.getApellido().equals("") &&
					!paciente.getFechaNac().toString().equals("") &&
					!paciente.getTpoDoc().equals("") &&
					!String.valueOf( paciente.getNroDoc() ).equals("") &&
					!paciente.getObraSocial().equals("") &&
					!paciente.getSexo().equals("") &&
					!String.valueOf( paciente.isEstaVivo() ).equals("") 
				)
			{
				if(LoginServlet.getHibernateSessionFactory() == null)
				{
					LoginServlet.createHibernateSessionFactory();
				}
				if( LoginServlet.getHibernateSession() == null )
				{
					LoginServlet.createHibernateSession();
				}
				transaccion = LoginServlet.getHibernateSession().beginTransaction();
				LoginServlet.getHibernateSession().save(paciente);
				transaccion.commit();
				isSuccesfullSaved = Boolean.TRUE;
				return isSuccesfullSaved;
			}
			else
			{
				PacienteHome.setMensaje("Debe completar todos los campos del formulario ..!");
				return isSuccesfullSaved;
			}
		}
		catch(HibernateException hex)
		{
			PacienteHome.setMensaje("Ha ocurrido una Excepción en PacienteHome.almacenaPaciente( paciente ) " + hex);
			return isSuccesfullSaved;
		}
	}
	
	/**
	 * @author ehv80
	 * Método:	actualizaPaciente
	 * 			En caso de actualizar paciente con éxito retorna Boolean.TRUE
	 * 			En caso contrario retorna Boolean.FALSE
	 * @param Paciente paciente
	 * @return Boolean isSuccesfullUpdated
	 */
	public static Boolean actualizaPaciente(Paciente paciente)
	{
		Boolean isSuccesfullUpdated = Boolean.FALSE; //por defecto
		Transaction transaccion;
		try
		{
			if( paciente != null &&
					!String.valueOf( paciente.getIdPaciente() ).equals("") &&
					!paciente.getNombre().equals("") &&
					!paciente.getApellido().equals("") &&
					!paciente.getFechaNac().toString().equals("") &&
					!paciente.getTpoDoc().equals("") &&
					!String.valueOf( paciente.getNroDoc() ).equals("") &&
					!paciente.getObraSocial().equals("") &&
					!paciente.getSexo().equals("") &&
					!String.valueOf( paciente.isEstaVivo() ).equals("") 
				)
			{
				if(LoginServlet.getHibernateSessionFactory() == null)
				{
					LoginServlet.createHibernateSessionFactory();
				}
				if( LoginServlet.getHibernateSession() == null )
				{
					LoginServlet.createHibernateSession();
				}
				transaccion = LoginServlet.getHibernateSession().beginTransaction();
				LoginServlet.getHibernateSession().saveOrUpdate(paciente);
				transaccion.commit();
				isSuccesfullUpdated = Boolean.TRUE;
				return isSuccesfullUpdated;
			}
			else
			{
				PacienteHome.setMensaje("Debe completar todos los campos del formulario ..!");
				return isSuccesfullUpdated;
			}
		}
		catch(HibernateException hex)
		{
			PacienteHome.setMensaje("Ha ocurrido una Excepción en PacienteHome.actualizaPaciente( paciente ) " + hex);
			return isSuccesfullUpdated;
		}
	}
		
	/**
	 * @author ehv80
	 * Método:	eliminaPaciente
	 * 			En caso de eliminar paciente con éxito retorna Boolean.TRUE
	 * 			En caso contrario retorna Boolean.FALSE
	 * @param Paciente paciente
	 * @return Boolean isSuccesfullDeleted
	 */
	public static Boolean eliminaPaciente(Paciente paciente)
	{
		Boolean isSuccesfullDeleted = Boolean.FALSE; //por defecto
		Transaction transaccion;
		try
		{
			if( paciente != null &&
					!String.valueOf( paciente.getIdPaciente() ).equals("") &&
					!paciente.getNombre().equals("") &&
					!paciente.getApellido().equals("") &&
					!paciente.getFechaNac().toString().equals("") &&
					!paciente.getTpoDoc().equals("") &&
					!String.valueOf( paciente.getNroDoc() ).equals("") &&
					!paciente.getObraSocial().equals("") &&
					!paciente.getSexo().equals("") &&
					!String.valueOf( paciente.isEstaVivo() ).equals("") 
				)
			{
				if(LoginServlet.getHibernateSessionFactory() == null)
				{
					LoginServlet.createHibernateSessionFactory();
				}
				if( LoginServlet.getHibernateSession() == null )
				{
					LoginServlet.createHibernateSession();
				}
				transaccion = LoginServlet.getHibernateSession().beginTransaction();
				LoginServlet.getHibernateSession().delete(paciente);
				transaccion.commit();
				isSuccesfullDeleted = Boolean.TRUE;
				return isSuccesfullDeleted;
			}
			else
			{
				PacienteHome.setMensaje("Debe completar todos los campos del formulario ..!");
				return isSuccesfullDeleted;
			}
		}
		catch(HibernateException hex)
		{
			PacienteHome.setMensaje("Ha ocurrido una Excepción en PacienteHome.eliminaPaciente( paciente ) " + hex);
			return isSuccesfullDeleted;
		}
	}
	
}
