package clinica;

// Generated 24/12/2007 10:36:36 by Hibernate Tools 3.2.0.beta8

import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Transaction;

import dbServlets.LoginServlet;

/**
 * Home object for domain model class Usuario.
 * @see clinica.Usuario
 * @author Hibernate Tools
 */
public class UsuarioHome 
{
	//	inicializador estático
	static{
		consultaHQLDeTodosLosUsuarios = "select u from Usuario as u where 1=1 ";
		consultaHQLDeUnUsuarioPorUsername = "select u from Usuario as u where 1=1 and u.nombreAcceso = ";
		consultaHQLDeUnUsuarioPorPassword = "select u from Usuario as u where 1=1 and u.claveAcceso = ";
		consultaHQLDeUnUsuarioPorNombreReal = "select u from Usuario as u where 1=1 and u.nombreReal = ";
		consultaHQLDeUnUsuarioPorApellido = "select u from Usuario as u where 1=1 and u.apellido = ";
	}
	
	private static String mensaje;
	
	public static void setMensaje( String mensaje){ UsuarioHome.mensaje = mensaje; }
	
	public static String getMensaje(){ return UsuarioHome.mensaje; }

	
	private static String consultaHQLDeTodosLosUsuarios;
	private static String consultaHQLDeUnUsuarioPorUsername;
	private static String consultaHQLDeUnUsuarioPorPassword;
	private static String consultaHQLDeUnUsuarioPorNombreReal;
	private static String consultaHQLDeUnUsuarioPorApellido;
	
	/**
	 * Método de Clase: getConsultaHQLDeUnUsuarioPorUsername
	 * 			Retorna la cadena String que representa la sentencia HQL de una Consulta por Username.
	 * @return UsuarioHome.consultaHQLDeUnUsuarioPorUsername
	 */
	public static String getConsultaHQLDeUnUsuarioPorUsername(){ return UsuarioHome.consultaHQLDeUnUsuarioPorUsername; }
	
	/**
	 * Método de Clase: getConsultaHQLDeUnUsuarioPorPassword
	 * 			Retorna la cadena String que representa la sentencia HQL de una Consulta por Password.
	 * @return UsuarioHome.consultaHQLDeUnUsuarioPorPassword
	 */
	public static String getConsultaHQLDeUnUsuarioPorPassword(){ return UsuarioHome.consultaHQLDeUnUsuarioPorPassword; }
	
	/**
	 * Método de Clase: getConsultaHQLDeTodosLosUsuarios
	 * 			Retorna la cadena String que representa la sentencia HQL de una Consulta por todos los Usuarios.
	 * @return UsuarioHome.consultaHQLDeTodosLosUsuarios
	 */
	public static String getConsultaHQLDeTodosLosUsuarios(){ return UsuarioHome.consultaHQLDeTodosLosUsuarios; }
	
	/**
	 * Método de Clase: getConsultaHQLDeUnUsuarioPorNombreReal
	 * 			Retorna la cadena String que representa la sentencia HQL de una Consulta por el Nombre Real.
	 * @return UsuarioHome.consultaHQLDeUnUsuarioPorUsername
	 */
	public static String getConsultaHQLDeUnUsuarioPorNombreReal(){ return UsuarioHome.consultaHQLDeUnUsuarioPorNombreReal; }
	
	/**
	 * Método de Clase: getConsultaHQLDeUnUsuarioPorApellido
	 * 			Retorna la cadena String que representa la sentencia HQL de una Consulta por el Apellido.
	 * @return UsuarioHome.consultaHQLDeUnUsuarioPorUsername
	 */
	public static String getConsultaHQLDeUnUsuarioPorApellido(){ return UsuarioHome.consultaHQLDeUnUsuarioPorApellido; }
	
	/**
	 * @author ehv80
	 * Método:	consultaUsuarios
	 * 		Realiza una consulta HQL en la base de datos Clinica, Tabla USUARIOS.
	 * @param	String consultaHQL
	 * @return	List<Usuario>
	 */
	public static List<Usuario> consultaUsuarios(String consultaHQL)
	{
		Transaction transaccion;
		List<Usuario> listaDeUsuarios;
		try
		{
			if( consultaHQL != null && !consultaHQL.equals("") )
			{
				//if(LoginServlet.getHibernateSessionFactory() == null)
				//{
				//	LoginServlet.createHibernateSessionFactory();
				//}
				//if( LoginServlet.getHibernateSession() == null )
				//{
				//	LoginServlet.createHibernateSession();
				//}
				transaccion = LoginServlet.getHibernateSession().beginTransaction();
				listaDeUsuarios= (List<Usuario>)(LoginServlet.getHibernateSession().createQuery(consultaHQL).list());
				transaccion.commit();
				return listaDeUsuarios;
			}
			else
			{	
				UsuarioHome.setMensaje("Error: La consulta HQL no puede estar vacía ..!" );
				return (List<Usuario>)null;
			}
		}
		catch(HibernateException ex)
		{
			UsuarioHome.setMensaje("Ha ocurrido una Excepción en UsuarioHome.consultaUsuarios(consulatHQL) " + ex);
			return (List<Usuario>)null;
		}
	}
	
	/**
	 * @author ehv80
	 * Método:	almacenaUsuario
	 * 			En caso de almacenar usuario con éxito retorna Boolean.TRUE
	 * 			En caso contrario retorna Boolean.FALSE
	 * @param Usuario usuario
	 * @return Boolean isSuccesfullSaved
	 */
	public static Boolean almacenaUsuario(Usuario usuario)
	{
		Boolean isSuccesfullSaved = Boolean.FALSE; //por defecto
		Transaction transaccion;
		try
		{
			if( usuario != null && 
					!usuario.getNombreReal().equals("") &&
					!usuario.getApellido().equals("") &&
					!usuario.getNombreAcceso().equals("") &&
					!usuario.getClaveAcceso().equals("")
				)
			{
				//if(LoginServlet.getHibernateSessionFactory() == null)
				//{
				//	LoginServlet.createHibernateSessionFactory();
				//}
				//if( LoginServlet.getHibernateSession() == null )
				//{
				//	LoginServlet.createHibernateSession();
				//}
				transaccion = LoginServlet.getHibernateSession().beginTransaction();
				LoginServlet.getHibernateSession().save(usuario);
				transaccion.commit();
				isSuccesfullSaved = Boolean.TRUE;
				return isSuccesfullSaved;
			}
			else
			{
				UsuarioHome.setMensaje("Debe completar todos los campos del formulario ..!");
				return isSuccesfullSaved;
			}
		}
		catch(HibernateException ex)
		{
			UsuarioHome.setMensaje("Ha ocurrido una Excepción en UsuarioHome.almacenaUsuario( usuario ) " + ex);
			return isSuccesfullSaved;
		}
	}
	
	/**
	 * @author ehv80
	 * Método:	modificaUsuario
	 * 			En caso de modificar usuario con éxito retorna Boolean.TRUE
	 * 			En caso contrario retorna Boolean.FALSE
	 * @param Usuario usuario
	 * @return Boolean isSuccesfullModified
	 */
	public static Boolean modificaUsuario(Usuario usuario)
	{
		Boolean isSuccesfullModified = Boolean.FALSE; //por defecto
		Transaction transaccion;
		try
		{
			if( usuario != null && 
					!usuario.getNombreReal().equals("") &&
					!usuario.getApellido().equals("") &&
					!usuario.getNombreAcceso().equals("") &&
					!usuario.getClaveAcceso().equals("")
				)
			{
				//if(LoginServlet.getHibernateSessionFactory() == null)
				//{
				//	LoginServlet.createHibernateSessionFactory();
				//}
				//if( LoginServlet.getHibernateSession() == null )
				//{
				//	LoginServlet.createHibernateSession();
				//}
				transaccion = LoginServlet.getHibernateSession().beginTransaction();
				LoginServlet.getHibernateSession().saveOrUpdate(usuario);
				transaccion.commit();
				isSuccesfullModified = Boolean.TRUE;
				return isSuccesfullModified;
			}
			else
			{
				UsuarioHome.setMensaje("Debe completar todos los campos del formulario ..!");
				return isSuccesfullModified;
			}
		}
		catch(HibernateException ex)
		{
			UsuarioHome.setMensaje("Ha ocurrido una Excepción en UsuarioHome.modificaUsuario( usuario ) " + ex);
			return isSuccesfullModified;
		}
	}
	
	/**
	 * @author ehv80
	 * Método:	eliminaUsuario
	 * 			En caso de eliminar usuario con éxito retorna Boolean.TRUE
	 * 			En caso contrario retorna Boolean.FALSE
	 * @param Usuario usuario
	 * @return Boolean isSuccesfullDeleted
	 */
	public static Boolean eliminaUsuario(Usuario usuario)
	{
		Boolean isSuccesfullDeleted = Boolean.FALSE; //por defecto
		Transaction transaccion;
		try
		{
			if( usuario != null && 
					!usuario.getNombreReal().equals("") &&
					!usuario.getApellido().equals("") &&
					!usuario.getNombreAcceso().equals("") &&
					!usuario.getClaveAcceso().equals("")
				)
			{
				//if(LoginServlet.getHibernateSessionFactory() == null)
				//{
				//	LoginServlet.createHibernateSessionFactory();
				//}
				//if( LoginServlet.getHibernateSession() == null )
				//{
				//	LoginServlet.createHibernateSession();
				//}
				transaccion = LoginServlet.getHibernateSession().beginTransaction();
				LoginServlet.getHibernateSession().delete(usuario);
				transaccion.commit();
				isSuccesfullDeleted = Boolean.TRUE;
				return isSuccesfullDeleted;
			}
			else
			{
				UsuarioHome.setMensaje("Debe completar todos los campos del formulario ..!");
				return isSuccesfullDeleted;
			}
		}
		catch(HibernateException ex)
		{
			UsuarioHome.setMensaje("Ha ocurrido una Excepción en UsuarioHome.eliminaUsuario( usuario ) " + ex);
			return isSuccesfullDeleted;
		}
	}	
}
