package clinica;

// Generated 24/12/2007 10:36:36 by Hibernate Tools 3.2.0.beta8

import java.util.List;
import javax.naming.InitialContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.LockMode;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import dbServlets.LoginServlet;

import static org.hibernate.criterion.Example.create;

/**
 * Home object for domain model class Diagnostico.
 * @see clinica.Diagnostico
 * @author Hibernate Tools
 */
public class DiagnosticoHome 
{
	public static String mensaje;
	
	public static void setMensaje(String mensaje){ DiagnosticoHome.mensaje = mensaje; }
	
	public static String getMensaje(){ return DiagnosticoHome.mensaje; }

	/**
	 * @author ehv80
	 * Método:	consultaDiagnosticos
	 * 		Realiza una consulta HQL en la base de datos Clinica, Tabla DIAGNOSTICOS.
	 * @param	String consultaHQL
	 * @return	List<Diagnostico>
	 */
	public static List<Diagnostico> consultaDiagnosticos(String consultaHQL)
	{
		Transaction transaccion;
		List<Diagnostico> listaDeDiagnosticos;
		try
		{
			if( consultaHQL != null && !consultaHQL.equals("") )
			{
				if(LoginServlet.getHibernateSessionFactory() == null)
				{
					LoginServlet.createHibernateSessionFactory();
				}
				if( LoginServlet.getHibernateSession() == null )
				{
					LoginServlet.createHibernateSession();
				}
				transaccion = LoginServlet.getHibernateSession().beginTransaction();
				listaDeDiagnosticos= (List<Diagnostico>)(LoginServlet.getHibernateSession().createQuery(consultaHQL).list());
				transaccion.commit();
				return listaDeDiagnosticos;
			}
			else
			{	
				DiagnosticoHome.setMensaje("Error en DiagnosticoHome.consultaDiagnosticos(consulatHQL): La consulta HQL no puede estar vacía ..!" );
				return (List<Diagnostico>)null;
			}
		}
		catch(HibernateException ex)
		{
			DiagnosticoHome.setMensaje("Ha ocurrido una Excepción en DiagnosticoHome.consultaDiagnosticos(consulatHQL) " + ex);
			return (List<Diagnostico>)null;
		}
	}
	
	/**
	 * @author ehv80
	 * Método:	almacenaDiagnostico
	 * 			En caso de almacenar Diagnostico con éxito retorna Boolean.TRUE
	 * 			En caso contrario retorna Boolean.FALSE
	 * @param Diagnostico diagnostico
	 * @return Boolean isSuccesfullSaved
	 */
	public static Boolean almacenaDiagnostico(Diagnostico diagnostico)
	{
		Boolean isSuccesfullSaved = Boolean.FALSE; //por defecto
		Transaction transaccion;
		try
		{
			if( diagnostico != null &&
					!String.valueOf( diagnostico.getIdDiagnostico() ).equals("") &&
					!String.valueOf( diagnostico.getPaciente().getIdPaciente() ).equals("") &&
					!diagnostico.getDescripcion().equals("") &&
					!diagnostico.getFecha().toString().equals("")
				)
			{
				if(LoginServlet.getHibernateSessionFactory() == null)
				{
					LoginServlet.createHibernateSessionFactory();
				}
				if( LoginServlet.getHibernateSession() == null )
				{
					LoginServlet.createHibernateSession();
				}
				transaccion = LoginServlet.getHibernateSession().beginTransaction();
				LoginServlet.getHibernateSession().save(diagnostico);
				transaccion.commit();
				isSuccesfullSaved = Boolean.TRUE;
				return isSuccesfullSaved;
			}
			else
			{
				DiagnosticoHome.setMensaje("Debe completar todos los campos del formulario ..!");
				return isSuccesfullSaved;
			}
		}
		catch(HibernateException hex)
		{
			PacienteHome.setMensaje("Ha ocurrido una Excepción en DiagnosticoHome.almacenaDiagnostico( diagnostico ) " + hex);
			return isSuccesfullSaved;
		}
	}
	
	/**
	 * @author ehv80
	 * Método:	actualizaDiagnostico
	 * 			En caso de actualizar diagnostico con éxito retorna Boolean.TRUE
	 * 			En caso contrario retorna Boolean.FALSE
	 * @param Diagnostico diagnostico
	 * @return Boolean isSuccesfullUpdated
	 */
	public static Boolean actualizaDiagnostico(Diagnostico diagnostico)
	{
		Boolean isSuccesfullUpdated = Boolean.FALSE; //por defecto
		Transaction transaccion;
		try
		{
			if( diagnostico != null &&
					!String.valueOf( diagnostico.getIdDiagnostico() ).equals("") &&
					!String.valueOf( diagnostico.getPaciente().getIdPaciente() ).equals("") &&
					!diagnostico.getDescripcion().equals("") &&
					!diagnostico.getFecha().toString().equals("")
				)
			{
				if(LoginServlet.getHibernateSessionFactory() == null)
				{
					LoginServlet.createHibernateSessionFactory();
				}
				if( LoginServlet.getHibernateSession() == null )
				{
					LoginServlet.createHibernateSession();
				}
				transaccion = LoginServlet.getHibernateSession().beginTransaction();
				LoginServlet.getHibernateSession().saveOrUpdate(diagnostico);
				transaccion.commit();
				isSuccesfullUpdated = Boolean.TRUE;
				return isSuccesfullUpdated;
			}
			else
			{
				DiagnosticoHome.setMensaje("Debe completar todos los campos del formulario ..!");
				return isSuccesfullUpdated;
			}
		}
		catch(HibernateException hex)
		{
			DiagnosticoHome.setMensaje("Ha ocurrido una Excepción en DiagnosticoHome.actualizaDiagnostico( diagnostico ) " + hex);
			return isSuccesfullUpdated;
		}
	}
		
	/**
	 * @author ehv80
	 * Método:	eliminaDiagnostico
	 * 			En caso de eliminar diagnostico con éxito retorna Boolean.TRUE
	 * 			En caso contrario retorna Boolean.FALSE
	 * @param Diagnostico diagnostico
	 * @return Boolean isSuccesfullDeleted
	 */
	public static Boolean eliminaDiagnostico(Diagnostico diagnostico)
	{
		Boolean isSuccesfullDeleted = Boolean.FALSE; //por defecto
		Transaction transaccion;
		try
		{
			if( diagnostico != null &&
					!String.valueOf( diagnostico.getIdDiagnostico() ).equals("") &&
					!String.valueOf( diagnostico.getPaciente().getIdPaciente() ).equals("") &&
					!diagnostico.getDescripcion().equals("") &&
					!diagnostico.getFecha().toString().equals("")
				)
			{
				if(LoginServlet.getHibernateSessionFactory() == null)
				{
					LoginServlet.createHibernateSessionFactory();
				}
				if( LoginServlet.getHibernateSession() == null )
				{
					LoginServlet.createHibernateSession();
				}
				transaccion = LoginServlet.getHibernateSession().beginTransaction();
				LoginServlet.getHibernateSession().delete(diagnostico);
				transaccion.commit();
				isSuccesfullDeleted = Boolean.TRUE;
				return isSuccesfullDeleted;
			}
			else
			{
				DiagnosticoHome.setMensaje("Debe completar todos los campos del formulario ..!");
				return isSuccesfullDeleted;
			}
		}
		catch(HibernateException hex)
		{
			DiagnosticoHome.setMensaje("Ha ocurrido una Excepción en DiagnosticoHome.eliminaDiagnostico( diagnostico ) " + hex);
			return isSuccesfullDeleted;
		}
	}
}
