
package utility;

import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * @author ehv80
 */
public class FechaUtil 
{
	private static String mensaje;
	private static ArrayList<String> listaDeAnios;
	private static ArrayList<String> listaDeMeses;
	private static ArrayList<String> listaDeDias;
	
	/**
	 * Método de Clase: setMensaje
	 * 			Asigna una cadena String descriptiva al atributo mensaje
	 * @param mensaje
	 * @return void
	 */
	public static void setMensaje( String mensaje ){ FechaUtil.mensaje = mensaje; }
	
	/**
	 * Método de Clase: getMensaje
	 * 			Retorna el atributo FechaUtil.mensaje
	 * @param void
	 * @return FechaUtil.mensaje
	 */
	public static String getMensaje(){ return FechaUtil.mensaje; }
	
	/**
	 * Método de Clase: getIteradorListaDeAnios
	 * 			Retorna un Iterador<String> que representa una lista de años
	 * 			comprendida entre 1900 y 2099
	 * @param void
	 * @return Fechautil.listaDeAnios
	 */
	public static Iterator<String> getIteradorListaDeAnios()
	{
		listaDeAnios = new  ArrayList<String>();
		for( int i = 1900 ; i <= 2099 ; i++ )
		{
			String anioTemp = String.valueOf( i );
			listaDeAnios.add(anioTemp);
		}
		Iterator<String> iteradorListaDeAnios = (Iterator<String>)listaDeAnios.iterator();
		return iteradorListaDeAnios;
	}
	
	/**
	 * Método de Clase: getIteradorListaDeMeses
	 * 			Retorna un Iterador<String> que representa una lista de meses
	 * 			en su forma numérica comprendida entre 1 y 12
	 * @param void
	 * @return Fechautil.listaDeMeses
	 */
	public static Iterator<String> getIteradorListaDeMeses()
	{
		listaDeMeses = new ArrayList<String>();
		for( int i = 1 ; i <= 12 ; i++ )
		{
			if( i <= 9 )
			{
				String mesTemp = "0" + String.valueOf(i);
				listaDeMeses.add(mesTemp);
			}
			if( i > 9 )
			{
				String mesTemp = String.valueOf(i);
				listaDeMeses.add(mesTemp);
			}
		}
		Iterator<String> iteradorListaDeMeses = (Iterator<String>) listaDeMeses.iterator();
		return iteradorListaDeMeses;
	}
	
	/**
	 * Método de Clase: getIteradorListaDeDias
	 * 			Retorna un Iterador<String> que representa una lista de días
	 * 			en su forma numérica comprendida entre 1 y 31
	 * @param void
	 * @return Fechautil.listaDeDias
	 */
	public static Iterator<String> getIteradorListaDeDias()
	{
		listaDeDias = new ArrayList<String>();
		for( int i = 1 ; i <= 31 ; i++ )
		{
			if( i <= 9 )
			{
				String diaTemp = "0" + String.valueOf(i);
				listaDeDias.add(diaTemp);
			}
			if( i > 9 )
			{
				String diaTemp = String.valueOf(i);
				listaDeDias.add(diaTemp);
			}
		}
		Iterator<String> iteradorListaDeDias = (Iterator<String>) listaDeDias.iterator();
		return iteradorListaDeDias;
	}
	
	/**
	 * Método de Clase: validaFecha
	 * 			Toma una cadena String que representa una fecha.
	 * 			Verifica si la cadena String cumple con el formato
	 * 			especificado "yyyy-MM-dd"
	 * 			En caso de ser una Fecha válida de acuerdo a las retricciones
	 * 			impuestas por la clase SimpleDateFormat retorna un objeto 
	 * 			de la clase java.util.Date que representa esa fecha.
	 * 			En caso contrario asigna una cadena String con una descripción
	 * 			adecuada de la situación errónea.
	 * @param cadenaFecha
	 * @return fecha
	 */
	public static Date validaFecha( String cadenaFecha )
	{
		String mascaraFecha = "yyyy-MM-dd"; //[año]-[mes del año]-[día del mes]
		Date fecha;
		SimpleDateFormat formateadorFechaSimple;
		try
		{
			formateadorFechaSimple = new SimpleDateFormat( mascaraFecha );
			formateadorFechaSimple.setLenient(false);//control riguroso
			fecha = formateadorFechaSimple.parse(cadenaFecha);
			if( fecha != null )
			{
				return fecha;
			}
			else
			{
				FechaUtil.setMensaje("Debe seleccionar una Fecha que sea válida ..!");
				return null;
			}
		}
		catch( ParseException pex )
		{
			FechaUtil.setMensaje(
					"Debe seleccionar una Fecha que sea válida ..! <BR /> <BR /> Detalles : " + pex);
			return null;			
		}
		catch( IllegalArgumentException iaex)
		{
			FechaUtil.setMensaje(" Debe seleccionar una Fecha que sea válida ..! <BR /> <BR /> Detalles: " + iaex);
			return null;
		}
	}
}
