package dbServlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import clinica.Usuario;
import clinica.UsuarioHome;

/**
 * Servlet implementation class for Servlet: GestorUsuarios
 *
 */
 public class GestorUsuarios extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
 {
	 private static String mensaje;
	 
	 protected String accion;
	 
	 protected Boolean UsernameRepetido;
	 
	 protected String criterioConsulta;
	 
	 protected String valorBuscar;
	 
	 protected String eleccionEliminarUsuario;
	 
	 protected Usuario usuario;
	 
	 /**
	  * Método de Clase: setMensaje
	  * 			Asigna una cadena String al atributo mensaje
	  * 
	  * @param mensaje
	  * @return void
	  */
	 public static void setMensaje(String mensaje){ GestorUsuarios.mensaje = mensaje; }
	 
	 /**
	  * Método de Clase: getMensaje
	  * 			Retorna el atributo mensaje
	  * @param void
	  * @return mensaje
	  */
	 public static String getMensaje(){ return GestorUsuarios.mensaje; }
	 	 
	 
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public GestorUsuarios() 
	{
		super();
	}   	
	
	/**
	 * Método: setAccion
	 * 			Asigna una cadena String que representa la acción que debe realizar el servlet GestorUsusarios
	 * @param accion
	 * @return void
	 */
	protected void setAccion( String accion ){ this.accion = accion; }
	
	/**
	 * Método: getAccion 
	 * 			Retorna el atributo accion.
	 * @return accion
	 */
	protected String getAccion(){ return this.accion; }
	
	/**
	 * Método: setUsernameRepetido
	 * 			Asigna un objeto Boolean al atributo UsernameRepetido 
	 * @param UsernameRepeated
	 * @return void
	 */
	protected void setUsernameRepetido( Boolean UsernameRepetido){ this.UsernameRepetido = UsernameRepetido; }
	
	/**
	 * Método: isUsernameRepetido
	 * 			Retorna el atributo Boolean UsernameRepetido
	 * @param void 
	 * @return Boolean
	 */
	protected Boolean isUsernameRepetido(){ return this.UsernameRepetido; }
	
	/**
	 * Método: setCriterioConsulta
	 * 			Asigna una cadena String al atributo criterioConsulta
	 * @param criterioConsulta
	 * @return void
	 */
	protected void setCriterioConsulta(String criterioConsulta ){this.criterioConsulta = criterioConsulta; }
	
	/**
	 * Método: getCriterioConsulta
	 * 			Retorna el atributo criterioConsulta
	 * @param void
	 * @return criterioConsulta
	 */
	protected String getCriterioConsulta(){ return this.criterioConsulta; }
	
	/**
	 * Método: setValorBuscar
	 * 			Asigna una cadena String al atributo valorBuscar
	 * @param valorBuscar
	 * @return void
	 */
	protected void setValorBuscar( String valorBuscar ){ this.valorBuscar = valorBuscar; }
	
	/**
	 * Método: getValorBuscar
	 * 			Retorna el atributo valorBuscar
	 * @return valorBuscar
	 */
	protected String getValorBuscar(){ return this.valorBuscar; }
	
	/**
	 * Método: setUsuario
	 * 			Asigna un Usuario al atributo usuario
	 * @param usuario
	 * @return void
	 */
	protected void setUsuario(Usuario usuario ){ this.usuario = usuario; }
	
	/**
	 * Método: getUsuario
	 * 			Retorna el atributo usuario
	 * @param void
	 * @return usuario
	 */
	protected Usuario getUsuario(){ return this.usuario; }
	
	/**
	 * Método:	setEleccionEliminarUsuario
	 * 			Asigna una cadena String al atributo eleccionEliminarUsuario
	 * @param eleccionEliminarUsuario
	 * @return void
	 */
	protected void setEleccionEliminarUsuario(String eleccionEliminarUsuario){ this.eleccionEliminarUsuario = eleccionEliminarUsuario; }
	
	/**
	 * Método: getEleccionEliminarUsuario
	 * 			Retorna el atributo eleccionEliminarUsuario
	 * @param void
	 * @return eleccionEliminarUsuario
	 */
	protected String getEleccionEliminarUsuario(){ return this.eleccionEliminarUsuario; }
	
	/**
	 * Método: validarCamposFormulario
	 * 
	 * 			En caso de que el atributo accion sea igual a "consultarUsuarioCuandoRegistra"
	 * 			o igual a "consultarUsuarioCuandoModifica"
	 * 				Si los dos parámetros del formulario del request son adecuados
	 * 				- almacena los dos parámetros en los atributos criterioConsulta y valorBuscar
	 * 				- retorna el valor booleano true
	 * 				Pero si los dos parámetros son inadecuados
	 * 				- asigna un mensaje adecuado y lo pone como atributo del HttpSesion
	 * 				- redirige hacia do_registra_usuario.jsp
	 * 				- retorna el valor booleano false
	 *  		 
	 * 			En caso de que el atributo accion sea igual a "registrarUsuario" o igual a "modificarUsuario"
	 * 			crea un objeto Usuario con esos parámetros y lo almacena temporalmente en usuarioTemp
	 * 				Si los cuatro parámetros del formulario del request son adecuados
	 * 				- almacena a usuarioTemp en el atributo usuario
	 * 				- retorna el valor booleano true
	 * 				Si los cuatro parámetros del formulario del request no son adecuados
	 * 				- asigna una cadena String descriptiva al atributo mensaje
	 * 				- pone el atributo mensaje como atributo del HttpSession
	 * 				- pone a usuarioTemp como atributo del HttpSession llamado "usuarioRegistrar"
	 * 				- redirige la respuesta hacia "do_registra_usuario.jsp"
	 * 				- retorna el valor booleano false
	 * 
	 * 			En caso de que el atributo accion sea igual a "eliminarUsuario"
	 * 				Si el parámetro "eleccionEliminarUsuario" del formulario del request es adecuado
	 * 				- lo almcena en el atributo eleccionEliminarUsuario
	 * 				- retorna el valor booleano true
	 * 				Si el parámetro del formulario del request no es adecuado
	 * 				- asigna una cadena String descriptiva al atributo mensaje
	 * 				- pone el atributo mensaje como atributo del HttpSession
	 * 				- redirige la respuesta hacia "do_elimina_usuario.jsp"
	 * 				- retorna el valor booleano false
	 * 			
	 * 			En cualquier otro caso retorna el valor booleano false
	 * 
	 * @param request
	 * @param response
	 * @param urlDestino
	 * @return boolean
	 * @throws ServletException
	 * @throws IOException
	 */
	protected boolean validarCamposFormulario(HttpServletRequest request, HttpServletResponse response , String urlVuelvePorError , String atributoHttpSession ) throws ServletException, IOException
	{
		if( getAccion().equals("consultarUsuarioCuandoRegistra") || getAccion().equals("consultarUsuarioCuandoModifica") )
		{
			if( request.getParameter("selectorCriterioConsultaUsuarios") != null &&
					!request.getParameter("selectorCriterioConsultaUsuarios").equals("") && 
					request.getParameter("valorBuscar") != null && !request.getParameter("valorBuscar").equals("")
				)
			{
				setCriterioConsulta( request.getParameter("selectorCriterioConsultaUsuarios") );
				setValorBuscar( request.getParameter("valorBuscar") );
				return true;
			}
			else
			{
				GestorUsuarios.setMensaje("Debe seleccionar un criterio de búsqueda e introducir el valor que desea buscar ..!");
				request.getSession().setAttribute( atributoHttpSession, GestorUsuarios.getMensaje() );
				response.sendRedirect(urlVuelvePorError);
				return false;
			}
		}
		else if( getAccion().equals("registrarUsuario") || getAccion().equals("modificarUsuario") )
		{
			Usuario usuarioTemp = new Usuario( request.getParameter("nombreReal") , request.getParameter("apellido") , 
					request.getParameter("username") , request.getParameter("password") );
			if( request.getParameter("nombreReal") != null && !request.getParameter("nombreReal").equals("") && 
					request.getParameter("apellido") != null && !request.getParameter("apellido").equals("") && 
					request.getParameter("username") != null && !request.getParameter("username").equals("") &&
					request.getParameter("password") != null && !request.getParameter("password").equals("")
				)
			{
				setUsuario(usuarioTemp);
				return true;
			}
			else
			{
				GestorUsuarios.setMensaje("Debe completar todos los campos del formulario ..!");
				request.getSession().setAttribute("mensaje", GestorUsuarios.getMensaje() );
				request.getSession().setAttribute( atributoHttpSession , usuarioTemp);
				response.sendRedirect(urlVuelvePorError);
				return false;
			}
		}
		else if( getAccion().equals("eliminarUsuario") )
		{
			if( request.getParameter("eleccionEliminaUsuario") != null && !request.getParameter("eleccionEliminaUsuario").equals("") )
			{
				setEleccionEliminarUsuario( request.getParameter("eleccionEliminaUsuario") );
				return true;
			}
			else
			{
				GestorUsuarios.setMensaje("Debe elegir por \"SI\" o por \"NO\" ..! ");
				request.getSession().setAttribute("mensaje", GestorUsuarios.getMensaje() );
				response.sendRedirect(urlVuelvePorError);
				return false;
			}
		}
		return false;
	}
	
	/**
	 * Método:	elegirAccion
	 * 			Toma del request el parámetro oculto "accion" y lo almacena en el atributo "accion" 
	 * 			para elegir los métodos a invocar, en el orden:
	 * 			- validarCamposFormulario
	 * 			- método de la acción respectiva
	 *  
	 * @param request
	 * @param response
	 * @return void
	 * @throws ServletException
	 * @throws IOException
	 */
	public void elegirAccion( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException
	{
		if( request.getParameter("accion") != null && !request.getParameter("accion").equals("") )
		{
			setAccion( request.getParameter("accion") );
			if( getAccion().equals("consultarUsuarioCuandoRegistra") )
			{
				if( validarCamposFormulario( request, response, "do_registra_usuario.jsp", "mensajeConsultaUsuarioCuandoRegistra" ) == true )
				{
					consultarUsuario( request, response , "do_registra_usuario.jsp", "listaDeUsuarios" );
				}
			}
			else if( getAccion().equals("consultarUsuarioCuandoModifica") )
			{
				if( validarCamposFormulario( request, response, "do_modifica_usuario.jsp", "mensajeConsultaUsuarioCuandoModifica" ) == true )
				{
					consultarUsuario( request, response , "do_modifica_usuario.jsp", "listaDeUsuarios" );
				}
			}
			else if( getAccion().equals("registrarUsuario") )
			{
				if( validarCamposFormulario( request, response, "do_registra_usuario.jsp", "usuarioRegistrar" ) )
				{
					registrarUsuario(request, response , "index.jsp", "do_registra_usuario.jsp", "usuarioRegistrar");
				}
			}
			else if( getAccion().equals("modificarUsuario") )
			{
				if( validarCamposFormulario( request, response, "do_modifica_usuario.jsp", "usuarioModificar" ) == true )
				{
					//modificarUsuario( request, response);
				}
			}
			else if( getAccion().equals("eliminarUsuario") )
			{
				if( validarCamposFormulario( request, response, "do_elimina_usuario.jsp", "" ) == true )
				{
					//eliminarUsuario(request, response)
				}
			}
		}
	}
	/**
	 * Método: registrarUsuario
	 * 
	 * 			En primer lugar realiza una conexión a la Base de Datos mediante Hibernate
	 * 			con el método LoginServlet.conectarHibernate()
	 * 
	 * 			Para cumplir con la restricción:
	 * 			No pueden registrarse dos Usuarios distintos con un mismo Username:
	 * 			
	 * 			- realiza una consulta HQL para ver si hay registrado un Usuario con el Username en cuestión
	 * 			
	 * 			- En el extraño caso que la consulta HQL de como resultado "null":
	 * 				- informa del error con un mensaje que pone como atributo en el HttpSession 
	 * 				- pone como atributo del HttpSession los datos ingresados que están en el objeto que retorna getUsuario()
	 * 				- redirige hacia la urlVuelvePorError
	 * 			
	 * 			- En el caso de que la consulta HQL de como resultado una List<Usuario> vacía
	 * 				- almacena el Usuario que retorna getUsuario() en la Base de Datos mediante el método UsuarioHome.almacenaUsuario( getUsuario() )
	 * 				- Si UsuarioHome.almacenaUsuario( getUsuario() ) retorna true significa que el Usuario se almacenó correctamente, en ese caso
	 * 					- pone un mensaje como atributo del HttpSession informando que ahora puede loguearse con ese username y password
	 * 					- redirige la respuesta hacia urlDestino
	 * 				- Pero si UsuarioHome.almacenaUsuario( getUsuario() ) retorna false significa que ha ocurrido algún error, en ese caso
	 * 					- pone un mensaje como atributo del HttpSession informando del error
	 * 					- pone como atributo del HttpSession los datos ingresados que están en el objeto que retorna getUsuario()
	 * 					- redirige hacia la urlVuelvePorError
	 * 
	 * 			- En el caso de que la consulta HQL de como resultado una List<Usuario> que no está vacía
	 * 				- pone como atributo del HttpSession al Boolean que retorna isUsernameRepetido()
	 * 				- pone un mensaje como atributo del HttpSession para explicar la situación
	 * 				- pone como atributo del HttpSession los datos ingresados que están en el objeto que retorna getUsuario()
	 * 				- redirige hacia la urlVuelvePorError
	 * 				
	 * @param request
	 * @param response
	 * @param urlDestino
	 * @param urlVuelvePorError
	 * @param atributoHttpSession
	 * @throws ServletException
	 * @throws IOException
	 */
	public void registrarUsuario( HttpServletRequest request, HttpServletResponse response , String urlDestino, String urlVuelvePorError, String atributoHttpSession ) throws ServletException, IOException
	{
		//urlDestino 			<·>		"index.jsp"
		//urlVuelvePorError		<·>		"do_registra_usuario.jsp"
		//atributoHttpSession	<·> 	"usuarioRegistrar"
		String consultaHQL;
		List<Usuario> listaDeUsuarios;
		Boolean UsuarioAlmacenado = Boolean.FALSE; //por defecto
		//debe conectarse mediante Hibernate para poder registrarse como usuario
		if( LoginServlet.getHibernateSession() == null && LoginServlet.getHibernateSessionFactory() == null )
		{
			LoginServlet.conectarHibernate();
		}
		//Verifica si el username ya existe, entonces no puede registrarlo y vuelve al formulario pidiéndole que elija otro username
		consultaHQL = UsuarioHome.getConsultaHQLDeUnUsuarioPorUsername() + "'" + getUsuario().getNombreAcceso() + "'";
		listaDeUsuarios = UsuarioHome.consultaUsuarios( consultaHQL );
		if( listaDeUsuarios == null )
		{
			if( UsuarioHome.getMensaje() != null && !UsuarioHome.getMensaje().equals("") )
			{
				GestorUsuarios.setMensaje( UsuarioHome.getMensaje() );
				request.getSession().setAttribute("mensaje", GestorUsuarios.getMensaje() );
				request.getSession().setAttribute( atributoHttpSession , getUsuario() );
				response.sendRedirect( urlVuelvePorError );
			}
			else
			{
				GestorUsuarios.setMensaje( "Error en la consulta HQL al buscar el Usuario ..! Intente nuevamentes ..!" );
				request.getSession().setAttribute("mensaje", GestorUsuarios.getMensaje() );
				request.getSession().setAttribute( atributoHttpSession , getUsuario() );
				response.sendRedirect(urlVuelvePorError);
			}
		}
		else
		{
			if( listaDeUsuarios.isEmpty() )
			{
				//No hay en la base de datos alguien registrado con ese username => puede registrarlo!
				UsuarioAlmacenado = UsuarioHome.almacenaUsuario( getUsuario() );
				if( UsuarioAlmacenado.booleanValue() == true )
				{
					GestorUsuarios.setMensaje(" " +
							"Ahora puede obtener acceso a los recursos del Portal autenticándose mediante el enlace llamado \"Login\" ..!"
						);
					request.getSession().setAttribute("mensaje", GestorUsuarios.getMensaje() );
					response.sendRedirect( urlDestino );
				}
				else
				{
					GestorUsuarios.setMensaje( UsuarioHome.getMensaje() );
					request.getSession().setAttribute("mensaje", GestorUsuarios.getMensaje() );
					request.getSession().setAttribute( atributoHttpSession , getUsuario() );
					response.sendRedirect( urlVuelvePorError );
				}
			}
			else
			{
				//Hay alguien registrado en la base de datos con ese username => redirige y avisa
				setUsernameRepetido( Boolean.TRUE );
				request.getSession().setAttribute("UsernameRepetido", isUsernameRepetido() );
				GestorUsuarios.setMensaje("No puede usar el Username que ha elegido porque ya existe un Usuario registrado con ese Username ..!");
				request.getSession().setAttribute("mensaje", GestorUsuarios.getMensaje() );
				request.getSession().setAttribute( atributoHttpSession , getUsuario() );
				response.sendRedirect( urlVuelvePorError );
			}
		}
	}
	
	/**
	 * Método: consultarUsuario
	 * 
	 * 			En primer lugar en caso de ser necesario realiza la conexión a la Base de Datos mediante LoginServlet.conectarHibernate()
	 * 	
	 * 			En caso de que el atributo retornado por el método getCriterioConsulta() sea igual a "Nombre Real" o igual a "Apellido" o igual a
	 * 			"Username" y que el atributo retornado por getValorBuscar() no sea null
	 * 			- realiza la consulta HQL por getCriterioConsulta() mediante UsuarioHome.consultaUsuarios(consultaHQL)
	 * 			- pone la List<Usuario> como atributo del httpSession
	 * 			- redirige la respuesta hacia urlDestino
	 * 
	 * @param request
	 * @param response
	 * @param urlDestino
	 * @param atributoHttpSession
	 * @throws ServletException
	 * @throws IOException
	 */
	protected void consultarUsuario( HttpServletRequest request, HttpServletResponse response, String urlDestino, String atributoHttpSession  ) throws ServletException, IOException
	{
		String consultaHQL;
		List<Usuario> listaDeUsuarios;
		//para poder consultar a la Base de Datos debe conectarse mediante Hibernate
		if( LoginServlet.getHibernateSession() == null && LoginServlet.getHibernateSessionFactory() == null )
		{
			LoginServlet.conectarHibernate();
		}
 		if( getCriterioConsulta() != null && getCriterioConsulta().equals("Nombre Real") )
		{
			if( getValorBuscar() != null )
			{
				consultaHQL = UsuarioHome.getConsultaHQLDeUnUsuarioPorNombreReal() + "'" + getValorBuscar() + "'";
				listaDeUsuarios = UsuarioHome.consultaUsuarios(consultaHQL);
				request.getSession().setAttribute( atributoHttpSession , listaDeUsuarios );
				response.sendRedirect( urlDestino );
			}
		}
		else if( getCriterioConsulta() != null && getCriterioConsulta().equals("Apellido") )
		{
			if( getValorBuscar() != null )
			{
				consultaHQL = UsuarioHome.getConsultaHQLDeUnUsuarioPorApellido() + "'" + getValorBuscar() + "'";
				listaDeUsuarios = UsuarioHome.consultaUsuarios(consultaHQL);
				request.getSession().setAttribute( atributoHttpSession , listaDeUsuarios );
				response.sendRedirect( urlDestino );
			}
		}
		else if( getCriterioConsulta() != null && getCriterioConsulta().equals("Username") )
		{
			if( getValorBuscar() != null )
			{
				consultaHQL = UsuarioHome.getConsultaHQLDeUnUsuarioPorUsername() + "'" + getValorBuscar() + "'";
				listaDeUsuarios = UsuarioHome.consultaUsuarios(consultaHQL);
				request.getSession().setAttribute( atributoHttpSession , listaDeUsuarios );
				response.sendRedirect( urlDestino );
			}
		}
	}
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try
		{
			elegirAccion(request, response);
		}
		catch(HibernateException hex)
		{
			setMensaje("Ha ocurrido una Excepción en GestorUsuarios.doPost(request, response) " + hex);
			request.getSession().setAttribute("mensaje", getMensaje() );
			//response.sendRedirect("do_registra_usuario.jsp");
			response.sendRedirect("error.jsp");
		}
		catch(Exception ex)
		{
			setMensaje("Ha ocurrido una Excepción en GestorUsuarios.doPost(request, response) " + ex);
			request.getSession().setAttribute("mensaje", getMensaje() );
			response.sendRedirect("error.jsp");
		}
	}   	  	    
}