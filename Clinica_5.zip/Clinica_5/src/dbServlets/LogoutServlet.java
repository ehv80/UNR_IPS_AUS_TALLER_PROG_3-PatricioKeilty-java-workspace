package dbServlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

/**
 * Servlet implementation class for Servlet: LogoutServlet
 *
 */
 public class LogoutServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
 {
	 private static String mensaje;
	 
	 private String eleccionLogout;
	 
	 /**
	  * Método de Clase: setMensaje
	  * 			Asigna un String con la descripción del mensaje 
	  * @param mensaje
	  * @return void
	  */
	 public static void setMensaje(String mensaje) { LogoutServlet.mensaje = mensaje; }
	 
	 /**
	  * Método de Clase: getMensaje
	  * 			Retorna el atributo de Clase LogoutServlet.mensaje 
	  * @param void
	  * @return LogoutServlet.mensaje
	  */
	 public static String getMensaje() { return LogoutServlet.mensaje; }
	 
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public LogoutServlet() {
		super();
	}   	
	
	/**
	 * Método: setEleccionLogout
	 * 			Asigna una cadena String al atributo eleccionLogout
	 * @param eleccionLogout
	 * @return void
	 */
	protected void setEleccionLogout( String eleccionLogout ){ this.eleccionLogout = eleccionLogout; }
	
	/**
	 * Método: getEleccionLogout
	 * 			Retorna el atributo eleccionLogout.
	 * @param void
	 * @return LogoutServlet.eleccionLogout
	 */
	protected String getEleccionLogout(){ return this.eleccionLogout; }
	
	/**
	 * Método: validarCamposFormulario
	 * 			Toma del request el parámetro del formulario de logout.jsp: "eleccionLogout"
	 * 			En caso de ser una cadena no vacía:
	 * 			- lo asigna al atributo eleccionLogout de LogoutServlet
	 * 			- retorna el valor booleano true
	 * 			En caso contrario:
	 * 			- pone al atributo del HttpSession mensaje con una cadena de descripción adecuada
	 * 			- redirige la respuesta hacia logout.jsp
	 * 			- retorna el valor booleano: false
	 * 
	 * @param request
	 * @param response
	 * @return boolean
	 * @throws ServletException
	 * @throws IOException
	 */
	protected boolean validarCamposFormulario( HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		if( request.getParameter("eleccionLogout") != null && !request.getParameter("eleccionLogout").equals("") )
		{
			setEleccionLogout( request.getParameter("eleccionLogout") );
			return true;
		}
		else
		{
			LogoutServlet.setMensaje("Debe elegir por \"SI\" o por \"NO\" ..! ");
			request.getSession().setAttribute("mensaje", LogoutServlet.getMensaje() );
			response.sendRedirect("logout.jsp");
			return false;
		}
	}
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	/**
	 * Método: doGet
	 * 			Invoca al método doPost
	 * 
	 * @param request
	 * @param response
	 * @return void
	 * @throws ServletException
	 * @throws IOException
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	/**
	 * Método: doPost
	 * 
	 * 			Invoca al método validarCamposFormulario.
	 * 			En caso de que el atributo eleccionLogout tenga la cadena "SI":
	 * 			- invoca a LoginServlet.desconectarHibernate()
	 * 			- pone en null los atributos del HttpSession "mensajeBienvenida" y "usuario"
	 * 			- invalida la HttpSession
	 * 			- redirige la respuesta hacia index.jsp
	 * 			En caso de que el atributo eleccionLogout tenga la cadena "NO":
	 * 			- pone una descripción adecuada en el atributo mensaje del HttpSession
	 * 			- redirige la respuesta hacia logout.jsp
	 * 
	 * @param request
	 * @param response
	 * @return void
	 * @throws ServletException 
	 * @throws IOException
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try
		{
			if( validarCamposFormulario(request, response) == true )
			{
				if( getEleccionLogout() != null && getEleccionLogout().equals("SI") )
				{
					LoginServlet.desconectarHibernate();
					request.getSession().setAttribute("mensajeBienvenida", null);
					request.getSession().setAttribute("usuario", null);
					request.getSession().invalidate();
					response.sendRedirect("index.jsp");
				}
				if(getEleccionLogout() != null && getEleccionLogout().equals("NO") )
				{
					LogoutServlet.setMensaje("Usted ha elegido continuar usando el Portal ...");
					request.getSession().setAttribute("mensaje", LogoutServlet.getMensaje() );
					response.sendRedirect("logout.jsp");
				}
			}
		}
		catch(HibernateException hex)
		{
			LogoutServlet.setMensaje("Ha ocurrido una Excepción en al intentar cerrar la sesión en el Portal : " + hex);
			request.getSession().setAttribute("mensaje", LogoutServlet.getMensaje() );
			response.sendRedirect("logout.jsp");
		}
		catch(Exception ex)
		{
			LogoutServlet.setMensaje("Ha ocurrido una Excepción en al intentar cerrar la sesión en el Portal : " + ex);
			request.getSession().setAttribute("mensaje", LogoutServlet.getMensaje() );
			response.sendRedirect("logout.jsp");
		}
	}   	  	    
}