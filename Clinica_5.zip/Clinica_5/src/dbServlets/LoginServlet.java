package dbServlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import clinica.Usuario;
import clinica.UsuarioHome;

/**
 * Servlet implementation class for Servlet: LoginServlet
 *
 */
 public class LoginServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
 {
	 private static SessionFactory hibernateSessionFactory;
	 private static Session hibernateSession;
	 private static String mensaje;
	 private static int contadorIntentosDeAcceso = 0;
	 
	 private String username;
	 private String password;
	 
	 /**
	  * Método de Clase: setMensaje
	  * 		Asigna un String al atributo de Clase: String mensaje
	  * @param String mensaje
	  * @return void
	  */
	 public static void setMensaje(String mensaje) { LoginServlet.mensaje = mensaje; }
	 
	 /**
	  * Método de Clase: getMensaje
	  * 		Retorna el atributo de Clase: String mensaje
	  * @param void
	  * @return String
	  */
	 public static String getMensaje() { return LoginServlet.mensaje;  }
	 
	 /**
	  * Método de Clase: createHibernateSessionFactory
	  * 		Inicializa el único SessionFactory para toda la aplicación web.
	  *	@param void
	  *	@return void
	  */
	public static void createHibernateSessionFactory()
	{
		try
		{
			hibernateSessionFactory = new Configuration().configure().buildSessionFactory();
		}
		catch(HibernateException ex)
		{
			setMensaje("Ha ocurrido una Excepción al iniciar la sesión: " + ex);
		}
	}
	
	/**
	 * Método de Clase: closeHibernateSessionFactory
	 * 			Finaliza el único SessionFactory para toda la aplicación web.
	 * @param void
	 * @return void
	 */
	public static void closeHibernateSessionFactory()
	{
		try
		{
			hibernateSessionFactory.close();
			hibernateSessionFactory = null;
		}
		catch(HibernateException ex)
		{
			setMensaje("Ha ocurrido una Excepción al cerrar la sesión: " + ex);
		}
	}
	 
	/**
	 * Método de Clase: getHibernateSessionFactory
	 * 			Retorna el único SessionFactory para toda la aplicación web.
	 * @param void
	 * @return SessionFactory
	 */
	public static SessionFactory getHibernateSessionFactory()
	{
		return hibernateSessionFactory;
	}
	
	/**
	 * Método de Clase: createHibernateSession
	 * 			Inicializa estáticamente la org.hibernate.Session.
	 * @param void
	 * @return void
	 */
	public static void createHibernateSession()
	{
		try
		{
			if(hibernateSessionFactory != null )
			{
				hibernateSession = hibernateSessionFactory.openSession();
			}
		}
		catch(HibernateException ex)
		{
			setMensaje("Ha ocurrido una Excepción al iniciar la sesión: " + ex);
		}
	}
	
	/**
	 * Método de Clase: closeHibernateSession
	 * 			Cierra estáticamente la org.hibernate.Session.
	 * @param void
	 * @return void
	 */
	public static void closeHibernateSession()
	{
		try
		{
			hibernateSession.close();
			hibernateSession = null;
		}
		catch(HibernateException ex)
		{
			setMensaje("Ha ocurrido una Excepción al cerrar la sesión: " + ex);
		}
	}
	
	/**
	 * Método de Clase: getHibernateSession
	 * 			Retorna la org.hibernate.Session.
	 * @param void
	 * @return Session.
	 */
	public static Session getHibernateSession()
	{
		return hibernateSession;
	}
	
	/**
	 * Método de Clase: conectarHibernate
	 * 			Conecta mediante createSessionFactory y createSession.
	 * @param void
	 * @return void
	 */
	public static void conectarHibernate()
	{
		if( hibernateSessionFactory == null )
		{
			createHibernateSessionFactory();
		}
		if( hibernateSession == null )
		{
			createHibernateSession();
		}
	}
	
	/**
	 * Método de Clase: desconectarHibernate
	 * 			Desconecta mediante  closeSession y closeSessionFactory.
	 * @param void
	 * @return void
	 */
	public static void desconectarHibernate()
	{
		if( hibernateSession != null )
		{
			closeHibernateSession();
		}
		if( hibernateSessionFactory != null )
		{
			closeHibernateSessionFactory();
		}
	}
	
	/**
	 * Método: setUsername
	 * 			Asigna un String al atributo de instancia username.
	 * @param String username
	 * @return void
	 */
	protected void setUsername( String username ){ this.username = username; }
	
	/**
	 * Método: getUsername
	 * 			Retorna el atributo de instancia username.
	 * @param void
	 * @return String username
	 */
	protected String getUsername(){ return this.username; }
	
	/**
	 * Método: setPassword
	 * 			Asigna un String al atributo de instancia password.
	 * @param String password
	 * @return void
	 */
	protected void setPassword( String password ){ this.password = password; }
	
	/**
	 * Método: getPassword
	 * 			Retorna el atributo de instancia password.
	 * @param void
	 * @return String password
	 */
	protected String getPassword(){ return this.password; }
	
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public LoginServlet() 
	{
		super();
	}   	
	
	/**
	 * Método: validarCamposFormulario
	 * 			Toma del request los dos parámetros del formulario de login.jsp: "username" y "password"
	 * 			En caso de ser ambos dos cadenas de caracteres no vacías:
	 * 			- las almacena en los respectivos atributos de LoginServlet
	 * 			- las almacena en la HttpSession
	 * 			- retorna el valor booleano: true
	 * 			En caso contrario:
	 * 			- almacena los parámetros en la HttpSession 
	 * 			- activa "isUsernameOrPasswordError" con el valor booleano: true y lo almacena en el HttpSession
	 * 			- asigna el String "mensaje" con una descripción apropiada y lo almacena en el HttpSession
	 * 			- redirige la respuesta hacia "login.jsp"
	 * 			- retorna el valor booleano. false
	 * @param HttpServletRequest request
	 * @param HttpServletResponse response
	 * @return boolean
	 * @throws ServletException
	 * @throws IOException
	 */
	protected boolean validarCamposFormulario(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		if( request.getParameter("username") != null && !request.getParameter("username").equals("") &&
				request.getParameter("password") != null && !request.getParameter("password").equals("") 
			)
		{
			setUsername( request.getParameter("username") );
			setPassword( request.getParameter("password") );
			// pone los parámetros recibidos como atributos en el HttpSession
			request.getSession().setAttribute("username", getUsername() );
			request.getSession().setAttribute("password", getPassword() );
			return true;
		}
		else
		{
			// igualmente pone los parámetros recibidos como atributos en el HttpSession
			request.getSession().setAttribute("username", request.getParameter("username") );
			request.getSession().setAttribute("password", request.getParameter("password") );
			request.getSession().setAttribute("isUsernameOrPasswordError", Boolean.TRUE);
			LoginServlet.setMensaje("Debe completar todos los campos del formulario ..! ");
			request.getSession().setAttribute("mensaje", LoginServlet.getMensaje() );
			response.sendRedirect("login.jsp");
			return false;
		}
	}
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	/**
	 * Método: doGet
	 * 			Invoca al método doPost con sus parámetros.
	 * @param request
	 * @param response
	 * @return void
	 * @throws ServletException
	 * @throws IOException
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	/**
	 * Método:	doPost
	 * 
	 * Invoca al método validarCamposFormulario
	 * 
	 * Verifica la existencia en la base de datos de un Usuario con ese Username y ese Password.
	 * 
	 * En caso de haber coincidencia lexicográfica pone en el HttpSession:
	 *    - al atributo "user" con valor "authenticated!"
	 *    - al atributo "usuario" con el objeto Usuario resultado de la consulta HQL
	 *    - al atributo "mensajeBienvenida" con el valor del String mensajeBienvenida
	 * y luego redirige la respuesta hacia index.jsp
	 * 
	 * En cualquier otro caso pone en el HttpSession al atributo "mensaje" con el valor del String
	 * que explica la situación errónea, pone al atributo "isUsernameOrPasswordError" con su valor 
	 * booleano apropiado y redirige la respuesta hacia login.jsp
	 * 
	 * @param 	request
	 * @param	response
	 * @return	void
	 * @throws	ServletException
	 * @throws  IOException
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String consultaHQL;
		List<Usuario> listaDeUsuarios;
		Usuario usuario;
		Boolean isUsernameOrPasswordError = Boolean.FALSE; //por defecto
		String mensajeBienvenida;
		try
		{
			conectarHibernate();
			if( validarCamposFormulario(request, response) == true )
			{
				// Consulta en Base de Datos si existe el par "usuario - password"
				consultaHQL = UsuarioHome.getConsultaHQLDeUnUsuarioPorUsername() + "'" + getUsername() + "' and u.claveAcceso = '" + getPassword() + "'";
				listaDeUsuarios = UsuarioHome.consultaUsuarios(consultaHQL);
				if( listaDeUsuarios == null )
				{
					if( UsuarioHome.getMensaje() != null && !UsuarioHome.getMensaje().equals("") )
					{
						LoginServlet.setMensaje( UsuarioHome.getMensaje() );
						request.getSession().setAttribute("mensaje", LoginServlet.getMensaje() );
						response.sendRedirect("login.jsp");
					}
					else
					{
						LoginServlet.setMensaje( "Error en la consulta HQL al buscar el Username y el Password..! Intente nuevamente ..!" );
						request.getSession().setAttribute("mensaje", LoginServlet.getMensaje() );
						response.sendRedirect("login.jsp");
					}
				}
				else
				{	
					if( !listaDeUsuarios.isEmpty() )
					{
						if( listaDeUsuarios.size() == 1 )
						{
							usuario = listaDeUsuarios.get(0); //índice comienza en cero
							if( usuario.getNombreAcceso().compareTo( getUsername() ) == 0 && usuario.getClaveAcceso().compareTo( getPassword() ) == 0 )
							{
								// username y password corresponden a un usuario en la base de datos
								request.getSession().setAttribute("user", "authenticated!");// Según la función definida en: WebContent/include/common.jsp
								request.getSession().setAttribute("usuario", usuario);
								mensajeBienvenida = "Bienvenido al Portal <BR /> " + usuario.getNombreReal() + " " + usuario.getApellido();
								request.getSession().setAttribute("mensajeBienvenida", mensajeBienvenida);
								response.sendRedirect("index.jsp");
							}
							else if( usuario.getNombreAcceso().compareTo( getUsername() ) != 0 || usuario.getClaveAcceso().compareTo( getPassword() ) != 0 )
							{
								isUsernameOrPasswordError = Boolean.TRUE;
								request.getSession().setAttribute("isUsernameOrPasswordError", isUsernameOrPasswordError);
								LoginServlet.setMensaje(
									"El Username o el Password no corresponden a un Usuario registrado en la Base de Datos ..! Intente nuevamente ..!" );
								request.getSession().setAttribute("mensaje", LoginServlet.getMensaje() );
								response.sendRedirect("login.jsp");
							}
						}
						else
						{
							LoginServlet.setMensaje( "Error en la consulta HQL al buscar el Username y Password ..! Intente nuevamente ..!" );
							request.getSession().setAttribute("mensaje", LoginServlet.getMensaje() );
							response.sendRedirect("login.jsp");
						}
					}
					else if( listaDeUsuarios.isEmpty() )
					{
						isUsernameOrPasswordError = Boolean.TRUE;
						request.getSession().setAttribute("isUsernameOrPasswordError", isUsernameOrPasswordError);
						LoginServlet.setMensaje("El Username o el Password no corresponden a un usuario registrado en la Base de Datos ..! ");
						contadorIntentosDeAcceso++;
						if( contadorIntentosDeAcceso == 5)
						{
							LoginServlet.setMensaje( LoginServlet.getMensaje() + "<BR /> <BR /> Lo invitamos a registrarse como Usuario de nuestro Portal ..! ");
							contadorIntentosDeAcceso = 0;
						}
						request.getSession().setAttribute("mensaje", LoginServlet.getMensaje() );
						response.sendRedirect("login.jsp");
					}
				}
			}
		}
		catch(HibernateException hex)
		{
			LoginServlet.setMensaje("Ha ocurrido una Excepción al intentar autenticarse ..! Intente nuevamente ..! " + hex);
			request.getSession().setAttribute("mensaje", LoginServlet.getMensaje() );
			response.sendRedirect("login.jsp");
		}
		catch(Exception ex)
		{
			LoginServlet.setMensaje("Ha ocurrido una Excepción al intentar autenticarse ..! Intente nuevamente ..! " + ex);
			request.getSession().setAttribute("mensaje", LoginServlet.getMensaje() );
			response.sendRedirect("login.jsp");
		}
	}   	  	    
}